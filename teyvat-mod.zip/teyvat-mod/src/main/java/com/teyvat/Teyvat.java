package com.teyvat;

import com.teyvat.net.Net;
import com.teyvat.registry.*;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;

@Mod(Teyvat.MODID)
public class Teyvat {
    public static final String MODID = "teyvat";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }

    public Teyvat(IEventBus modBus, ModContainer container) {
        ModComponents.REG.register(modBus);
        ModItems.REG.register(modBus);
        ModEntities.REG.register(modBus);
        ModEffects.REG.register(modBus);
        ModAttachments.REG.register(modBus);
        ModTabs.REG.register(modBus);
        modBus.addListener(Net::register);
    }
}
