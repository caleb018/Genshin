package com.teyvat;

import com.teyvat.registry.ModComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/** Estilos de ornamento. A ordem precisa bater com gen_assets.py (ORNAMENTS). */
public enum Ornament {
    MONDSTADT("mondstadt"), LIYUE("liyue"), INAZUMA("inazuma"), SUMERU("sumeru"),
    FONTAINE("fontaine"), NATLAN("natlan"), SNEZHNAYA("snezhnaya");

    public final String id;

    Ornament(String id) { this.id = id; }

    public static Ornament byId(String id) {
        for (Ornament o : values()) if (o.id.equals(id)) return o;
        return INAZUMA;
    }

    public static Ornament of(ItemStack stack) {
        String s = stack.get(ModComponents.ORNAMENT.get());
        return s == null ? INAZUMA : byId(s);
    }

    public Ornament next() {
        return values()[(ordinal() + 1) % values().length];
    }

    public Component displayName() {
        return Component.translatable("ornament.teyvat." + id);
    }
}
