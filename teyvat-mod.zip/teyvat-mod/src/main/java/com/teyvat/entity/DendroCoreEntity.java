package com.teyvat.entity;

import com.teyvat.Balance;
import com.teyvat.Element;
import com.teyvat.logic.ElementalSystem;
import com.teyvat.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;

/** Nucleo Dendro gerado por Florescer. Explode sozinho; Pyro = Brotar; Electro = Hiperflorescer. */
public class DendroCoreEntity extends Entity implements ItemSupplier {
    private UUID owner;
    private int life;

    public DendroCoreEntity(EntityType<? extends DendroCoreEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public void setOwner(@Nullable LivingEntity e) {
        this.owner = e == null ? null : e.getUUID();
    }

    @Nullable
    public LivingEntity getOwner() {
        if (owner != null && level() instanceof ServerLevel sl && sl.getEntity(owner) instanceof LivingEntity le) return le;
        return null;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {}

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (tickCount % 3 == 0) {
                level().addParticle(ParticleTypes.HAPPY_VILLAGER, getX() + (random.nextDouble() - .5) * .4, getY() + .3 + random.nextDouble() * .3, getZ() + (random.nextDouble() - .5) * .4, 0, 0.02, 0);
            }
            return;
        }
        life++;
        if (life >= 120) bloomExplode();
    }

    private void bloomExplode() {
        if (!(level() instanceof ServerLevel sl)) return;
        LivingEntity src = getOwner();
        Vec3 c = position();
        for (LivingEntity e : ElementalSystem.around(sl, src, c, 3.0)) {
            ElementalSystem.deal(e, src, Element.DENDRO, Balance.REACTION * 0.8f);
        }
        sl.sendParticles(Element.DENDRO.dust(2f), c.x, c.y + .3, c.z, 30, 1.2, .5, 1.2, 0.05);
        sl.playSound(null, c.x, c.y, c.z, SoundEvents.GRASS_BREAK, SoundSource.PLAYERS, 1f, 0.8f);
        discard();
    }

    public void burgeon(@Nullable LivingEntity src) {
        if (!(level() instanceof ServerLevel sl)) return;
        Vec3 c = position();
        for (LivingEntity e : ElementalSystem.around(sl, src, c, 4.0)) {
            ElementalSystem.deal(e, src, Element.PYRO, Balance.REACTION * 1.4f);
            e.setRemainingFireTicks(60);
        }
        sl.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION, c.x, c.y + .5, c.z, 3, .8, .4, .8, 0);
        sl.sendParticles(Element.PYRO.dust(2f), c.x, c.y + .5, c.z, 40, 1.5, .6, 1.5, .08);
        sl.playSound(null, c.x, c.y, c.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, .8f, 1.2f);
        discard();
    }

    public void hyperbloom(@Nullable LivingEntity src) {
        if (!(level() instanceof ServerLevel sl)) return;
        List<LivingEntity> list = ElementalSystem.around(sl, src, position(), 10.0);
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            double d = e.distanceToSqr(this);
            if (d < bd) { bd = d; best = e; }
        }
        if (best != null) {
            ElementalSystem.deal(best, src, Element.ELECTRO, Balance.REACTION * 1.0f);
            Vec3 a = position(), b = best.position().add(0, best.getBbHeight() / 2, 0);
            for (int i = 0; i <= 12; i++) {
                Vec3 p = a.lerp(b, i / 12.0);
                sl.sendParticles(Element.DENDRO.dust(1f), p.x, p.y, p.z, 1, 0, 0, 0, 0);
                sl.sendParticles(net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, .05, .05, .05, 0);
            }
        }
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, .5f, 1.6f);
        discard();
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
        life = tag.getInt("Life");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        if (owner != null) tag.putUUID("Owner", owner);
        tag.putInt("Life", life);
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.DENDRO_CORE.get());
    }
}
