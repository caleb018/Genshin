package com.teyvat.entity;

import com.teyvat.Balance;
import com.teyvat.Element;
import com.teyvat.logic.ElementalSystem;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;

/**
 * Cristalizacao Lunar: torreta dourada (modelo do Blockbench "Moondrifts_torreta_dourada")
 * que ataca inimigos proximos com dano Geo Lunar durante alguns segundos.
 */
public class MoondriftEntity extends Entity {
    public static final int LIFETIME = 20 * 12;
    private UUID owner;

    public MoondriftEntity(EntityType<? extends MoondriftEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public void setOwner(@Nullable LivingEntity e) {
        this.owner = e == null ? null : e.getUUID();
    }

    @Nullable
    public LivingEntity getOwner() {
        if (owner != null && level() instanceof ServerLevel sl && sl.getEntity(owner) instanceof LivingEntity le) return le;
        return null;
    }

    public UUID ownerId() { return owner; }

    public void refresh() { this.tickCount = 0; }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {}

    @Override
    public boolean isPickable() { return false; }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (tickCount % 2 == 0) {
                double a = random.nextDouble() * Math.PI * 2;
                level().addParticle(ParticleTypes.END_ROD, getX() + Math.cos(a) * 1.2, getY() + 1.2 + random.nextDouble() * 1.4, getZ() + Math.sin(a) * 1.2, 0, 0.01, 0);
            }
            return;
        }
        if (tickCount >= LIFETIME) {
            discard();
            return;
        }
        if (tickCount % 20 == 10 && level() instanceof ServerLevel sl) {
            LivingEntity src = getOwner();
            List<LivingEntity> list = ElementalSystem.around(sl, src, position().add(0, 1, 0), 7.0);
            int n = 0;
            for (LivingEntity e : list) {
                if (n++ >= 5) break;
                ElementalSystem.deal(e, src, Element.GEO, Balance.REACTION * 0.9f);
                sl.sendParticles(ParticleTypes.END_ROD, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 10, .3, .5, .3, .05);
            }
            if (!list.isEmpty()) {
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.2f, 1.4f);
            }
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
        tickCount = tag.getInt("Age");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        if (owner != null) tag.putUUID("Owner", owner);
        tag.putInt("Age", tickCount);
    }
}
