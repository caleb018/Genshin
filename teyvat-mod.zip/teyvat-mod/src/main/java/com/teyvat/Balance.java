package com.teyvat;

/** Numeros de balanceamento centralizados. */
public final class Balance {
    private Balance() {}
    /** Dano base (HP) das reacoes transformativas. */
    public static final float REACTION = 6.0f;
    public static final int IMBUE_TICKS = 20 * 15;
    public static final int IMBUE_COOLDOWN = 20 * 12;
    public static final float IMBUE_BONUS = 1.25f;
    public static final int[] SKILL_COOLDOWN = {
            20 * 16, // PYRO   (Hu Tao)
            20 * 16, // HYDRO  (Vodyanitsa)
            20 * 18, // ANEMO  (Vesna)
            20 * 8,  // ELECTRO(Clorinde)
            20 * 14, // DENDRO (Lauma)
            20 * 8,  // CRYO   (Eula)
            20 * 12  // GEO    (Xilonen)
    };
}
