package com.teyvat.registry;

import com.teyvat.Teyvat;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageType;

public final class ModDamage {
    public static final ResourceKey<DamageType> ELEMENTAL =
            ResourceKey.create(Registries.DAMAGE_TYPE, Teyvat.id("elemental"));

    private ModDamage() {}
}
