package com.teyvat.registry;

import com.teyvat.Teyvat;
import com.teyvat.item.ElementalCurioItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister<Item> REG = DeferredRegister.create(Registries.ITEM, Teyvat.MODID);

    public static final DeferredHolder<Item, ElementalCurioItem> VISION = REG.register("vision",
            () -> new ElementalCurioItem(ElementalCurioItem.Kind.VISION, new Item.Properties().stacksTo(1).fireResistant()));
    public static final DeferredHolder<Item, ElementalCurioItem> STELLAR_AXIS = REG.register("stellar_axis",
            () -> new ElementalCurioItem(ElementalCurioItem.Kind.STELLAR_AXIS, new Item.Properties().stacksTo(1).fireResistant()));
    public static final DeferredHolder<Item, ElementalCurioItem> LUNAR_DISC = REG.register("lunar_disc",
            () -> new ElementalCurioItem(ElementalCurioItem.Kind.LUNAR_DISC, new Item.Properties().stacksTo(1).fireResistant()));

    /** Itens "tecnicos" usados so pelos renderers (fora da aba criativa). */
    public static final DeferredHolder<Item, Item> DENDRO_CORE = REG.register("dendro_core", () -> new Item(new Item.Properties()));
    public static final DeferredHolder<Item, Item> MOONDRIFT_TURRET = REG.register("moondrift_turret", () -> new Item(new Item.Properties()));

    private ModItems() {}
}
