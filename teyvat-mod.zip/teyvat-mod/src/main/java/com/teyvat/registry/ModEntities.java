package com.teyvat.registry;

import com.teyvat.Teyvat;
import com.teyvat.entity.DendroCoreEntity;
import com.teyvat.entity.MoondriftEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> REG = DeferredRegister.create(Registries.ENTITY_TYPE, Teyvat.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<DendroCoreEntity>> DENDRO_CORE = REG.register("dendro_core",
            () -> EntityType.Builder.<DendroCoreEntity>of(DendroCoreEntity::new, MobCategory.MISC)
                    .sized(0.4f, 0.4f).clientTrackingRange(8).updateInterval(5).build("dendro_core"));

    public static final DeferredHolder<EntityType<?>, EntityType<MoondriftEntity>> MOONDRIFT = REG.register("moondrift",
            () -> EntityType.Builder.<MoondriftEntity>of(MoondriftEntity::new, MobCategory.MISC)
                    .sized(3.0f, 3.0f).clientTrackingRange(10).updateInterval(10).build("moondrift"));

    private ModEntities() {}
}
