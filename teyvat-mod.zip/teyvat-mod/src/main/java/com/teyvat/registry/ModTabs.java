package com.teyvat.registry;

import com.teyvat.Ornament;
import com.teyvat.Teyvat;
import com.teyvat.item.ElementalCurioItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> REG = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Teyvat.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = REG.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.teyvat"))
            .icon(() -> ElementalCurioItem.withOrnament(ModItems.VISION.get(), Ornament.INAZUMA))
            .displayItems((params, out) -> {
                // um item por ornamento: o jogador escolhe o estilo pelo menu criativo
                for (var item : new ElementalCurioItem[]{ModItems.VISION.get(), ModItems.STELLAR_AXIS.get(), ModItems.LUNAR_DISC.get()}) {
                    for (Ornament o : Ornament.values()) {
                        ItemStack s = ElementalCurioItem.withOrnament(item, o);
                        out.accept(s);
                    }
                }
            })
            .build());

    private ModTabs() {}
}
