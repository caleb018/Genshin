package com.teyvat.registry;

import com.mojang.serialization.Codec;
import com.teyvat.Teyvat;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModComponents {
    public static final DeferredRegister<DataComponentType<?>> REG =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, Teyvat.MODID);

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<String>> ORNAMENT =
            REG.register("ornament", () -> DataComponentType.<String>builder()
                    .persistent(Codec.STRING)
                    .networkSynchronized(ByteBufCodecs.STRING_UTF8)
                    .build());

    private ModComponents() {}
}
