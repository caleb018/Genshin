package com.teyvat.registry;

import com.teyvat.Teyvat;
import com.teyvat.logic.ElementalAura;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

public final class ModAttachments {
    public static final DeferredRegister<AttachmentType<?>> REG =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, Teyvat.MODID);

    /** Aura elemental ativa em uma entidade (nao persistente, vive so no servidor). */
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<ElementalAura>> AURA =
            REG.register("aura", () -> AttachmentType.builder(ElementalAura::new).build());

    private ModAttachments() {}
}
