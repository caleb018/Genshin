package com.teyvat.registry;

import com.teyvat.Element;
import com.teyvat.Teyvat;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> REG = DeferredRegister.create(Registries.MOB_EFFECT, Teyvat.MODID);

    /** Efeito simples (sem logica propria): a logica fica em ElementalSystem. */
    public static class Marker extends MobEffect {
        public Marker(MobEffectCategory cat, int color) { super(cat, color); }
    }

    public static final Map<Element, DeferredHolder<MobEffect, Marker>> AURA = new EnumMap<>(Element.class);

    static {
        for (Element e : Element.values()) {
            AURA.put(e, REG.register(e.id, () -> new Marker(MobEffectCategory.HARMFUL, e.rgb)));
        }
    }

    // ids de textura: mob_effect/<nome>.png -> registrados com o mesmo nome
    public static final DeferredHolder<MobEffect, Marker> FROZEN = REG.register("frozen", () -> {
        Marker m = new Marker(MobEffectCategory.HARMFUL, 0x96DCFF);
        m.addAttributeModifier(Attributes.MOVEMENT_SPEED, Teyvat.id("frozen_speed"), -1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        m.addAttributeModifier(Attributes.JUMP_STRENGTH, Teyvat.id("frozen_jump"), -1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        return m;
    });

    public static final DeferredHolder<MobEffect, Marker> SUPERCONDUCT = REG.register("superconduct", () -> {
        Marker m = new Marker(MobEffectCategory.HARMFUL, 0xC8A0FF);
        m.addAttributeModifier(Attributes.ARMOR, Teyvat.id("superconduct_armor"), -6.0, AttributeModifier.Operation.ADD_VALUE);
        return m;
    });

    public static final DeferredHolder<MobEffect, Marker> QUICKEN = REG.register("quicken", () -> new Marker(MobEffectCategory.HARMFUL, 0xA0FF82));
    public static final DeferredHolder<MobEffect, Marker> SHRED = REG.register("shred", () -> new Marker(MobEffectCategory.HARMFUL, 0xFFE678));

    private ModEffects() {}
}
