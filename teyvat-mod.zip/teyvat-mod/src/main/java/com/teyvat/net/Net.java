package com.teyvat.net;

import com.teyvat.logic.PlayerElements;
import com.teyvat.logic.SkillSystem;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class Net {
    private Net() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar r = event.registrar("1");

        r.playToServer(SelectElementPayload.TYPE, SelectElementPayload.CODEC, (p, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                if (p.cycle()) PlayerElements.cycle(sp, p.index());
                else PlayerElements.select(sp, p.index());
            }
        }));

        r.playToServer(CastSkillPayload.TYPE, CastSkillPayload.CODEC, (p, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) SkillSystem.cast(sp);
        }));

        r.playToClient(SyncElementPayload.TYPE, SyncElementPayload.CODEC,
                (p, ctx) -> ctx.enqueueWork(() -> ClientPayloadHandler.handle(p)));
    }
}
