package com.teyvat.net;

import com.teyvat.Teyvat;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.UUID;

/** Servidor -> clientes: elemento atual + flags visuais de um jogador. */
public record SyncElementPayload(UUID player, int element, int flags) implements CustomPacketPayload {
    public static final int F_VISION = 1, F_IMBUE = 2, F_ARMED = 4, F_LUNAR = 8, F_AXIS = 16;

    public static final Type<SyncElementPayload> TYPE = new Type<>(Teyvat.id("sync_element"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SyncElementPayload> CODEC = StreamCodec.composite(
            UUIDUtil.STREAM_CODEC, SyncElementPayload::player,
            ByteBufCodecs.VAR_INT, SyncElementPayload::element,
            ByteBufCodecs.VAR_INT, SyncElementPayload::flags,
            SyncElementPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
