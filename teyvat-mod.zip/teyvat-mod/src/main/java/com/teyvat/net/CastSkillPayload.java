package com.teyvat.net;

import com.teyvat.Teyvat;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Cliente -> servidor: usar habilidade elemental. */
public record CastSkillPayload() implements CustomPacketPayload {
    public static final Type<CastSkillPayload> TYPE = new Type<>(Teyvat.id("cast_skill"));
    public static final StreamCodec<ByteBuf, CastSkillPayload> CODEC = StreamCodec.unit(new CastSkillPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
