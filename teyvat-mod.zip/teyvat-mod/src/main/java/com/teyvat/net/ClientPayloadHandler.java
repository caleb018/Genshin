package com.teyvat.net;

public final class ClientPayloadHandler {
    private ClientPayloadHandler() {}

    public static void handle(SyncElementPayload p) {
        ClientElementState.put(p.player(), new ClientElementState.State(p.element(), p.flags()));
    }
}
