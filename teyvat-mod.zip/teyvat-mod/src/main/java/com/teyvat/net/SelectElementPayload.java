package com.teyvat.net;

import com.teyvat.Teyvat;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Cliente -> servidor: escolher elemento (index absoluto) ou ciclar (cycle=true, index = +1/-1). */
public record SelectElementPayload(int index, boolean cycle) implements CustomPacketPayload {
    public static final Type<SelectElementPayload> TYPE = new Type<>(Teyvat.id("select_element"));
    public static final StreamCodec<ByteBuf, SelectElementPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SelectElementPayload::index,
            ByteBufCodecs.BOOL, SelectElementPayload::cycle,
            SelectElementPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
