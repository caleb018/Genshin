package com.teyvat.net;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Estado visual dos jogadores no cliente. Sem referencias a classes client-only (seguro no servidor). */
public final class ClientElementState {
    public record State(int element, int flags) {
        public boolean has(int f) { return (flags & f) != 0; }
    }

    private static final Map<UUID, State> MAP = new HashMap<>();

    private ClientElementState() {}

    public static State get(UUID id) { return MAP.get(id); }

    public static void put(UUID id, State s) { MAP.put(id, s); }

    public static void clear() { MAP.clear(); }
}
