package com.teyvat.logic;

import com.teyvat.Element;

import java.util.EnumMap;
import java.util.Iterator;
import java.util.Map;

/** Estado de aura elemental de uma entidade (gauge units, como no jogo original). */
public class ElementalAura {
    public static class Gauge {
        public float u;
        public float decay;
    }

    public final EnumMap<Element, Gauge> map = new EnumMap<>(Element.class);
    public int quickenTicks;
    public int burningTicks;
    public boolean lunarCharged;
    public int timer;

    public boolean has(Element e) {
        Gauge g = map.get(e);
        return g != null && g.u > 0.01f;
    }

    public float get(Element e) {
        Gauge g = map.get(e);
        return g == null ? 0f : g.u;
    }

    /** Aplica elemento: 1U -> 0.8U de gauge (aura tax), decaimento proporcional. */
    public void add(Element e, float units) {
        float gauge = units * 0.8f;
        Gauge g = map.computeIfAbsent(e, k -> new Gauge());
        g.u = Math.max(g.u, gauge);
        g.decay = g.u / ((9.5f * g.u + 4f) * 20f);
    }

    public void consume(Element e, float amount) {
        Gauge g = map.get(e);
        if (g == null) return;
        g.u -= amount;
        if (g.u <= 0.01f) map.remove(e);
    }

    public boolean isEmpty() {
        return map.isEmpty() && quickenTicks <= 0 && burningTicks <= 0;
    }

    public void tick() {
        timer++;
        Iterator<Map.Entry<Element, Gauge>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Gauge g = it.next().getValue();
            g.u -= g.decay;
            if (g.u <= 0.01f) it.remove();
        }
        if (quickenTicks > 0) quickenTicks--;
        if (burningTicks > 0) burningTicks--;
        if (!(has(Element.ELECTRO) && has(Element.HYDRO))) lunarCharged = false;
    }
}
