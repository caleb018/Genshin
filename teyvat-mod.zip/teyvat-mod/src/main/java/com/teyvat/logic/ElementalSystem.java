package com.teyvat.logic;

import com.teyvat.Balance;
import com.teyvat.Element;
import com.teyvat.entity.DendroCoreEntity;
import com.teyvat.entity.MoondriftEntity;
import com.teyvat.registry.ModAttachments;
import com.teyvat.registry.ModDamage;
import com.teyvat.registry.ModEffects;
import com.teyvat.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Motor de elementos: aplicacao de aura (gauge units) e reacoes.
 * Regras baseadas no jogo original, simplificadas para Minecraft.
 */
public final class ElementalSystem {
    private ElementalSystem() {}

    // ------------------------------------------------------------------ utilidades
    public static ElementalAura aura(LivingEntity e) {
        return e.getData(ModAttachments.AURA);
    }

    public static boolean canHit(@Nullable LivingEntity src, LivingEntity t) {
        if (!t.isAlive() || t == src || t instanceof ArmorStand) return false;
        if (t instanceof TamableAnimal ta && src != null && ta.isOwnedBy(src)) return false;
        if (t instanceof Player) {
            return t.level().getServer() != null && t.level().getServer().isPvpAllowed();
        }
        return t instanceof Mob;
    }

    public static List<LivingEntity> around(ServerLevel l, @Nullable LivingEntity src, Vec3 c, double r) {
        return l.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r),
                e -> canHit(src, e) && e.distanceToSqr(c) <= r * r);
    }

    /** Dano elemental (ignora armadura, nao reaplica elementos). */
    public static void deal(LivingEntity t, @Nullable LivingEntity src, Element el, float dmg) {
        if (!(t.level() instanceof ServerLevel lv)) return;
        var holder = lv.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ModDamage.ELEMENTAL);
        DamageSource ds = new DamageSource(holder, src, src);
        t.invulnerableTime = 0;
        t.hurt(ds, dmg);
        lv.sendParticles(el.dust(1.0f), t.getX(), t.getY() + t.getBbHeight() / 2, t.getZ(), 6, .3, .4, .3, 0.02);
    }

    private static void popup(@Nullable LivingEntity src, String key, Element el) {
        if (src instanceof ServerPlayer sp) {
            sp.displayClientMessage(Component.translatable("reaction.teyvat." + key).withStyle(s -> s.withColor(el.rgb)), true);
        }
    }

    private static void burst(ServerLevel lv, Vec3 p, Element a, Element b, int n) {
        lv.sendParticles(a.dust(1.4f), p.x, p.y, p.z, n, .5, .5, .5, 0.05);
        if (b != null) lv.sendParticles(b.dust(1.4f), p.x, p.y, p.z, n, .5, .5, .5, 0.05);
        lv.sendParticles(a.accent(), p.x, p.y, p.z, n / 2, .4, .4, .4, 0.05);
    }

    // ------------------------------------------------------------------ aplicacao
    /**
     * Aplica um elemento (units em U) e dispara reacoes.
     * @return multiplicador de dano para o golpe que causou a aplicacao (Vaporizar/Derreter/Intensificar...).
     */
    public static float apply(LivingEntity t, @Nullable LivingEntity src, Element el, float units) {
        if (!(t.level() instanceof ServerLevel lv)) return 1f;
        ElementalAura a = aura(t);
        Player player = src instanceof Player p ? p : null;
        boolean lunar = player != null && PlayerElements.hasLunarDisc(player);
        boolean stellar = player != null && PlayerElements.hasStellarAxis(player);
        Vec3 pos = t.position().add(0, t.getBbHeight() * 0.5, 0);
        float mult = 1f;
        boolean reacted = false;

        // Estilhacar: Geo em alvo congelado
        if (el == Element.GEO && t.hasEffect(ModEffects.FROZEN)) {
            t.removeEffect(ModEffects.FROZEN);
            mult *= 1.8f;
            popup(src, "shatter", Element.CRYO);
            burst(lv, pos, Element.CRYO, Element.GEO, 20);
            lv.playSound(null, t.getX(), t.getY(), t.getZ(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 1f, 0.8f);
        }
        // Intensificado: bonus de Agravar / Propagar
        if (a.quickenTicks > 0 && (el == Element.ELECTRO || el == Element.DENDRO)) {
            mult *= el == Element.ELECTRO ? 1.4f : 1.25f;
            burst(lv, pos, Element.DENDRO, Element.ELECTRO, 8);
        }

        switch (el) {
            case PYRO -> {
                if (a.has(Element.CRYO)) {
                    mult *= 2f; a.consume(Element.CRYO, units * 0.5f); reacted = true; popup(src, "melt", el);
                    burst(lv, pos, Element.PYRO, Element.CRYO, 14);
                } else if (a.has(Element.HYDRO)) {
                    mult *= 1.5f; a.consume(Element.HYDRO, units * 2f); reacted = true; popup(src, "vaporize", el);
                    lv.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, 12, .4, .4, .4, 0.05);
                } else if (a.has(Element.ELECTRO)) {
                    a.consume(Element.ELECTRO, units); reacted = true; overloaded(lv, t, src, pos);
                } else if (a.has(Element.DENDRO)) {
                    a.burningTicks = 100; popup(src, "burning", el); // coexistem; Pyro entra como aura
                }
            }
            case HYDRO -> {
                if (a.has(Element.PYRO)) {
                    mult *= 2f; a.consume(Element.PYRO, units * 0.5f); reacted = true; popup(src, "vaporize", el);
                    lv.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, 12, .4, .4, .4, 0.05);
                } else if (a.has(Element.CRYO)) {
                    reacted = freeze(lv, t, src, a, Element.HYDRO, units, pos);
                } else if (a.has(Element.DENDRO)) {
                    a.consume(Element.DENDRO, units); reacted = true; bloom(lv, t, src, lunar, pos);
                } else if (a.has(Element.ELECTRO)) {
                    a.lunarCharged = lunar; // coexistem; ticks causam dano
                    popup(src, lunar ? "lunar_charged" : "electro_charged", lunar ? Element.ELECTRO : Element.HYDRO);
                }
            }
            case CRYO -> {
                if (a.has(Element.PYRO)) {
                    mult *= 1.5f; a.consume(Element.PYRO, units * 2f); reacted = true; popup(src, "melt", el);
                    burst(lv, pos, Element.PYRO, Element.CRYO, 14);
                } else if (a.has(Element.HYDRO)) {
                    reacted = freeze(lv, t, src, a, Element.CRYO, units, pos);
                } else if (a.has(Element.ELECTRO)) {
                    a.consume(Element.ELECTRO, units); reacted = true; superconduct(lv, t, src, pos);
                }
            }
            case ELECTRO -> {
                if (a.has(Element.PYRO)) {
                    a.consume(Element.PYRO, units); reacted = true; overloaded(lv, t, src, pos);
                } else if (a.has(Element.CRYO)) {
                    a.consume(Element.CRYO, units); reacted = true; superconduct(lv, t, src, pos);
                } else if (a.has(Element.HYDRO)) {
                    a.lunarCharged = lunar;
                    popup(src, lunar ? "lunar_charged" : "electro_charged", lunar ? Element.ELECTRO : Element.HYDRO);
                } else if (a.has(Element.DENDRO)) {
                    a.consume(Element.DENDRO, units * 0.5f); reacted = true;
                    a.quickenTicks = 120; popup(src, "quicken", Element.DENDRO);
                    burst(lv, pos, Element.DENDRO, Element.ELECTRO, 10);
                }
            }
            case DENDRO -> {
                if (a.has(Element.HYDRO)) {
                    a.consume(Element.HYDRO, units); reacted = true; bloom(lv, t, src, lunar, pos);
                } else if (a.has(Element.ELECTRO)) {
                    a.consume(Element.ELECTRO, units * 0.5f); reacted = true;
                    a.quickenTicks = 120; popup(src, "quicken", Element.DENDRO);
                    burst(lv, pos, Element.DENDRO, Element.ELECTRO, 10);
                } else if (a.has(Element.PYRO)) {
                    a.burningTicks = 100; popup(src, "burning", Element.PYRO);
                }
            }
            case ANEMO -> {
                for (Element x : new Element[]{Element.PYRO, Element.HYDRO, Element.ELECTRO, Element.CRYO}) {
                    if (a.has(x)) {
                        a.consume(x, units * 0.5f);
                        reacted = true;
                        swirl(lv, t, src, x, stellar && x == Element.CRYO, pos);
                        break;
                    }
                }
            }
            case GEO -> {
                for (Element x : new Element[]{Element.PYRO, Element.HYDRO, Element.ELECTRO, Element.CRYO}) {
                    if (a.has(x)) {
                        a.consume(x, units * 0.5f);
                        reacted = true;
                        crystallize(lv, t, src, x, lunar && x == Element.HYDRO, pos);
                        break;
                    }
                }
            }
        }

        if (!reacted && el.canAura) a.add(el, units);
        coreReact(lv, t, src, el);
        syncEffects(t, a);
        return mult;
    }

    // ------------------------------------------------------------------ reacoes
    private static void overloaded(ServerLevel lv, LivingEntity t, @Nullable LivingEntity src, Vec3 pos) {
        popup(src, "overloaded", Element.PYRO);
        lv.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 2, .3, .3, .3, 0);
        burst(lv, pos, Element.PYRO, Element.ELECTRO, 20);
        lv.playSound(null, pos.x, pos.y, pos.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, .7f, 1.4f);
        for (LivingEntity e : around(lv, src, pos, 3.0)) {
            deal(e, src, Element.PYRO, Balance.REACTION);
            e.knockback(0.8, pos.x - e.getX(), pos.z - e.getZ());
        }
    }

    private static void superconduct(ServerLevel lv, LivingEntity t, @Nullable LivingEntity src, Vec3 pos) {
        popup(src, "superconduct", Element.CRYO);
        burst(lv, pos, Element.CRYO, Element.ELECTRO, 24);
        lv.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, .8f, 1.5f);
        for (LivingEntity e : around(lv, src, pos, 4.0)) {
            deal(e, src, Element.CRYO, Balance.REACTION * 0.5f);
            e.addEffect(new MobEffectInstance(ModEffects.SUPERCONDUCT, 240, 0, false, true, true));
        }
    }

    private static boolean freeze(ServerLevel lv, LivingEntity t, @Nullable LivingEntity src, ElementalAura a,
                                  Element trigger, float units, Vec3 pos) {
        Element other = trigger == Element.HYDRO ? Element.CRYO : Element.HYDRO;
        float g = units * 0.8f;
        float m = Math.min(a.get(other), g);
        a.consume(other, m);
        float left = g - m;
        if (left > 0.05f) a.add(trigger, left / 0.8f);
        float sec = Math.max(1f, 2f * (float) Math.sqrt(5f * m + 4f) - 4f);
        t.addEffect(new MobEffectInstance(ModEffects.FROZEN, (int) (sec * 20), 0, false, true, true));
        popup(src, "frozen", Element.CRYO);
        burst(lv, pos, Element.CRYO, Element.HYDRO, 18);
        lv.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, .6f, 1.9f);
        return true;
    }

    private static void swirl(ServerLevel lv, LivingEntity t, @Nullable LivingEntity src, Element spread,
                              boolean stellar, Vec3 pos) {
        double r = stellar ? 5.0 : 3.5;
        popup(src, stellar ? "stellar_swirl" : "swirl", Element.ANEMO);
        burst(lv, pos, Element.ANEMO, spread, 22);
        lv.playSound(null, pos.x, pos.y, pos.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1f, 0.7f);
        for (LivingEntity e : around(lv, src, pos, r)) {
            deal(e, src, Element.ANEMO, Balance.REACTION * 0.6f);
            Vec3 pull = pos.subtract(e.position()).normalize().scale(stellar ? 0.7 : 0.35);
            e.push(pull.x, 0.15, pull.z);
            e.hurtMarked = true;
            if (e != t) apply(e, src, spread, 0.5f); // espalha o elemento
        }
        if (stellar) {
            // Vortice Estelar: puxa e detona depois de ~1.2s
            var server = lv.getServer();
            server.tell(new TickTask(server.getTickCount() + 24, () -> {
                burst(lv, pos, Element.ANEMO, Element.CRYO, 40);
                lv.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 1.2f, 0.6f);
                for (LivingEntity e : around(lv, src, pos, r)) {
                    deal(e, src, Element.CRYO, Balance.REACTION * 1.4f);
                }
            }));
        }
    }

    private static void crystallize(ServerLevel lv, LivingEntity t, @Nullable LivingEntity src, Element on,
                                    boolean lunar, Vec3 pos) {
        if (lunar) {
            lunarCrystallize(lv, t, src, pos);
            return;
        }
        popup(src, "crystallize", Element.GEO);
        burst(lv, pos, Element.GEO, on, 16);
        lv.playSound(null, pos.x, pos.y, pos.z, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1f, 1.2f);
        if (src != null) {
            src.setAbsorptionAmount(Math.min(10f, src.getAbsorptionAmount() + 4f)); // escudo elemental
        }
    }

    private static void lunarCrystallize(ServerLevel lv, LivingEntity t, @Nullable LivingEntity src, Vec3 pos) {
        popup(src, "lunar_crystallize", Element.GEO);
        lv.playSound(null, pos.x, pos.y, pos.z, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.5f, 0.8f);
        // reaproveita Moondrift existente do mesmo dono perto daqui (maximo 2)
        int count = 0;
        for (MoondriftEntity m : lv.getEntitiesOfClass(MoondriftEntity.class, new AABB(pos, pos).inflate(10))) {
            if (src != null && src.getUUID().equals(m.ownerId())) {
                count++;
                m.refresh();
            }
        }
        if (count >= 2) return;
        MoondriftEntity m = new MoondriftEntity(ModEntities.MOONDRIFT.get(), lv);
        m.setPos(t.getX(), t.getY(), t.getZ());
        m.setOwner(src);
        lv.addFreshEntity(m);
    }

    private static void bloom(ServerLevel lv, LivingEntity t, @Nullable LivingEntity src, boolean lunar, Vec3 pos) {
        if (lunar) {
            popup(src, "lunar_bloom", Element.DENDRO);
            lv.sendParticles(ParticleTypes.END_ROD, pos.x, pos.y, pos.z, 30, 1, .6, 1, 0.05);
            burst(lv, pos, Element.DENDRO, Element.GEO, 24);
            lv.playSound(null, pos.x, pos.y, pos.z, SoundEvents.AMETHYST_CLUSTER_BREAK, SoundSource.PLAYERS, 1f, 1.1f);
            for (LivingEntity e : around(lv, src, pos, 3.5)) {
                deal(e, src, Element.DENDRO, Balance.REACTION * 1.3f);
            }
            return;
        }
        popup(src, "bloom", Element.DENDRO);
        int cores = lv.getEntitiesOfClass(DendroCoreEntity.class, new AABB(pos, pos).inflate(12)).size();
        if (cores >= 5) return;
        DendroCoreEntity c = new DendroCoreEntity(ModEntities.DENDRO_CORE.get(), lv);
        c.setPos(t.getX(), t.getY() + 0.3, t.getZ());
        c.setOwner(src);
        lv.addFreshEntity(c);
    }

    private static void coreReact(ServerLevel lv, LivingEntity t, @Nullable LivingEntity src, Element el) {
        if (el != Element.PYRO && el != Element.ELECTRO) return;
        List<DendroCoreEntity> cores = lv.getEntitiesOfClass(DendroCoreEntity.class, t.getBoundingBox().inflate(3));
        for (DendroCoreEntity c : new ArrayList<>(cores)) {
            if (el == Element.PYRO) {
                popup(src, "burgeon", Element.PYRO);
                c.burgeon(src);
            } else {
                popup(src, "hyperbloom", Element.ELECTRO);
                c.hyperbloom(src);
            }
        }
    }

    // ------------------------------------------------------------------ tick de aura (servidor)
    public static void tickAura(LivingEntity e) {
        if (!(e.level() instanceof ServerLevel lv) || !e.hasData(ModAttachments.AURA)) return;
        ElementalAura a = aura(e);
        a.tick();
        Vec3 pos = e.position().add(0, e.getBbHeight() * 0.5, 0);

        // Eletrocarregado / Carga Lunar: pulsos enquanto Electro + Hydro coexistem
        if (a.has(Element.ELECTRO) && a.has(Element.HYDRO) && a.timer % 20 == 0) {
            float dmg = (a.lunarCharged ? 1.2f : 0.8f) * Balance.REACTION * 0.5f;
            double r = a.lunarCharged ? 5.0 : 3.0;
            LivingEntity src = null;
            deal(e, src, Element.ELECTRO, dmg);
            int hits = 0;
            for (LivingEntity n : lv.getEntitiesOfClass(LivingEntity.class, e.getBoundingBox().inflate(r),
                    x -> x != e && canHit(null, x) && (a.lunarCharged || (x.hasData(ModAttachments.AURA) && aura(x).has(Element.HYDRO))))) {
                if (hits++ >= 4) break;
                deal(n, src, Element.ELECTRO, dmg);
                Vec3 b = n.position().add(0, n.getBbHeight() / 2, 0);
                for (int i = 0; i <= 8; i++) {
                    Vec3 p = pos.lerp(b, i / 8.0);
                    lv.sendParticles(a.lunarCharged ? net.minecraft.core.particles.ParticleTypes.END_ROD : net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK,
                            p.x, p.y, p.z, 1, .05, .05, .05, 0);
                }
            }
            a.consume(Element.ELECTRO, 0.1f);
            a.consume(Element.HYDRO, 0.1f);
            lv.playSound(null, pos.x, pos.y, pos.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, .25f, 2f);
        }

        // Queimar
        if (a.burningTicks > 0) {
            if (a.has(Element.PYRO) && a.has(Element.DENDRO)) {
                if (a.timer % 10 == 0) {
                    deal(e, null, Element.PYRO, Balance.REACTION * 0.2f);
                    e.setRemainingFireTicks(30);
                }
                a.consume(Element.DENDRO, 0.01f);
            } else {
                a.burningTicks = 0;
            }
        }

        // particulas de aura
        if (a.timer % 8 == 0) {
            for (Element el : a.map.keySet()) {
                lv.sendParticles(el.dust(0.9f), e.getX(), e.getY() + e.getBbHeight() * 0.6, e.getZ(), 2, e.getBbWidth() * 0.4, e.getBbHeight() * 0.3, e.getBbWidth() * 0.4, 0.0);
            }
        }
        if (a.timer % 20 == 0) syncEffects(e, a);
        if (a.isEmpty()) e.removeData(ModAttachments.AURA);
    }

    /** Mostra as auras como efeitos (aparecem no inventario/HUD e em mods como Jade). */
    private static void syncEffects(LivingEntity e, ElementalAura a) {
        for (Element el : Element.values()) {
            var holder = ModEffects.AURA.get(el);
            if (a.has(el)) {
                e.addEffect(new MobEffectInstance(holder, 45, 0, false, false, true));
            } else if (e.hasEffect(holder)) {
                e.removeEffect(holder);
            }
        }
        if (a.quickenTicks > 0) e.addEffect(new MobEffectInstance(ModEffects.QUICKEN, 45, 0, false, false, true));
    }
}
