package com.teyvat.logic;

import com.teyvat.Balance;
import com.teyvat.Element;
import com.teyvat.Teyvat;
import com.teyvat.registry.ModDamage;
import com.teyvat.registry.ModEffects;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@EventBusSubscriber(modid = Teyvat.MODID)
public final class CommonEvents {
    private static final String ARROW_KEY = "teyvat_el";
    /** ICD por jogador: {contador, ultimo tick}. 1 aplicacao a cada 3 golpes ou 2.5s. */
    private static final Map<UUID, long[]> ICD = new HashMap<>();

    private CommonEvents() {}

    // ------------------------------------------------------------ combate
    @SubscribeEvent
    public static void onIncoming(LivingIncomingDamageEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide) return;
        DamageSource ds = e.getSource();

        if (ds.is(ModDamage.ELEMENTAL)) {
            if (victim.hasEffect(ModEffects.SHRED)) e.setAmount(e.getAmount() * 1.2f);
            return;
        }
        if (!(ds.getEntity() instanceof ServerPlayer p)) return;
        Entity direct = ds.getDirectEntity();
        Element el = null;
        boolean bare = false;

        if (direct == p) {
            el = PlayerElements.imbuedElement(p);
            if (el == null && p.getMainHandItem().isEmpty()) {
                el = PlayerElements.armedElement(p);
                bare = el != null;
            }
        } else if (direct instanceof AbstractArrow arrow && arrow.getPersistentData().contains(ARROW_KEY)) {
            el = Element.byIndex(arrow.getPersistentData().getInt(ARROW_KEY));
        }
        if (el == null) return;

        long now = p.level().getGameTime();
        long[] icd = ICD.computeIfAbsent(p.getUUID(), k -> new long[]{0, -1000});
        boolean allow = (icd[0] % 3 == 0) || (now - icd[1] >= 50);
        if (now - icd[1] > 100) icd[0] = 0;
        icd[0]++;
        float mult = 1f;
        if (allow) {
            icd[1] = now;
            mult = ElementalSystem.apply(victim, p, el, 1f);
        }

        float amount = e.getAmount();
        if (bare) amount += Balance.REACTION * 0.4f;                 // punhos elementais
        amount *= Balance.IMBUE_BONUS * mult;
        if (bare && el == Element.PYRO && p.getHealth() <= p.getMaxHealth() * 0.5f) amount *= 1.3f; // Hu Tao

        // Vesna: Pena Espiritual a cada golpe
        if (el == Element.ANEMO && PlayerElements.armedElement(p) == Element.ANEMO) {
            ElementalSystem.deal(victim, p, Element.ANEMO, Balance.REACTION * 0.25f);
            int might = PlayerElements.getInt(p, "might");
            if (might < 3) PlayerElements.setInt(p, "might", might + 1);
        }
        e.setAmount(amount);

        ServerLevel lv = (ServerLevel) victim.level();
        double y = victim.getY() + victim.getBbHeight() / 2;
        lv.sendParticles(el.dust(1.4f), victim.getX(), y, victim.getZ(), 12, .35, .4, .35, 0.06);
        lv.sendParticles(el.accent(), victim.getX(), y, victim.getZ(), 6, .3, .3, .3, 0.05);
        lv.playSound(null, victim.getX(), victim.getY(), victim.getZ(), el.hitSound(), SoundSource.PLAYERS, .6f, 1.3f);
    }

    // ------------------------------------------------------------ flechas
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide) return;
        if (e.getEntity() instanceof AbstractArrow arrow && arrow.getOwner() instanceof ServerPlayer p) {
            if (PlayerElements.imbueActive(p) && PlayerElements.isImbueWeapon(p.getMainHandItem())) {
                CompoundTag t = PlayerElements.tag(p);
                arrow.getPersistentData().putInt(ARROW_KEY, t.getInt("imbueEl"));
            }
        }
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post e) {
        Entity en = e.getEntity();
        if (en.level().isClientSide) return;
        if (en instanceof LivingEntity le) {
            ElementalSystem.tickAura(le);
        } else if (en instanceof AbstractArrow arrow && arrow.getPersistentData().contains(ARROW_KEY)) {
            Element el = Element.byIndex(arrow.getPersistentData().getInt(ARROW_KEY));
            ((ServerLevel) en.level()).sendParticles(el.dust(1.1f), arrow.getX(), arrow.getY(), arrow.getZ(), 2, .05, .05, .05, 0);
            ((ServerLevel) en.level()).sendParticles(el.accent(), arrow.getX(), arrow.getY(), arrow.getZ(), 1, .05, .05, .05, 0);
        }
    }

    // ------------------------------------------------------------ jogador
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post e) {
        if (e.getEntity() instanceof ServerPlayer p && p.tickCount % 10 == 0) {
            PlayerElements.sync(p, false);
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        CompoundTag old = e.getOriginal().getPersistentData();
        if (old.contains("teyvat", 10)) {
            CompoundTag copy = old.getCompound("teyvat").copy();
            // estados temporarios nao sobrevivem a morte
            copy.remove("imbueEnd");
            copy.remove("armEnd");
            e.getEntity().getPersistentData().put("teyvat", copy);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) PlayerElements.sync(p, true);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        PlayerElements.forget(e.getEntity().getUUID());
        ICD.remove(e.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking e) {
        if (e.getTarget() instanceof ServerPlayer target && e.getEntity() instanceof ServerPlayer watcher) {
            PacketDistributor.sendToPlayer(watcher, PlayerElements.payload(target));
        }
    }

    // ------------------------------------------------------------ servidor
    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post e) {
        FieldManager.tick(e.getServer());
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent e) {
        FieldManager.clear();
        ICD.clear();
    }
}
