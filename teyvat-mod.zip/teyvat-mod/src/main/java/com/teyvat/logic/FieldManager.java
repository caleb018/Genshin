package com.teyvat.logic;

import com.teyvat.Balance;
import com.teyvat.Element;
import com.teyvat.registry.ModEffects;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** Campos temporarios de habilidades: Santuario (Lauma) e Cancao (Vodyanitsa). */
public final class FieldManager {
    public enum Kind { SANCTUARY, SONG }

    private static final class Field {
        ServerLevel level;
        Vec3 pos;
        UUID owner;
        Kind kind;
        long end;
        double radius;
    }

    private static final List<Field> FIELDS = new ArrayList<>();

    private FieldManager() {}

    public static void add(ServerLevel lv, Vec3 pos, LivingEntity owner, Kind kind, int ticks, double radius) {
        Field f = new Field();
        f.level = lv; f.pos = pos; f.owner = owner.getUUID(); f.kind = kind;
        f.end = lv.getGameTime() + ticks; f.radius = radius;
        FIELDS.add(f);
    }

    public static void clear() { FIELDS.clear(); }

    public static void tick(MinecraftServer server) {
        Iterator<Field> it = FIELDS.iterator();
        while (it.hasNext()) {
            Field f = it.next();
            long now = f.level.getGameTime();
            LivingEntity owner = f.level.getEntity(f.owner) instanceof LivingEntity le ? le : null;
            if (now >= f.end || owner == null || !owner.isAlive()) { it.remove(); continue; }
            Vec3 c = f.kind == Kind.SONG ? owner.position() : f.pos;
            Element el = f.kind == Kind.SONG ? Element.HYDRO : Element.DENDRO;

            // anel visual
            if (now % 3 == 0) {
                double a = (now * 0.15) % (Math.PI * 2);
                for (int i = 0; i < 4; i++) {
                    double ang = a + i * Math.PI / 2;
                    f.level.sendParticles(el.dust(1.3f), c.x + Math.cos(ang) * f.radius, c.y + 0.1, c.z + Math.sin(ang) * f.radius, 1, 0, 0, 0, 0);
                }
                f.level.sendParticles(f.kind == Kind.SONG ? ParticleTypes.NOTE : ParticleTypes.END_ROD, c.x, c.y + 1.5, c.z, 1, .6, .4, .6, 0);
            }

            if (now % 20 == 0) {
                if (f.kind == Kind.SANCTUARY) {
                    for (LivingEntity e : ElementalSystem.around(f.level, owner, c, f.radius)) {
                        ElementalSystem.apply(e, owner, Element.DENDRO, 1f);
                        ElementalSystem.deal(e, owner, Element.DENDRO, Balance.REACTION * 0.3f);
                        e.addEffect(new MobEffectInstance(ModEffects.SHRED, 200, 0, false, true, true));
                    }
                } else {
                    owner.heal(1.5f);
                    if (now % 40 == 0) {
                        LivingEntity best = null;
                        double bd = Double.MAX_VALUE;
                        for (LivingEntity e : ElementalSystem.around(f.level, owner, c, 8.0)) {
                            double d = e.distanceToSqr(c);
                            if (d < bd) { bd = d; best = e; }
                        }
                        if (best != null) {
                            ElementalSystem.apply(best, owner, Element.HYDRO, 1f);
                            ElementalSystem.deal(best, owner, Element.HYDRO, Balance.REACTION * 0.5f);
                            best.addEffect(new MobEffectInstance(ModEffects.SHRED, 200, 0, false, true, true));
                            f.level.sendParticles(ParticleTypes.NOTE, best.getX(), best.getY() + best.getBbHeight() + .3, best.getZ(), 4, .3, .2, .3, 1);
                        }
                    }
                }
            }
        }
    }
}
