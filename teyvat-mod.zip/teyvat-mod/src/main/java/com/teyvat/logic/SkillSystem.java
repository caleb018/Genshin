package com.teyvat.logic;

import com.teyvat.Balance;
import com.teyvat.Element;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Habilidade elemental.
 *  - Arma na mao (espada, machado, tridente, arco): imbui a arma com o elemento.
 *  - Mao vazia: habilidade inspirada em personagens, uma por elemento:
 *      PYRO Hu Tao | HYDRO Vodyanitsa | ANEMO Vesna | ELECTRO Clorinde | DENDRO Lauma | CRYO Eula | GEO Xilonen
 */
public final class SkillSystem {
    private SkillSystem() {}

    public static void cast(ServerPlayer p) {
        if (!PlayerElements.hasVision(p)) {
            p.displayClientMessage(Component.translatable("message.teyvat.no_vision"), true);
            return;
        }
        Element el = PlayerElements.getSelected(p);
        long now = p.level().getGameTime();
        boolean empty = p.getMainHandItem().isEmpty();

        // Vesna: segundo toque durante o Armamento = Espada dos Ventos
        if (empty && el == Element.ANEMO && PlayerElements.armedElement(p) == Element.ANEMO
                && PlayerElements.getInt(p, "might") > 0) {
            windborneSword(p);
            return;
        }

        long cd = PlayerElements.cooldownEnd(p, el);
        if (now < cd) {
            p.displayClientMessage(Component.translatable("message.teyvat.cooldown", String.format("%.1f", (cd - now) / 20.0)), true);
            return;
        }

        if (PlayerElements.isImbueWeapon(p.getMainHandItem())) {
            PlayerElements.imbue(p, el, Balance.IMBUE_TICKS);
            PlayerElements.setCooldown(p, el, Balance.IMBUE_COOLDOWN);
            ServerLevel lv = p.serverLevel();
            lv.sendParticles(el.dust(1.6f), p.getX(), p.getY() + 1, p.getZ(), 30, .6, .6, .6, .05);
            lv.sendParticles(el.accent(), p.getX(), p.getY() + 1, p.getZ(), 12, .5, .5, .5, .05);
            lv.playSound(null, p.blockPosition(), el.hitSound(), SoundSource.PLAYERS, 1f, 1.2f);
            p.displayClientMessage(Component.translatable("message.teyvat.imbue", el.displayName()), true);
        } else if (empty) {
            switch (el) {
                case PYRO -> huTao(p);
                case HYDRO -> vodyanitsa(p);
                case ANEMO -> vesna(p);
                case ELECTRO -> clorinde(p);
                case DENDRO -> lauma(p);
                case CRYO -> eula(p);
                case GEO -> xilonen(p);
            }
            PlayerElements.setCooldown(p, el, Balance.SKILL_COOLDOWN[el.ordinal()]);
        } else {
            p.displayClientMessage(Component.translatable("message.teyvat.bad_item"), true);
            return;
        }
        PlayerElements.sync(p, true);
    }

    // ------------------------------------------------------------------ Hu Tao (Pyro)
    private static void huTao(ServerPlayer p) {
        // Guide to Afterlife / Paramita Papilio: troca HP por um estado de punhos em chamas
        float cost = Math.min(p.getHealth() * 0.3f, Math.max(0f, p.getHealth() - 2f));
        p.setHealth(p.getHealth() - cost);
        PlayerElements.arm(p, Element.PYRO, 20 * 9);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 9, 0, false, false, true));
        ServerLevel lv = p.serverLevel();
        lv.sendParticles(Element.PYRO.dust(2f), p.getX(), p.getY() + 1, p.getZ(), 40, .7, .8, .7, .08);
        lv.sendParticles(ParticleTypes.FLAME, p.getX(), p.getY() + 1, p.getZ(), 25, .6, .8, .6, .06);
        lv.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1f, 0.8f);
    }

    // ------------------------------------------------------------------ Vodyanitsa (Hydro)
    private static void vodyanitsa(ServerPlayer p) {
        ServerLevel lv = p.serverLevel();
        Vec3 c = p.position();
        lv.sendParticles(Element.HYDRO.dust(2f), c.x, c.y + .5, c.z, 60, 2.5, .3, 2.5, .05);
        lv.sendParticles(ParticleTypes.SPLASH, c.x, c.y + .5, c.z, 60, 2.5, .3, 2.5, .2);
        lv.playSound(null, p.blockPosition(), SoundEvents.PLAYER_SPLASH, SoundSource.PLAYERS, 1.2f, 0.9f);
        for (LivingEntity e : ElementalSystem.around(lv, p, c, 5.0)) {
            float m = ElementalSystem.apply(e, p, Element.HYDRO, 2f);
            ElementalSystem.deal(e, p, Element.HYDRO, Balance.REACTION * 0.8f * m);
        }
        // Cancao das Eras Passadas: microfones atacam e curam
        FieldManager.add(lv, c, p, FieldManager.Kind.SONG, 20 * 12, 4.0);
    }

    // ------------------------------------------------------------------ Vesna (Anemo)
    private static void vesna(ServerPlayer p) {
        ServerLevel lv = p.serverLevel();
        Vec3 c = p.position();
        lv.sendParticles(Element.ANEMO.dust(2f), c.x, c.y + 1, c.z, 50, 2, .8, 2, .1);
        lv.sendParticles(ParticleTypes.CLOUD, c.x, c.y + .5, c.z, 30, 2, .3, 2, .1);
        lv.playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.3f, 0.6f);
        for (LivingEntity e : ElementalSystem.around(lv, p, c, 4.0)) {
            float m = ElementalSystem.apply(e, p, Element.ANEMO, 1f);
            ElementalSystem.deal(e, p, Element.ANEMO, Balance.REACTION * 0.7f * m);
        }
        PlayerElements.arm(p, Element.ANEMO, 20 * 15);
        PlayerElements.setInt(p, "might", 2);
    }

    private static void windborneSword(ServerPlayer p) {
        int stage = Math.min(3, PlayerElements.getInt(p, "stage") + 1);
        PlayerElements.setInt(p, "stage", stage);
        PlayerElements.setInt(p, "might", PlayerElements.getInt(p, "might") - 1);
        float mult = 0.8f + 0.6f * stage;
        ServerLevel lv = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 start = p.getEyePosition();
        for (int i = 1; i <= 8; i++) {
            Vec3 pt = start.add(look.scale(i * 0.8));
            lv.sendParticles(Element.ANEMO.dust(1.5f), pt.x, pt.y, pt.z, 3, .3, .3, .3, 0);
            lv.sendParticles(ParticleTypes.SWEEP_ATTACK, pt.x, pt.y, pt.z, 1, 0, 0, 0, 0);
        }
        lv.playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.2f, 0.5f + stage * 0.2f);
        for (LivingEntity e : inLine(lv, p, 6.5, 1.6)) {
            float m = ElementalSystem.apply(e, p, Element.ANEMO, 1f);
            ElementalSystem.deal(e, p, Element.ANEMO, Balance.REACTION * mult * m);
        }
        PlayerElements.sync(p, true);
    }

    // ------------------------------------------------------------------ Clorinde (Electro)
    private static void clorinde(ServerPlayer p) {
        // Vinculo de Vida: gasta um pouco de HP para o golpe do investida
        float cost = Math.min(p.getHealth() * 0.1f, Math.max(0f, p.getHealth() - 4f));
        p.setHealth(p.getHealth() - cost);
        ServerLevel lv = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z).normalize();
        for (LivingEntity e : inLine(lv, p, 7.0, 1.7)) {
            float m = ElementalSystem.apply(e, p, Element.ELECTRO, 1f);
            ElementalSystem.deal(e, p, Element.ELECTRO, Balance.REACTION * 1.2f * m);
        }
        for (int i = 0; i <= 14; i++) {
            Vec3 pt = p.position().add(flat.scale(i * 0.5)).add(0, 1, 0);
            lv.sendParticles(Element.ELECTRO.dust(1.4f), pt.x, pt.y, pt.z, 2, .2, .4, .2, 0);
            lv.sendParticles(ParticleTypes.ELECTRIC_SPARK, pt.x, pt.y, pt.z, 2, .2, .4, .2, .05);
        }
        p.setDeltaMovement(flat.x * 2.0, 0.15, flat.z * 2.0);
        p.hurtMarked = true;
        lv.playSound(null, p.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, .6f, 1.8f);
        PlayerElements.arm(p, Element.ELECTRO, 20 * 4);
    }

    // ------------------------------------------------------------------ Lauma (Dendro)
    private static void lauma(ServerPlayer p) {
        ServerLevel lv = p.serverLevel();
        Vec3 c = p.position();
        lv.sendParticles(Element.DENDRO.dust(2f), c.x, c.y + .3, c.z, 50, 2.5, .2, 2.5, .05);
        lv.sendParticles(ParticleTypes.END_ROD, c.x, c.y + 1, c.z, 20, 2, .8, 2, .02);
        lv.playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.2f, 0.6f);
        // Santuario Frostgrove: aplica Dendro e reduz resistencias por 10s
        FieldManager.add(lv, c, p, FieldManager.Kind.SANCTUARY, 20 * 10, 5.0);
    }

    // ------------------------------------------------------------------ Eula (Cryo)
    private static void eula(ServerPlayer p) {
        ServerLevel lv = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z).normalize();
        Vec3 c = p.position();
        for (LivingEntity e : ElementalSystem.around(lv, p, c.add(flat.scale(1.5)), 4.0)) {
            Vec3 to = e.position().subtract(c).multiply(1, 0, 1).normalize();
            if (to.dot(flat) < 0.2) continue;
            float m = ElementalSystem.apply(e, p, Element.CRYO, 2f);
            ElementalSystem.deal(e, p, Element.CRYO, Balance.REACTION * 1.0f * m);
        }
        for (int i = -6; i <= 6; i++) {
            double ang = Math.atan2(flat.z, flat.x) + i * 0.16;
            for (int r = 1; r <= 4; r++) {
                lv.sendParticles(Element.CRYO.dust(1.3f), c.x + Math.cos(ang) * r, c.y + 1, c.z + Math.sin(ang) * r, 1, 0, .1, 0, 0);
            }
        }
        lv.sendParticles(ParticleTypes.SNOWFLAKE, c.x + flat.x * 2, c.y + 1, c.z + flat.z * 2, 25, 1.5, .5, 1.5, .05);
        lv.playSound(null, p.blockPosition(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 1f, 1.4f);
        // Coracao Sombrio: escudo temporario
        p.setAbsorptionAmount(Math.min(8f, p.getAbsorptionAmount() + 4f));
    }

    // ------------------------------------------------------------------ Xilonen (Geo)
    private static void xilonen(ServerPlayer p) {
        ServerLevel lv = p.serverLevel();
        Vec3 c = p.position();
        lv.sendParticles(Element.GEO.dust(2f), c.x, c.y + .3, c.z, 50, 2, .2, 2, .05);
        lv.playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.3f, 0.5f);
        for (LivingEntity e : ElementalSystem.around(lv, p, c, 4.0)) {
            float m = ElementalSystem.apply(e, p, Element.GEO, 1f);
            ElementalSystem.deal(e, p, Element.GEO, Balance.REACTION * 0.9f * m);
        }
        // Alma Noturna: patinacao veloz + escudo geo
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 8, 1, false, false, true));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 8, 0, false, false, true));
        p.setAbsorptionAmount(Math.min(10f, p.getAbsorptionAmount() + 6f));
        PlayerElements.arm(p, Element.GEO, 20 * 8);
    }

    // ------------------------------------------------------------------ util
    private static List<LivingEntity> inLine(ServerLevel lv, ServerPlayer p, double len, double width) {
        Vec3 look = p.getLookAngle();
        Vec3 from = p.getEyePosition();
        Vec3 mid = from.add(look.scale(len / 2));
        return lv.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(mid, mid).inflate(len / 2 + width),
                e -> {
                    if (!ElementalSystem.canHit(p, e)) return false;
                    Vec3 c = e.position().add(0, e.getBbHeight() / 2, 0).subtract(from);
                    double along = c.dot(look);
                    if (along < -0.5 || along > len) return false;
                    return c.subtract(look.scale(along)).length() <= width;
                });
    }
}
