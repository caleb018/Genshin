package com.teyvat.logic;

import com.teyvat.Element;
import com.teyvat.net.SyncElementPayload;
import com.teyvat.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.network.PacketDistributor;
import top.theillusivec4.curios.api.CuriosApi;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Estado elemental do jogador (servidor). Persistido em getPersistentData(). */
public final class PlayerElements {
    private static final String KEY = "teyvat";
    private static final Map<UUID, Integer> LAST_SYNC = new HashMap<>();

    private PlayerElements() {}

    public static CompoundTag tag(Player p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(KEY, 10)) root.put(KEY, new CompoundTag());
        return root.getCompound(KEY);
    }

    // ---------------------------------------------------------- equipamento (Curios)
    private static boolean has(Player p, Item item) {
        return CuriosApi.getCuriosInventory(p).map(h -> h.findFirstCurio(item).isPresent()).orElse(false);
    }

    public static boolean hasVision(Player p) { return has(p, ModItems.VISION.get()); }
    public static boolean hasStellarAxis(Player p) { return has(p, ModItems.STELLAR_AXIS.get()); }
    public static boolean hasLunarDisc(Player p) { return has(p, ModItems.LUNAR_DISC.get()); }

    // ---------------------------------------------------------- selecao
    public static Element getSelected(Player p) { return Element.byIndex(tag(p).getInt("sel")); }

    public static void select(ServerPlayer p, int idx) {
        if (!hasVision(p)) return;
        tag(p).putInt("sel", Math.floorMod(idx, Element.values().length));
        sync(p, true);
    }

    public static void cycle(ServerPlayer p, int dir) {
        select(p, getSelected(p).ordinal() + (dir >= 0 ? 1 : -1));
    }

    // ---------------------------------------------------------- cooldown / estados
    public static long cooldownEnd(Player p, Element e) { return tag(p).getLong("cd" + e.ordinal()); }

    public static void setCooldown(Player p, Element e, int ticks) {
        tag(p).putLong("cd" + e.ordinal(), p.level().getGameTime() + ticks);
    }

    public static void imbue(Player p, Element e, int ticks) {
        CompoundTag t = tag(p);
        t.putLong("imbueEnd", p.level().getGameTime() + ticks);
        t.putInt("imbueEl", e.ordinal());
    }

    public static boolean isImbueWeapon(ItemStack s) {
        Item i = s.getItem();
        return i instanceof SwordItem || i instanceof AxeItem || i instanceof TridentItem || i instanceof BowItem;
    }

    /** Elemento da imbuicao ativa (so vale com arma imbuivel na mao). */
    public static Element imbuedElement(Player p) {
        CompoundTag t = tag(p);
        if (p.level().getGameTime() < t.getLong("imbueEnd") && isImbueWeapon(p.getMainHandItem())) {
            return Element.byIndex(t.getInt("imbueEl"));
        }
        return null;
    }

    public static boolean imbueActive(Player p) {
        return p.level().getGameTime() < tag(p).getLong("imbueEnd");
    }

    public static void arm(Player p, Element e, int ticks) {
        CompoundTag t = tag(p);
        t.putLong("armEnd", p.level().getGameTime() + ticks);
        t.putInt("armEl", e.ordinal());
        t.putInt("might", 0);
        t.putInt("stage", 0);
    }

    public static Element armedElement(Player p) {
        CompoundTag t = tag(p);
        if (p.level().getGameTime() < t.getLong("armEnd")) return Element.byIndex(t.getInt("armEl"));
        return null;
    }

    public static int getInt(Player p, String k) { return tag(p).getInt(k); }
    public static void setInt(Player p, String k, int v) { tag(p).putInt(k, v); }

    // ---------------------------------------------------------- sync
    public static SyncElementPayload payload(ServerPlayer p) {
        int flags = 0;
        boolean vision = hasVision(p);
        if (vision) flags |= SyncElementPayload.F_VISION;
        if (imbueActive(p)) flags |= SyncElementPayload.F_IMBUE;
        if (armedElement(p) != null) flags |= SyncElementPayload.F_ARMED;
        if (hasLunarDisc(p)) flags |= SyncElementPayload.F_LUNAR;
        if (hasStellarAxis(p)) flags |= SyncElementPayload.F_AXIS;
        return new SyncElementPayload(p.getUUID(), getSelected(p).ordinal(), flags);
    }

    public static void sync(ServerPlayer p, boolean force) {
        SyncElementPayload pl = payload(p);
        int hash = pl.element() * 64 + pl.flags();
        Integer last = LAST_SYNC.get(p.getUUID());
        if (!force && last != null && last == hash) return;
        LAST_SYNC.put(p.getUUID(), hash);
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(p, pl);
    }

    public static void forget(UUID id) { LAST_SYNC.remove(id); }
}
