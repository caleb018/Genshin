package com.teyvat.item;

import com.teyvat.Ornament;
import com.teyvat.registry.ModComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import top.theillusivec4.curios.api.type.capability.ICurioItem;

import java.util.List;

/** Visao / Eixo Estelar / Disco Lunar: mesmo codigo, slot Curios diferente. */
public class ElementalCurioItem extends Item implements ICurioItem {
    public enum Kind { VISION, STELLAR_AXIS, LUNAR_DISC }

    public final Kind kind;

    public ElementalCurioItem(Kind kind, Properties props) {
        super(props);
        this.kind = kind;
    }

    public static ItemStack withOrnament(Item item, Ornament o) {
        ItemStack s = new ItemStack(item);
        s.set(ModComponents.ORNAMENT.get(), o.id);
        return s;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.isShiftKeyDown()) {
            Ornament next = Ornament.of(stack).next();
            if (!level.isClientSide) {
                stack.set(ModComponents.ORNAMENT.get(), next.id);
                player.displayClientMessage(Component.translatable("message.teyvat.ornament", next.displayName()), true);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        return InteractionResultHolder.pass(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        String key = switch (kind) {
            case VISION -> "tooltip.teyvat.vision";
            case STELLAR_AXIS -> "tooltip.teyvat.stellar_axis";
            case LUNAR_DISC -> "tooltip.teyvat.lunar_disc";
        };
        tip.add(Component.translatable(key));
        tip.add(Component.translatable("tooltip.teyvat.ornament", Ornament.of(stack).displayName()));
        tip.add(Component.translatable("tooltip.teyvat.shift"));
    }
}
