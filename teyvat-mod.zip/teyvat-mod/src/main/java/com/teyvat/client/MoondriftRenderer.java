package com.teyvat.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.teyvat.entity.MoondriftEntity;
import com.teyvat.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Renderiza o modelo Blockbench "Moondrifts_torreta_dourada" (convertido para
 * models/item/moondrift_turret.json): uma torreta grande no centro e duas menores nos lados,
 * como na imagem de referencia.
 */
public class MoondriftRenderer extends EntityRenderer<MoondriftEntity> {
    private ItemStack stack;

    public MoondriftRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0f;
    }

    @Override
    public void render(MoondriftEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        if (stack == null) stack = new ItemStack(ModItems.MOONDRIFT_TURRET.get());
        float t = e.tickCount + pt;
        float grow = Math.min(1f, t / 10f);                      // surge do chao
        float fade = Math.min(1f, (MoondriftEntity.LIFETIME - t) / 10f);
        float k = Math.max(0f, Math.min(grow, fade));
        float bob = (float) Math.sin(t * 0.08) * 0.05f;

        turret(e, ps, buf, 0f, bob, 0f, 2.6f * k, t * 1.5f);
        turret(e, ps, buf, -1.7f, 0.1f + bob, 0.5f, 1.5f * k, -t * 2f);
        turret(e, ps, buf, 1.7f, 0.1f - bob, 0.5f, 1.5f * k, t * 2f);
    }

    private void turret(MoondriftEntity e, PoseStack ps, MultiBufferSource buf, float x, float y, float z, float scale, float rot) {
        if (scale <= 0.01f) return;
        ps.pushPose();
        ps.translate(x, y + scale * 0.5f, z);
        ps.scale(scale, scale, scale);
        ps.mulPose(Axis.YP.rotationDegrees(rot));
        Minecraft.getInstance().getItemRenderer().renderStatic(stack, ItemDisplayContext.NONE, 0xF000F0,
                OverlayTexture.NO_OVERLAY, ps, buf, e.level(), e.getId());
        ps.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(MoondriftEntity e) {
        return ResourceLocation.withDefaultNamespace("textures/misc/white.png");
    }
}
