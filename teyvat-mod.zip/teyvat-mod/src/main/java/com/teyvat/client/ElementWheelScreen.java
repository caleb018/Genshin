package com.teyvat.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.teyvat.Element;
import com.teyvat.net.ClientElementState;
import com.teyvat.net.SelectElementPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Matrix4f;

/** Roda de selecao de elementos: segure V, aponte com o mouse e solte (ou clique). */
public class ElementWheelScreen extends Screen {
    private static final double INNER = 30, OUTER = 92;
    private int hovered = -1;

    public ElementWheelScreen() {
        super(Component.translatable("screen.teyvat.wheel"));
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) { /* sem blur */ }

    private int hoverAt(int mx, int my) {
        double dx = mx - width / 2.0, dy = my - height / 2.0;
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < INNER || dist > OUTER + 60) return -1;
        double ang = Math.atan2(dx, -dy);
        if (ang < 0) ang += Math.PI * 2;
        int n = Element.values().length;
        double slice = Math.PI * 2 / n;
        return (int) Math.floor((ang + slice / 2) / slice) % n;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        hovered = hoverAt(mx, my);
        int n = Element.values().length;
        double slice = Math.PI * 2 / n;
        double cx = width / 2.0, cy = height / 2.0;
        var st = ClientElementState.get(Minecraft.getInstance().player.getUUID());
        int current = st == null ? -1 : st.element();

        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        Matrix4f m = g.pose().last().pose();
        BufferBuilder b = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i < n; i++) {
            Element el = Element.byIndex(i);
            boolean hov = i == hovered;
            double ro = OUTER + (hov ? 8 : 0);
            int alpha = hov ? 235 : (i == current ? 190 : 120);
            int argb = (alpha << 24) | el.rgb;
            double a0 = i * slice - slice / 2 + 0.03, a1 = i * slice + slice / 2 - 0.03;
            int steps = 8;
            for (int s = 0; s < steps; s++) {
                double u0 = a0 + (a1 - a0) * s / steps, u1 = a0 + (a1 - a0) * (s + 1) / steps;
                b.addVertex(m, (float) (cx + Math.sin(u0) * INNER), (float) (cy - Math.cos(u0) * INNER), 0).setColor(argb);
                b.addVertex(m, (float) (cx + Math.sin(u0) * ro), (float) (cy - Math.cos(u0) * ro), 0).setColor(argb);
                b.addVertex(m, (float) (cx + Math.sin(u1) * ro), (float) (cy - Math.cos(u1) * ro), 0).setColor(argb);
                b.addVertex(m, (float) (cx + Math.sin(u1) * INNER), (float) (cy - Math.cos(u1) * INNER), 0).setColor(argb);
            }
        }
        BufferUploader.drawWithShader(b.buildOrThrow());
        RenderSystem.enableCull();

        for (int i = 0; i < n; i++) {
            Element el = Element.byIndex(i);
            double ang = i * slice;
            double lr = (INNER + OUTER) / 2 + (i == hovered ? 4 : 0);
            int lx = (int) (cx + Math.sin(ang) * lr), ly = (int) (cy - Math.cos(ang) * lr);
            g.drawCenteredString(font, el.displayName(), lx, ly - 4, 0xFFFFFF);
        }
        Component center = hovered >= 0 ? Element.byIndex(hovered).displayName()
                : (current >= 0 ? Element.byIndex(current).displayName() : Component.empty());
        g.drawCenteredString(font, center, (int) cx, (int) cy - 4, 0xFFFFFF);
    }

    private void choose() {
        if (hovered >= 0) PacketDistributor.sendToServer(new SelectElementPayload(hovered, false));
        onClose();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        hovered = hoverAt((int) mx, (int) my);
        choose();
        return true;
    }

    @Override
    public boolean keyReleased(int key, int scan, int mods) {
        if (ClientSetup.WHEEL.matches(key, scan)) {
            choose();
            return true;
        }
        return super.keyReleased(key, scan, mods);
    }
}
