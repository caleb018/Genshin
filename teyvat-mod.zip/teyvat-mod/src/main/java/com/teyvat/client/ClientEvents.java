package com.teyvat.client;

import com.teyvat.Element;
import com.teyvat.Teyvat;
import com.teyvat.net.CastSkillPayload;
import com.teyvat.net.ClientElementState;
import com.teyvat.net.SelectElementPayload;
import com.teyvat.net.SyncElementPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = Teyvat.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        ClientElementState.State st = ClientElementState.get(mc.player.getUUID());
        boolean vision = st != null && st.has(SyncElementPayload.F_VISION);

        while (ClientSetup.NEXT.consumeClick()) {
            if (vision) PacketDistributor.sendToServer(new SelectElementPayload(1, true));
        }
        while (ClientSetup.PREV.consumeClick()) {
            if (vision) PacketDistributor.sendToServer(new SelectElementPayload(-1, true));
        }
        while (ClientSetup.SKILL.consumeClick()) {
            PacketDistributor.sendToServer(new CastSkillPayload());
        }
        if (ClientSetup.WHEEL.isDown() && mc.screen == null && vision) {
            mc.setScreen(new ElementWheelScreen());
        }
        handEffects(mc);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientElementState.clear();
    }

    /** Particulas na mao (e na arma imbuida) de todos os jogadores com Visao. */
    private static void handEffects(Minecraft mc) {
        long t = mc.level.getGameTime();
        for (Player p : mc.level.players()) {
            ClientElementState.State st = ClientElementState.get(p.getUUID());
            if (st == null || !st.has(SyncElementPayload.F_VISION) || p.isInvisible()) continue;
            Element el = Element.byIndex(st.element());
            boolean active = st.has(SyncElementPayload.F_IMBUE) || st.has(SyncElementPayload.F_ARMED);
            if (t % (active ? 1 : 4) != 0) continue;

            double yaw = Math.toRadians(p.yBodyRot);
            double fx = -Math.sin(yaw), fz = Math.cos(yaw);
            double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
            double h = p.isCrouching() ? 0.7 : 0.9;
            double x = p.getX() + rx * 0.38 + fx * 0.3;
            double y = p.getY() + h;
            double z = p.getZ() + rz * 0.38 + fz * 0.3;
            var r = p.getRandom();
            mc.level.addParticle(el.dust(active ? 1.0f : 0.7f), x + (r.nextDouble() - .5) * .15, y + (r.nextDouble() - .5) * .15, z + (r.nextDouble() - .5) * .15, 0, 0.01, 0);
            if (active) {
                mc.level.addParticle(el.accent(), x, y, z, (r.nextDouble() - .5) * .02, 0.02, (r.nextDouble() - .5) * .02);
                if (st.has(SyncElementPayload.F_IMBUE)) {
                    // brilho ao longo da arma
                    for (int i = 1; i <= 3; i++) {
                        mc.level.addParticle(el.dust(0.8f), x + fx * 0.3 * i, y + 0.15 * i, z + fz * 0.3 * i, 0, 0, 0);
                    }
                }
            }
        }
    }

    public static void renderHud(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        ClientElementState.State st = ClientElementState.get(mc.player.getUUID());
        if (st == null || !st.has(SyncElementPayload.F_VISION)) return;
        Element el = Element.byIndex(st.element());
        int x = 8, y = g.guiHeight() - 22;
        g.fill(x - 1, y - 1, x + 11, y + 11, 0xFF000000);
        g.fill(x, y, x + 10, y + 10, 0xFF000000 | el.rgb);
        g.drawString(mc.font, Component.translatable("hud.teyvat.element", el.displayName()), x + 15, y + 1, 0xFFFFFF, true);
    }
}
