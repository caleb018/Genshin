package com.teyvat.client;

import com.teyvat.Ornament;
import com.teyvat.Teyvat;
import com.teyvat.item.ElementalCurioItem;
import com.teyvat.net.ClientElementState;
import com.teyvat.registry.ModEntities;
import com.teyvat.registry.ModItems;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.item.Item;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;
import top.theillusivec4.curios.api.client.CuriosRendererRegistry;

@EventBusSubscriber(modid = Teyvat.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    public static final KeyMapping WHEEL = new KeyMapping("key.teyvat.wheel", GLFW.GLFW_KEY_V, "key.categories.teyvat");
    public static final KeyMapping NEXT = new KeyMapping("key.teyvat.next", GLFW.GLFW_KEY_X, "key.categories.teyvat");
    public static final KeyMapping PREV = new KeyMapping("key.teyvat.prev", GLFW.GLFW_KEY_Z, "key.categories.teyvat");
    public static final KeyMapping SKILL = new KeyMapping("key.teyvat.skill", GLFW.GLFW_KEY_R, "key.categories.teyvat");

    private ClientSetup() {}

    @SubscribeEvent
    public static void onKeys(RegisterKeyMappingsEvent e) {
        e.register(WHEEL);
        e.register(NEXT);
        e.register(PREV);
        e.register(SKILL);
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> {
            CuriosRendererRegistry.register(ModItems.VISION.get(), () -> new BroochRenderer(ElementalCurioItem.Kind.VISION));
            CuriosRendererRegistry.register(ModItems.STELLAR_AXIS.get(), () -> new BroochRenderer(ElementalCurioItem.Kind.STELLAR_AXIS));
            CuriosRendererRegistry.register(ModItems.LUNAR_DISC.get(), () -> new BroochRenderer(ElementalCurioItem.Kind.LUNAR_DISC));

            // o modelo do item muda conforme o elemento do portador e o ornamento do item
            for (Item it : new Item[]{ModItems.VISION.get(), ModItems.STELLAR_AXIS.get(), ModItems.LUNAR_DISC.get()}) {
                ItemProperties.register(it, Teyvat.id("element"), (stack, level, entity, seed) -> {
                    LivingEntity holder = entity != null ? entity : Minecraft.getInstance().player;
                    if (holder == null) return 0f;
                    ClientElementState.State st = ClientElementState.get(holder.getUUID());
                    return st == null ? 0f : st.element();
                });
                ItemProperties.register(it, Teyvat.id("ornament"), (stack, level, entity, seed) -> (float) Ornament.of(stack).ordinal());
            }
        });
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.MOONDRIFT.get(), MoondriftRenderer::new);
        e.registerEntityRenderer(ModEntities.DENDRO_CORE.get(), ctx -> new ThrownItemRenderer<>(ctx, 1.0f, true));
    }

    @SubscribeEvent
    public static void onAddLayers(EntityRenderersEvent.AddLayers e) {
        for (PlayerSkin.Model skin : e.getSkins()) {
            EntityRenderer<?> r = e.getSkin(skin);
            if (r instanceof PlayerRenderer pr) {
                pr.addLayer(new HandEffectLayer(pr));
            }
        }
    }

    @SubscribeEvent
    public static void onGui(RegisterGuiLayersEvent e) {
        e.registerAboveAll(Teyvat.id("element_hud"), (g, dt) -> ClientEvents.renderHud(g));
    }
}
