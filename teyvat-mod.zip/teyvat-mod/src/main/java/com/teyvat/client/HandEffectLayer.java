package com.teyvat.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.teyvat.Element;
import com.teyvat.Teyvat;
import com.teyvat.net.ClientElementState;
import com.teyvat.net.SyncElementPayload;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Circulo do arconte (simbolo do elemento) girando na mao direita do jogador. */
public class HandEffectLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation[] TEX = new ResourceLocation[Element.values().length];

    static {
        for (Element e : Element.values()) TEX[e.ordinal()] = Teyvat.id("textures/effect/archon_" + e.id + ".png");
    }

    public HandEffectLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer player, float limbSwing,
                       float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        ClientElementState.State st = ClientElementState.get(player.getUUID());
        if (st == null || !st.has(SyncElementPayload.F_VISION) || player.isInvisible()) return;
        Element el = Element.byIndex(st.element());
        boolean active = st.has(SyncElementPayload.F_IMBUE) || st.has(SyncElementPayload.F_ARMED);

        ps.pushPose();
        getParentModel().rightArm.translateAndRotate(ps); // segue a animacao do braco (e de mods de animacao)
        ps.translate(0.0, 0.78, 0.0);
        ps.mulPose(Axis.YP.rotationDegrees(ageInTicks * (active ? 9f : 3f)));
        float s = active ? 0.36f : 0.22f;
        int a = active ? 235 : 120;
        VertexConsumer vc = buf.getBuffer(RenderType.entityTranslucentEmissive(TEX[el.ordinal()]));
        PoseStack.Pose pose = ps.last();
        vertex(vc, pose, -s, -s, 0, 0, a);
        vertex(vc, pose, -s, s, 0, 1, a);
        vertex(vc, pose, s, s, 1, 1, a);
        vertex(vc, pose, s, -s, 1, 0, a);
        ps.popPose();
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float z, float u, float v, int alpha) {
        vc.addVertex(pose, x, 0f, z).setColor(255, 255, 255, alpha).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(0xF000F0).setNormal(pose, 0f, 1f, 0f);
    }
}
