package com.teyvat.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.teyvat.item.ElementalCurioItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.client.ICurioRenderer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Desenha os tres broches no corpo do jogador usando as partes do modelo (compativel com
 * mods de animacao, pois segue o 'body' ja animado). O "entalhe 3D" vem da extrusao do
 * proprio sprite do item; o Eixo Estelar tem uma fisica de pendulo leve.
 */
public class BroochRenderer implements ICurioRenderer {
    private static final Map<UUID, float[]> SWAY = new HashMap<>();
    private final ElementalCurioItem.Kind kind;

    public BroochRenderer(ElementalCurioItem.Kind kind) {
        this.kind = kind;
    }

    @Override
    public <T extends LivingEntity, M extends EntityModel<T>> void render(ItemStack stack, SlotContext slotContext, PoseStack ps,
                                                                           RenderLayerParent<T, M> parent, MultiBufferSource buf, int light,
                                                                           float limbSwing, float limbSwingAmount, float partialTicks,
                                                                           float ageInTicks, float netHeadYaw, float headPitch) {
        LivingEntity entity = slotContext.entity();
        if (!(parent.getModel() instanceof HumanoidModel<?> hm)) return;

        ps.pushPose();
        hm.body.translateAndRotate(ps);

        switch (kind) {
            case VISION -> {
                // quadril esquerdo, na frente
                ps.translate(0.17, 0.64, -0.165);
                ps.scale(0.45f, 0.45f, 0.45f);
            }
            case STELLAR_AXIS -> {
                // pendurado no ombro direito, balancando
                ps.translate(-0.27, 0.03, -0.11);
                float[] s = SWAY.computeIfAbsent(entity.getUUID(), k -> new float[5]);
                float dt = Math.min(3f, ageInTicks - s[4]);
                if (dt > 0 || dt < -50) {
                    if (dt < 0) dt = 1f;
                    double yaw = Math.toRadians(entity.yBodyRot);
                    double vx = entity.getX() - entity.xo, vz = entity.getZ() - entity.zo;
                    double fwd = vx * -Math.sin(yaw) + vz * Math.cos(yaw);
                    double lat = vx * -Math.cos(yaw) + vz * -Math.sin(yaw);
                    float tx = (float) Math.max(-35, Math.min(35, fwd * 140)) + (float) Math.sin(ageInTicks * 0.12) * 2f;
                    float tz = (float) Math.max(-35, Math.min(35, lat * 140)) + (float) Math.cos(ageInTicks * 0.09) * 1.5f;
                    s[1] += (tx - s[0]) * 0.25f * dt;
                    s[1] *= Math.pow(0.8, dt);
                    s[0] += s[1] * dt;
                    s[3] += (tz - s[2]) * 0.25f * dt;
                    s[3] *= Math.pow(0.8, dt);
                    s[2] += s[3] * dt;
                    s[4] = ageInTicks;
                }
                ps.mulPose(Axis.XP.rotationDegrees(s[0]));
                ps.mulPose(Axis.ZP.rotationDegrees(s[2]));
                ps.translate(0, 0.12, 0);
                ps.scale(0.5f, 0.5f, 0.5f);
            }
            case LUNAR_DISC -> {
                // nas costas, quase na nuca, flutuando de leve
                ps.translate(0, 0.07 + Math.sin(ageInTicks * 0.08) * 0.008, 0.165);
                ps.scale(0.55f, 0.55f, 0.55f);
            }
        }

        Minecraft.getInstance().getItemRenderer().renderStatic(entity, stack, ItemDisplayContext.FIXED, false, ps, buf,
                entity.level(), light, OverlayTexture.NO_OVERLAY, entity.getId());
        ps.popPose();
    }
}
