package com.teyvat;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.joml.Vector3f;

public enum Element {
    PYRO("pyro", 0xFF5A2E, true),
    HYDRO("hydro", 0x2E8BFF, true),
    ANEMO("anemo", 0x6EF2C8, false),
    ELECTRO("electro", 0xB35CFF, true),
    DENDRO("dendro", 0x7FE03A, true),
    CRYO("cryo", 0x8FE9FF, true),
    GEO("geo", 0xFFC83A, false);

    public final String id;
    public final int rgb;
    public final boolean canAura;

    Element(String id, int rgb, boolean canAura) {
        this.id = id;
        this.rgb = rgb;
        this.canAura = canAura;
    }

    public static Element byIndex(int i) {
        Element[] v = values();
        return v[Math.floorMod(i, v.length)];
    }

    public float r() { return ((rgb >> 16) & 255) / 255f; }
    public float g() { return ((rgb >> 8) & 255) / 255f; }
    public float b() { return (rgb & 255) / 255f; }

    public DustParticleOptions dust(float scale) {
        return new DustParticleOptions(new Vector3f(r(), g(), b()), scale);
    }

    public ParticleOptions accent() {
        return switch (this) {
            case PYRO -> ParticleTypes.FLAME;
            case HYDRO -> ParticleTypes.SPLASH;
            case ANEMO -> ParticleTypes.CLOUD;
            case ELECTRO -> ParticleTypes.ELECTRIC_SPARK;
            case DENDRO -> ParticleTypes.HAPPY_VILLAGER;
            case CRYO -> ParticleTypes.SNOWFLAKE;
            case GEO -> ParticleTypes.END_ROD;
        };
    }

    public SoundEvent hitSound() {
        return switch (this) {
            case PYRO -> SoundEvents.FIRECHARGE_USE;
            case HYDRO -> SoundEvents.BUBBLE_COLUMN_UPWARDS_AMBIENT;
            case ANEMO -> SoundEvents.PLAYER_ATTACK_SWEEP;
            case ELECTRO -> SoundEvents.LIGHTNING_BOLT_IMPACT;
            case DENDRO -> SoundEvents.GRASS_BREAK;
            case CRYO -> SoundEvents.GLASS_BREAK;
            case GEO -> SoundEvents.AMETHYST_BLOCK_CHIME;
        };
    }

    public Component displayName() {
        return Component.translatable("element.teyvat." + id);
    }
}
