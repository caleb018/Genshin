import json, math, os, random
from PIL import Image, ImageDraw, ImageFilter

ROOT = '/home/claude/teyvat/src/main/resources'
A = ROOT + '/assets/teyvat'
D = ROOT + '/data'
MOD = 'teyvat'

ELEMENTS = ['pyro', 'hydro', 'anemo', 'electro', 'dendro', 'cryo', 'geo']
ECOL = {
    'pyro': (255, 90, 46), 'hydro': (46, 139, 255), 'anemo': (110, 242, 200),
    'electro': (179, 92, 255), 'dendro': (127, 224, 58), 'cryo': (143, 233, 255),
    'geo': (255, 200, 58),
}
ORNAMENTS = ['mondstadt', 'liyue', 'inazuma', 'sumeru', 'fontaine', 'natlan', 'snezhnaya']
GOLD = ((236, 220, 160), (201, 174, 109), (142, 116, 64))
SILVER = ((236, 238, 242), (184, 188, 198), (110, 115, 128))
METAL = {'mondstadt': GOLD, 'liyue': GOLD, 'inazuma': GOLD, 'sumeru': GOLD,
         'fontaine': SILVER, 'natlan': GOLD, 'snezhnaya': SILVER}
ITEMS = ['vision', 'stellar_axis', 'lunar_disc']

S = 8      # supersample
N = 32     # final size


def mk(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)


def save(img, path):
    mk(path)
    img.save(path)


def canvas(size=N):
    return Image.new('RGBA', (size * S, size * S), (0, 0, 0, 0))


def down(img, size=N):
    return img.resize((size, size), Image.LANCZOS)


def P(pts, size=N):
    return [(x * S * size / N, y * S * size / N) for x, y in pts]


# ---------------------------------------------------------------- symbols
def draw_symbol(d, el, cx, cy, r, col):
    w = max(2, int(r * 0.22))
    if el == 'pyro':
        pts = [(0, -1), (0.55, -0.25), (0.8, 0.35), (0.35, 0.95), (-0.35, 0.95), (-0.8, 0.35), (-0.45, -0.1), (-0.15, -0.35)]
        d.polygon([(cx + x * r, cy + y * r) for x, y in pts], fill=col)
    elif el == 'hydro':
        for k, rr in enumerate([1.0, 0.62, 0.28]):
            d.arc([cx - rr * r, cy - rr * r, cx + rr * r, cy + rr * r], 30 + k * 40, 330 + k * 20, fill=col, width=w)
    elif el == 'anemo':
        for k in range(3):
            a0 = k * 120
            d.arc([cx - r, cy - r, cx + r, cy + r], a0, a0 + 150, fill=col, width=w)
        d.ellipse([cx - r * .2, cy - r * .2, cx + r * .2, cy + r * .2], fill=col)
    elif el == 'electro':
        for k in range(3):
            a = math.radians(k * 120 - 90)
            ox, oy = cx + math.cos(a) * r * 0.5, cy + math.sin(a) * r * 0.5
            d.ellipse([ox - r * .3, oy - r * .3, ox + r * .3, oy + r * .3], fill=col)
            d.polygon([(ox, oy), (ox + math.cos(a + 1.9) * r * .7, oy + math.sin(a + 1.9) * r * .7),
                       (ox + math.cos(a + 1.2) * r * .7, oy + math.sin(a + 1.2) * r * .7)], fill=col)
    elif el == 'dendro':
        d.ellipse([cx - r * .45, cy - r * .9, cx + r * .45, cy + r * .1], fill=col)
        d.ellipse([cx - r * .9, cy - r * .2, cx, cy + r * .8], fill=col)
        d.ellipse([cx, cy - r * .2, cx + r * .9, cy + r * .8], fill=col)
        d.line([cx, cy - r * .2, cx, cy + r], fill=col, width=w)
    elif el == 'cryo':
        for k in range(6):
            a = math.radians(k * 60)
            ex, ey = cx + math.cos(a) * r, cy + math.sin(a) * r
            d.line([cx, cy, ex, ey], fill=col, width=w)
            mx, my = cx + math.cos(a) * r * .6, cy + math.sin(a) * r * .6
            for s in (-1, 1):
                b = a + s * 0.7
                d.line([mx, my, mx + math.cos(b) * r * .35, my + math.sin(b) * r * .35], fill=col, width=max(1, w - 1))
    elif el == 'geo':
        d.polygon([(cx, cy - r), (cx + r * .75, cy), (cx, cy + r), (cx - r * .75, cy)], fill=col)
        d.polygon([(cx, cy - r * .5), (cx + r * .35, cy), (cx, cy + r * .5), (cx - r * .35, cy)], fill=(255, 255, 255, 120))


# ---------------------------------------------------------------- gems
def gem_shape(kind, d, fill, size=N, scale=1.0):
    c = size / 2
    if kind == 'axis':  # star diamond
        r = size * 0.44 * scale
        k = r * 0.42
        pts = [(c, c - r), (c + k, c - k), (c + r, c), (c + k, c + k), (c, c + r), (c - k, c + k), (c - r, c), (c - k, c - k)]
        d.polygon(P_(pts, size), fill=fill)
    else:
        r = size * (0.30 if kind == 'vision' else 0.34) * scale
        d.ellipse([(c - r) * S, (c - r) * S, (c + r) * S, (c + r) * S], fill=fill)


def P_(pts, size):
    return [(x * S, y * S) for x, y in pts]


def make_gem(item, el, size=N):
    kind = {'vision': 'vision', 'stellar_axis': 'axis', 'lunar_disc': 'disc'}[item]
    col = ECOL[el]
    img = canvas(size)
    mask = Image.new('L', img.size, 0)
    md = ImageDraw.Draw(mask)
    gem_shape(kind, md, 255, size)
    grad = Image.new('RGBA', img.size)
    gd = ImageDraw.Draw(grad)
    for y in range(img.size[1]):
        t = y / img.size[1]
        c = tuple(int(col[i] * (1.15 - 0.55 * t)) for i in range(3))
        c = tuple(min(255, v) for v in c)
        gd.line([(0, y), (img.size[0], y)], fill=c + (255,))
    img.paste(grad, (0, 0), mask)
    d = ImageDraw.Draw(img)
    light = tuple(min(255, v + 90) for v in col) + (235,)
    draw_symbol(d, el, size * S / 2, size * S / 2, size * S * (0.17 if kind != 'axis' else 0.15), light)
    # highlight
    hl = Image.new('RGBA', img.size, (0, 0, 0, 0))
    hd = ImageDraw.Draw(hl)
    hd.ellipse([size * S * .30, size * S * .24, size * S * .52, size * S * .38], fill=(255, 255, 255, 110))
    img = Image.composite(Image.alpha_composite(img, hl), img, mask)
    return down(img, size)


# ---------------------------------------------------------------- frames
def ring_hole(d, kind, size, hole=True):
    c = size / 2
    if kind == 'axis':
        r = size * 0.44
        k = r * .42
        pts = [(c, c - r), (c + k, c - k), (c + r, c), (c + k, c + k), (c, c + r), (c - k, c + k), (c - r, c), (c - k, c - k)]
        return [(x * S, y * S) for x, y in pts]
    return None


def make_frame(item, orn, size=N):
    kind = {'vision': 'vision', 'stellar_axis': 'axis', 'lunar_disc': 'disc'}[item]
    light, mid, dark = METAL[orn]
    c = size / 2
    img = canvas(size)
    d = ImageDraw.Draw(img)

    def poly(pts, f, o=dark):
        d.polygon([(x * S, y * S) for x, y in pts], fill=f, outline=o)

    def ell(cx, cy, rx, ry, f, o=dark):
        d.ellipse([(cx - rx) * S, (cy - ry) * S, (cx + rx) * S, (cy + ry) * S], fill=f, outline=o, width=S // 2)

    if kind == 'vision':
        # silhouette per ornament
        if orn == 'mondstadt':      # teardrop with spikes
            poly([(c, 1), (c + 9, 12), (c + 15, 15), (c + 9, 18), (c + 10, 25), (c, 31), (c - 10, 25), (c - 9, 18), (c - 15, 15), (c - 9, 12)], mid)
        elif orn == 'liyue':        # ring with cross points
            poly([(c, 2), (c + 3, c - 6), (c + 14, c), (c + 3, c + 6), (c, 30), (c - 3, c + 6), (c - 14, c), (c - 3, c - 6)], dark)
            ell(c, c, 12, 12, mid)
        elif orn == 'inazuma':      # octagon
            r = 14
            poly([(c + r * math.cos(math.radians(22.5 + 45 * i)), c + r * math.sin(math.radians(22.5 + 45 * i))) for i in range(8)], mid)
        elif orn == 'sumeru':       # winged circle
            poly([(c - 15, 9), (c - 8, 12), (c - 8, 18), (c - 15, 22), (c - 12, 15)], light)
            poly([(c + 15, 9), (c + 8, 12), (c + 8, 18), (c + 15, 22), (c + 12, 15)], light)
            ell(c, c, 11, 11, mid)
            poly([(c - 3, 27), (c + 3, 27), (c, 31)], dark)
        elif orn == 'fontaine':     # silver crescent-topped diamond
            poly([(c, 6), (c + 12, c), (c, 30), (c - 12, c)], mid)
            ell(c, 4, 5, 3.5, light)
            ell(c, 5.2, 3, 2.2, (0, 0, 0, 0), (0, 0, 0, 0))
        elif orn == 'natlan':       # spiky star ring
            pts = []
            for i in range(16):
                rr = 15 if i % 2 == 0 else 11
                a = math.radians(i * 22.5 - 90)
                pts.append((c + rr * math.cos(a), c + rr * math.sin(a)))
            poly(pts, mid)
        else:                       # snezhnaya: spiky silver teardrop
            poly([(c, 0), (c + 6, 9), (c + 15, 11), (c + 9, 17), (c + 11, 24), (c, 31), (c - 11, 24), (c - 9, 17), (c - 15, 11), (c - 6, 9)], mid)
        r = 11.5
        ell(c, c, r, r, dark)
        ell(c, c, r - 1.5, r - 1.5, light)
        # punch the gem hole
        hole = canvas(size)
        hd = ImageDraw.Draw(hole)
        gem_shape('vision', hd, (255, 255, 255, 255), size, 1.02)
        a = img.getchannel('A')
        ha = hole.getchannel('A')
        a = Image.composite(Image.new('L', a.size, 0), a, ha)
        img.putalpha(a)
    elif kind == 'axis':
        spikes = {'mondstadt': 4, 'liyue': 4, 'inazuma': 8, 'sumeru': 6, 'fontaine': 4, 'natlan': 8, 'snezhnaya': 6}[orn]
        pts = []
        for i in range(spikes * 2):
            rr = 15.5 if i % 2 == 0 else 11.5
            a = math.radians(i * 180 / spikes - 90)
            pts.append((c + rr * math.cos(a), c + rr * math.sin(a)))
        poly(pts, mid)
        r = 13
        k = r * .5
        poly([(c, c - r), (c + k, c - k), (c + r, c), (c + k, c + k), (c, c + r), (c - k, c + k), (c - r, c), (c - k, c - k)], light, dark)
        hole = canvas(size)
        hd = ImageDraw.Draw(hole)
        gem_shape('axis', hd, (255, 255, 255, 255), size, 0.95)
        a = img.getchannel('A')
        a = Image.composite(Image.new('L', a.size, 0), a, hole.getchannel('A'))
        img.putalpha(a)
        # hanging loop
        d2 = ImageDraw.Draw(img)
        d2.ellipse([(c - 2) * S, 0, (c + 2) * S, 4 * S], outline=dark, width=S // 2)
    else:  # disc: ring with crescent below and top stud
        ell(c, c - 1, 14, 14, mid)
        ell(c, c - 1, 11.5, 11.5, dark)
        ell(c, 4, 2.6, 2.6, light)
        ell(c, 28, 4.5, 3.5, mid)
        ell(c, 28.8, 2.6, 2.1, dark)
        for i, ang in enumerate([-60, -35, 35, 60]):
            a = math.radians(ang + 90)
            px, py = c + math.cos(a) * 13, c - 1 + math.sin(a) * 13
            poly([(px, py - 2.4), (px + 2, py), (px, py + 2.4), (px - 2, py)], light)
        if orn in ('inazuma', 'natlan'):
            ell(c, c - 1, 14.5, 14.5, (0, 0, 0, 0), mid)
        hole = canvas(size)
        hd = ImageDraw.Draw(hole)
        gem_shape('disc', hd, (255, 255, 255, 255), size, 1.0)
        a = img.getchannel('A')
        a = Image.composite(Image.new('L', a.size, 0), a, hole.getchannel('A'))
        img.putalpha(a)
    return down(img, size)


# ---------------------------------------------------------------- emblems (hand effect)
def make_emblem(el, size=128):
    col = ECOL[el]
    img = canvas(size)
    d = ImageDraw.Draw(img)
    s = size * S
    c = s / 2
    glow = tuple(col) + (255,)
    for rr, w in ((0.47, 5), (0.40, 3), (0.20, 3)):
        d.ellipse([c - c * rr * 2, c - c * rr * 2, c + c * rr * 2, c + c * rr * 2], outline=glow, width=int(w * S / 2))
    for k in range(12):
        a = math.radians(k * 30)
        d.line([c + math.cos(a) * c * 0.78, c + math.sin(a) * c * 0.78, c + math.cos(a) * c * 0.94, c + math.sin(a) * c * 0.94], fill=glow, width=int(2.5 * S / 2))
    draw_symbol(d, el, c, c, c * 0.34, glow)
    img = img.filter(ImageFilter.GaussianBlur(S * 0.4))
    return down(img, size)


# ---------------------------------------------------------------- misc icons
def make_effect_icon(name):
    img = canvas(18)
    d = ImageDraw.Draw(img)
    if name in ELEMENTS:
        col = ECOL[name]
        d.ellipse([1 * S, 1 * S, 17 * S, 17 * S], fill=col + (255,), outline=(255, 255, 255, 255), width=S // 2)
        draw_symbol(d, name, 9 * S, 9 * S, 5.5 * S, (255, 255, 255, 235))
    else:
        base = {'frozen': (150, 220, 255), 'superconduct': (200, 160, 255), 'quicken': (160, 255, 130), 'shred': (255, 230, 120)}[name]
        d.rectangle([1 * S, 1 * S, 17 * S, 17 * S], fill=base + (255,), outline=(255, 255, 255, 255), width=S // 2)
        if name == 'frozen':
            draw_symbol(d, 'cryo', 9 * S, 9 * S, 6 * S, (255, 255, 255, 255))
        elif name == 'superconduct':
            draw_symbol(d, 'electro', 9 * S, 9 * S, 6 * S, (255, 255, 255, 255))
        elif name == 'quicken':
            draw_symbol(d, 'dendro', 9 * S, 9 * S, 6 * S, (255, 255, 255, 255))
        else:
            d.polygon([(9 * S, 3 * S), (14 * S, 14 * S), (9 * S, 11 * S), (4 * S, 14 * S)], fill=(255, 255, 255, 255))
    return down(img, 18)


def make_slot_icon(item):
    img = canvas(16)
    d = ImageDraw.Draw(img)
    col = (150, 150, 150, 255)
    c = 8 * S
    if item == 'vision':
        d.ellipse([3 * S, 3 * S, 13 * S, 13 * S], outline=col, width=S)
        d.polygon([(8 * S, 0), (10 * S, 3 * S), (6 * S, 3 * S)], outline=col)
    elif item == 'stellar_axis':
        d.polygon([(8 * S, 1 * S), (10 * S, 6 * S), (15 * S, 8 * S), (10 * S, 10 * S), (8 * S, 15 * S), (6 * S, 10 * S), (1 * S, 8 * S), (6 * S, 6 * S)], outline=col)
    else:
        d.ellipse([2 * S, 2 * S, 14 * S, 14 * S], outline=col, width=S)
        d.ellipse([5 * S, 9 * S, 11 * S, 14 * S], outline=col, width=S // 2)
    return down(img, 16)


def make_core():
    img = canvas(16)
    d = ImageDraw.Draw(img)
    d.ellipse([2 * S, 2 * S, 14 * S, 14 * S], fill=(110, 210, 60, 255), outline=(40, 110, 30, 255), width=S // 2)
    d.ellipse([5 * S, 5 * S, 11 * S, 11 * S], fill=(200, 255, 150, 255))
    d.ellipse([4 * S, 4 * S, 7 * S, 7 * S], fill=(255, 255, 255, 200))
    return down(img, 16)


# ---------------------------------------------------------------- moondrift model + texture
def build_moondrift():
    src = '/mnt/user-data/uploads/Moondrifts_torreta_dourada.bbmodel__1_'
    bb = json.load(open(src))
    els = {e['uuid']: e for e in bb['elements']}
    role = {}
    order = []
    for gi, g in enumerate(bb['outliner']):
        for ch in g['children']:
            role[ch] = gi
            order.append(ch)
    tex = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    td = ImageDraw.Draw(tex)
    rnd = random.Random(7)
    PAL = {
        0: ((222, 196, 120), (244, 226, 164), (168, 134, 70)),   # haste
        1: ((236, 214, 140), (250, 240, 190), (184, 150, 84)),   # colar
        2: ((246, 232, 170), (255, 250, 220), (214, 182, 106)),  # lua
    }
    CRYSTAL = ((232, 186, 78), (255, 232, 150), (176, 124, 40))
    BASEP = ((196, 164, 92), (226, 200, 130), (140, 108, 52))
    model_elements = []
    face_map = {'north': 'north', 'east': 'east', 'south': 'south', 'west': 'west', 'up': 'up', 'down': 'down'}
    for idx, uid in enumerate(order):
        e = els[uid]
        g = role[uid]
        pal = PAL[g]
        local = [c for c in bb['outliner'][g]['children']].index(uid)
        if g == 0:
            pal = BASEP if local == 1 else (CRYSTAL if local >= 2 else PAL[0])
        for fname, f in e['faces'].items():
            u0, v0, u1, v1 = [int(round(x)) for x in f['uv']]
            x0, x1 = sorted((u0, u1))
            y0, y1 = sorted((v0, v1))
            x1 = max(x1, x0 + 1)
            y1 = max(y1, y0 + 1)
            shade = {'up': 1, 'down': 2, 'north': 0, 'south': 0, 'east': 2 if g else 0, 'west': 0}[fname]
            base = pal[0] if shade == 0 else (pal[1] if shade == 1 else pal[2])
            for x in range(x0, min(x1, 32)):
                for y in range(y0, min(y1, 32)):
                    v = rnd.randint(-8, 8)
                    col = tuple(max(0, min(255, base[i] + v)) for i in range(3)) + (255,)
                    if x in (x0, x1 - 1) or y in (y0, y1 - 1):
                        col = tuple(max(0, min(255, int(pal[2][i] * 1.05 + v))) for i in range(3)) + (255,)
                    tex.putpixel((x, y), col)
            if (x1 - x0) >= 2 and (y1 - y0) >= 2:
                tex.putpixel((x0 + 1 if x1 - x0 > 2 else x0, y0), tuple(min(255, c + 40) for c in pal[1]) + (255,))
        el = {'from': e['from'], 'to': e['to'], 'faces': {}}
        rot = e.get('rotation')
        if rot and any(abs(r) > 1e-6 for r in rot):
            axis = 'x' if abs(rot[0]) > 0 else ('y' if abs(rot[1]) > 0 else 'z')
            ang = rot[{'x': 0, 'y': 1, 'z': 2}[axis]]
            el['rotation'] = {'angle': ang, 'axis': axis, 'origin': e['origin']}
        for fname, f in e['faces'].items():
            u0, v0, u1, v1 = f['uv']
            el['faces'][fname] = {'uv': [u0 * .5, v0 * .5, u1 * .5, v1 * .5], 'texture': '#0'}
        model_elements.append(el)
    model = {
        'textures': {'0': f'{MOD}:item/moondrift_turret', 'particle': f'{MOD}:item/moondrift_turret'},
        'elements': model_elements,
        'display': {'fixed': {'rotation': [0, 180, 0], 'scale': [0.8, 0.8, 0.8]}},
    }
    big = tex.resize((128, 128), Image.NEAREST)
    # keep native 32x32 texture so UVs stay valid
    save(tex, f'{A}/textures/item/moondrift_turret.png')
    mk(f'{A}/models/item/moondrift_turret.json')
    json.dump(model, open(f'{A}/models/item/moondrift_turret.json', 'w'), indent=1)


# ---------------------------------------------------------------- run
def jdump(obj, path):
    mk(path)
    json.dump(obj, open(path, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)


def main():
    for item in ITEMS:
        for o in ORNAMENTS:
            save(make_frame(item, o), f'{A}/textures/item/{item}/frame_{o}.png')
        for e in ELEMENTS:
            save(make_gem(item, e), f'{A}/textures/item/{item}/gem_{e}.png')
        # models
        overrides = []
        for oi, o in enumerate(ORNAMENTS):
            for ei, e in enumerate(ELEMENTS):
                name = f'{item}_{o}_{e}'
                jdump({'parent': 'item/generated',
                       'textures': {'layer0': f'{MOD}:item/{item}/gem_{e}', 'layer1': f'{MOD}:item/{item}/frame_{o}'}},
                      f'{A}/models/item/{name}.json')
                overrides.append({'predicate': {f'{MOD}:ornament': oi, f'{MOD}:element': ei}, 'model': f'{MOD}:item/{name}'})
        jdump({'parent': 'item/generated',
               'textures': {'layer0': f'{MOD}:item/{item}/gem_pyro', 'layer1': f'{MOD}:item/{item}/frame_inazuma'},
               'overrides': overrides}, f'{A}/models/item/{item}.json')
        save(make_slot_icon(item), f'{A}/textures/slot/{item}.png')

    for e in ELEMENTS:
        save(make_emblem(e), f'{A}/textures/effect/archon_{e}.png')
    for n in ELEMENTS + ['frozen', 'superconduct', 'quicken', 'shred']:
        save(make_effect_icon(n), f'{A}/textures/mob_effect/{n}.png')
    save(make_core(), f'{A}/textures/item/dendro_core.png')
    jdump({'parent': 'item/generated', 'textures': {'layer0': f'{MOD}:item/dendro_core'}}, f'{A}/models/item/dendro_core.json')
    build_moondrift()

    # ---- curios data
    slots = {'vision': 'vision', 'stellar_axis': 'stellar_axis', 'lunar_disc': 'lunar_disc'}
    for i, s in enumerate(slots):
        jdump({'size': 1, 'order': 100 + i, 'icon': f'{MOD}:slot/{s}'}, f'{D}/{MOD}/curios/slots/{s}.json')
        jdump({'replace': False, 'values': [f'{MOD}:{s}']}, f'{D}/curios/tags/item/{s}.json')
    jdump({'entities': ['player'], 'slots': list(slots)}, f'{D}/{MOD}/curios/entities/player.json')

    # ---- damage type
    jdump({'exhaustion': 0.0, 'message_id': 'teyvat.elemental', 'scaling': 'when_caused_by_living_non_player'},
          f'{D}/{MOD}/damage_type/elemental.json')
    jdump({'replace': False, 'values': [f'{MOD}:elemental']}, f'{D}/minecraft/tags/damage_type/bypasses_armor.json')
    jdump({'replace': False, 'values': [f'{MOD}:elemental']}, f'{D}/minecraft/tags/damage_type/no_knockback.json')

    # ---- recipes
    def shaped(name, pattern, key, result):
        jdump({'type': 'minecraft:crafting_shaped', 'category': 'equipment', 'pattern': pattern,
               'key': {k: {'item': v} for k, v in key.items()},
               'result': {'id': f'{MOD}:{result}', 'count': 1}}, f'{D}/{MOD}/recipe/{name}.json')
    shaped('vision', [' G ', 'GAG', ' D '], {'G': 'minecraft:gold_ingot', 'A': 'minecraft:amethyst_shard', 'D': 'minecraft:diamond'}, 'vision')
    shaped('stellar_axis', ['GQG', 'QDQ', 'GQG'], {'G': 'minecraft:gold_nugget', 'Q': 'minecraft:quartz', 'D': 'minecraft:diamond'}, 'stellar_axis')
    shaped('lunar_disc', ['IAI', 'ADA', 'IAI'], {'I': 'minecraft:iron_ingot', 'A': 'minecraft:amethyst_shard', 'D': 'minecraft:diamond'}, 'lunar_disc')

    # ---- lang
    names_pt = {'pyro': 'Pyro', 'hydro': 'Hydro', 'anemo': 'Anemo', 'electro': 'Electro', 'dendro': 'Dendro', 'cryo': 'Cryo', 'geo': 'Geo'}
    orn_pt = {'mondstadt': 'Mondstadt', 'liyue': 'Liyue', 'inazuma': 'Inazuma', 'sumeru': 'Sumeru', 'fontaine': 'Fontaine', 'natlan': 'Natlan', 'snezhnaya': 'Snezhnaya'}
    pt = {
        'item.teyvat.vision': 'Visão', 'item.teyvat.stellar_axis': 'Eixo Estelar', 'item.teyvat.lunar_disc': 'Disco Lunar',
        'item.teyvat.dendro_core': 'Núcleo Dendro', 'item.teyvat.moondrift_turret': 'Moondrift',
        'entity.teyvat.dendro_core': 'Núcleo Dendro', 'entity.teyvat.moondrift': 'Moondrift',
        'itemGroup.teyvat': 'Teyvat Elements',
        'curios.identifier.vision': 'Visão', 'curios.identifier.stellar_axis': 'Eixo Estelar', 'curios.identifier.lunar_disc': 'Disco Lunar',
        'key.categories.teyvat': 'Teyvat Elements',
        'key.teyvat.wheel': 'Roda de elementos (segurar)', 'key.teyvat.next': 'Próximo elemento',
        'key.teyvat.prev': 'Elemento anterior', 'key.teyvat.skill': 'Habilidade elemental',
        'screen.teyvat.wheel': 'Roda de elementos',
        'message.teyvat.no_vision': 'Você precisa equipar uma Visão (slot Curios).',
        'message.teyvat.cooldown': 'Habilidade em recarga: %s s',
        'message.teyvat.bad_item': 'Segure uma espada, machado, tridente, arco ou deixe a mão vazia.',
        'message.teyvat.imbue': 'Arma imbuída com %s!',
        'message.teyvat.ornament': 'Ornamento: %s',
        'tooltip.teyvat.ornament': 'Ornamento: %s',
        'tooltip.teyvat.shift': 'Agache + clique direito para trocar o ornamento.',
        'tooltip.teyvat.vision': 'Concede todos os elementos. Use a roda (V) e a habilidade (R).',
        'tooltip.teyvat.stellar_axis': 'Habilita o Redemoinho Estelar (Anemo + Cryo).',
        'tooltip.teyvat.lunar_disc': 'Signo Lunar: Carga Lunar, Florescimento Lunar e Cristalização Lunar.',
        'reaction.teyvat.melt': 'Derretimento', 'reaction.teyvat.vaporize': 'Vaporização',
        'reaction.teyvat.overloaded': 'Sobrecarregar', 'reaction.teyvat.superconduct': 'Supercondutor',
        'reaction.teyvat.frozen': 'Congelado', 'reaction.teyvat.swirl': 'Redemoinho',
        'reaction.teyvat.stellar_swirl': 'Redemoinho Estelar', 'reaction.teyvat.crystallize': 'Cristalizar',
        'reaction.teyvat.bloom': 'Florescer', 'reaction.teyvat.burning': 'Queimar',
        'reaction.teyvat.quicken': 'Intensificar', 'reaction.teyvat.electro_charged': 'Eletrocarregado',
        'reaction.teyvat.lunar_charged': 'Carga Lunar', 'reaction.teyvat.lunar_bloom': 'Florescimento Lunar',
        'reaction.teyvat.lunar_crystallize': 'Cristalização Lunar', 'reaction.teyvat.burgeon': 'Brotar',
        'reaction.teyvat.hyperbloom': 'Hiperflorescer', 'reaction.teyvat.shatter': 'Estilhaçar',
        'effect.teyvat.frozen': 'Congelado', 'effect.teyvat.superconduct': 'Supercondutor',
        'effect.teyvat.quicken': 'Intensificado', 'effect.teyvat.shred': 'Resistência Reduzida',
        'death.attack.teyvat.elemental': '%1$s foi consumido(a) por energia elemental',
        'death.attack.teyvat.elemental.player': '%1$s foi consumido(a) por energia elemental de %2$s',
        'hud.teyvat.element': 'Elemento: %s',
    }
    for e in ELEMENTS:
        pt[f'element.teyvat.{e}'] = names_pt[e]
        pt[f'effect.teyvat.{e}'] = f'Aura {names_pt[e]}'
    for o in ORNAMENTS:
        pt[f'ornament.teyvat.{o}'] = orn_pt[o]
    en = dict(pt)
    en.update({
        'item.teyvat.vision': 'Vision', 'item.teyvat.stellar_axis': 'Stellar Axis', 'item.teyvat.lunar_disc': 'Lunar Disc',
        'item.teyvat.dendro_core': 'Dendro Core', 'entity.teyvat.dendro_core': 'Dendro Core',
        'curios.identifier.vision': 'Vision', 'curios.identifier.stellar_axis': 'Stellar Axis', 'curios.identifier.lunar_disc': 'Lunar Disc',
        'key.teyvat.wheel': 'Element wheel (hold)', 'key.teyvat.next': 'Next element', 'key.teyvat.prev': 'Previous element',
        'key.teyvat.skill': 'Elemental skill', 'screen.teyvat.wheel': 'Element wheel',
        'message.teyvat.no_vision': 'You need to equip a Vision (Curios slot).',
        'message.teyvat.cooldown': 'Skill on cooldown: %s s',
        'message.teyvat.bad_item': 'Hold a sword, axe, trident, bow, or keep your hand empty.',
        'message.teyvat.imbue': 'Weapon imbued with %s!', 'message.teyvat.ornament': 'Ornament: %s',
        'tooltip.teyvat.ornament': 'Ornament: %s',
        'tooltip.teyvat.shift': 'Sneak + right click to change the ornament.',
        'tooltip.teyvat.vision': 'Grants every element. Use the wheel (V) and the skill (R).',
        'tooltip.teyvat.stellar_axis': 'Enables Stellar Swirl (Anemo + Cryo).',
        'tooltip.teyvat.lunar_disc': 'Moonsign: Lunar-Charged, Lunar-Bloom and Lunar-Crystallize.',
        'reaction.teyvat.melt': 'Melt', 'reaction.teyvat.vaporize': 'Vaporize', 'reaction.teyvat.overloaded': 'Overloaded',
        'reaction.teyvat.superconduct': 'Superconduct', 'reaction.teyvat.frozen': 'Frozen', 'reaction.teyvat.swirl': 'Swirl',
        'reaction.teyvat.stellar_swirl': 'Stellar Swirl', 'reaction.teyvat.crystallize': 'Crystallize', 'reaction.teyvat.bloom': 'Bloom',
        'reaction.teyvat.burning': 'Burning', 'reaction.teyvat.quicken': 'Quicken', 'reaction.teyvat.electro_charged': 'Electro-Charged',
        'reaction.teyvat.lunar_charged': 'Lunar-Charged', 'reaction.teyvat.lunar_bloom': 'Lunar-Bloom',
        'reaction.teyvat.lunar_crystallize': 'Lunar-Crystallize', 'reaction.teyvat.burgeon': 'Burgeon',
        'reaction.teyvat.hyperbloom': 'Hyperbloom', 'reaction.teyvat.shatter': 'Shatter',
        'effect.teyvat.frozen': 'Frozen', 'effect.teyvat.superconduct': 'Superconduct', 'effect.teyvat.quicken': 'Quickened',
        'effect.teyvat.shred': 'RES Reduced',
        'death.attack.teyvat.elemental': '%1$s was consumed by elemental energy',
        'death.attack.teyvat.elemental.player': '%1$s was consumed by elemental energy from %2$s',
        'hud.teyvat.element': 'Element: %s',
    })
    for e in ELEMENTS:
        en[f'effect.teyvat.{e}'] = f'{names_pt[e]} Aura'
    jdump(pt, f'{A}/lang/pt_br.json')
    jdump(en, f'{A}/lang/en_us.json')
    print('assets ok')


main()
