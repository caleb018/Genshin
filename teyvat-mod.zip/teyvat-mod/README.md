# Teyvat Elements (NeoForge 1.21.1)

Mod focado no sistema de elementos de Genshin Impact. **Requer Curios API 9.x.**

## Itens (slots Curios)
- **Visão** (`vision`): broche no quadril. Concede todos os elementos.
- **Eixo Estelar** (`stellar_axis`): pendurado no ombro, com física de pêndulo. Habilita o *Redemoinho Estelar* (Anemo + Cryo).
- **Disco Lunar** (`lunar_disc`): nas costas, perto da nuca. Habilita o *Signo Lunar*: Carga Lunar, Florescimento Lunar, Cristalização Lunar.

O visual dos três muda com o elemento atual do jogador. O ornamento (Mondstadt, Liyue, Inazuma, Sumeru, Fontaine, Natlan, Snezhnaya)
é escolhido na aba criativa "Teyvat Elements", ou em sobrevivência com **Agachar + clique direito** com o item na mão.

## Controles (rebindáveis)
| Tecla | Ação |
|---|---|
| V (segurar) | Roda de elementos (solte ou clique para escolher) |
| X / Z | Próximo / elemento anterior (troca rápida) |
| R | Habilidade elemental |

## Habilidade elemental
- Com **espada, machado, tridente ou arco** na mão: imbui a arma (15 s) e aplica o elemento (ICD de 3 golpes / 2,5 s). Flechas levam o elemento.
- **Mão vazia**, por elemento:
  Pyro = Hu Tao, Hydro = Vodyanitsa, Anemo = Vesna (aperte R de novo para a Espada dos Ventos),
  Electro = Clorinde, Dendro = Lauma, Cryo = Eula, Geo = Xilonen.

## Reações
Vaporizar, Derreter, Sobrecarregar, Supercondutor, Eletrocarregado, Congelar (+Estilhaçar), Redemoinho, Cristalizar,
Florescer (Núcleo Dendro -> Brotar / Hiperflorescer), Queimar, Intensificar (Agravar/Propagar) e as lunares/estelares.
As auras aparecem como efeitos de poção no alvo (visíveis em qualquer mod que liste efeitos).

## Cristalização Lunar
Usa o modelo `Moondrifts_torreta_dourada.bbmodel` convertido para `assets/teyvat/models/item/moondrift_turret.json`
(textura `textures/item/moondrift_turret.png`, 32x32). Para repintar, edite o PNG mantendo o layout de UV.

## Compilar
`gradle build` (Java 21). O GitHub Actions em `.github/workflows/build.yml` já faz isso e publica o .jar como artifact.
Texturas procedurais foram geradas por `tools/gen_assets.py` (Pillow); substitua por arte final quando quiser.
