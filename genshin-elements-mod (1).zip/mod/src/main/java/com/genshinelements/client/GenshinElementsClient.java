package com.genshinelements.client;

import com.genshinelements.GenshinElementsMod;
import com.genshinelements.network.ClientState;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

/** Teclas (R roda, V/B troca, G habilidade, botão direito do mouse: ataque carregado) e registro do indicador na tela. */
@EventBusSubscriber(modid = GenshinElementsMod.MODID, value = Dist.CLIENT)
public final class GenshinElementsClient {
    private GenshinElementsClient() {}

    private static KeyMapping WHEEL, NEXT, PREV, SKILL, CHARGE;
    private static int held = 0;

    /**
     * O botão direito também é "usar item" do jogo (colocar bloco, comer, arco, escudo...).
     * Com true, o ataque carregado só começa com a mão principal vazia, para não colidir com essas ações.
     * Mude para false se quiser carregar com qualquer item na mão.
     */
    private static final boolean REQUIRE_EMPTY_HAND = true;

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        KeyMapping.Category cat = new KeyMapping.Category(GenshinElementsMod.id("main"));
        event.registerCategory(cat);
        WHEEL = new KeyMapping("key.genshinelements.wheel", InputConstants.KEY_R, cat);
        NEXT = new KeyMapping("key.genshinelements.next", InputConstants.KEY_V, cat);
        PREV = new KeyMapping("key.genshinelements.prev", InputConstants.KEY_B, cat);
        SKILL = new KeyMapping("key.genshinelements.skill", InputConstants.KEY_G, cat);
        // Botão direito do mouse (1 = GLFW_MOUSE_BUTTON_RIGHT). Pode ser trocado em Opções > Controles.
        CHARGE = new KeyMapping("key.genshinelements.charge", InputConstants.Type.MOUSE, 1, cat);
        event.register(WHEEL);
        event.register(NEXT);
        event.register(PREV);
        event.register(SKILL);
        event.register(CHARGE);
    }

    @SubscribeEvent
    public static void registerLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(GenshinElementsMod.id("element_hud"), (graphics, delta) -> ElementHud.render(graphics));
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || WHEEL == null) {
            held = 0;
            ClientState.chargeTicks = 0;
            return;
        }
        while (WHEEL.consumeClick()) {
            if (mc.gui.screen() == null) mc.gui.setScreenAndShow(new ElementWheelScreen());
        }
        while (NEXT.consumeClick()) send(mc, "ge next");
        while (PREV.consumeClick()) send(mc, "ge prev");
        while (SKILL.consumeClick()) send(mc, "ge skill");

        // Ataque carregado: segure CHARGE e solte (o servidor confere se passou de 1 s).
        boolean down = CHARGE.isDown() && mc.gui.screen() == null
                && (!REQUIRE_EMPTY_HAND || mc.player.getMainHandItem().isEmpty());
        if (down) {
            held++;
            if (held == 1) send(mc, "ge chargestart");
        } else if (held > 0) {
            send(mc, "ge chargerelease");
            held = 0;
        }
        ClientState.chargeTicks = held;
    }

    static void send(Minecraft mc, String command) {
        if (mc.player != null) mc.player.connection.sendCommand(command);
    }
}
