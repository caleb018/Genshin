package com.genshinelements.client;

import com.genshinelements.element.Element;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Roda de 7 botões em círculo: um clique escolhe o elemento e fecha a tela. */
public class ElementWheelScreen extends Screen {
    public ElementWheelScreen() {
        super(Component.translatable("screen.genshinelements.wheel"));
    }

    @Override
    protected void init() {
        Element[] els = Element.values();
        int cx = this.width / 2;
        int cy = this.height / 2;
        int radius = 62;
        for (int i = 0; i < els.length; i++) {
            double a = -Math.PI / 2 + 2 * Math.PI * i / els.length;
            int x = cx + (int) Math.round(Math.cos(a) * radius) - 36;
            int y = cy + (int) Math.round(Math.sin(a) * radius) - 10;
            Element el = els[i];
            this.addRenderableWidget(Button.builder(el.coloredName(), b -> {
                GenshinElementsClient.send(Minecraft.getInstance(), "ge element " + el.id);
                this.onClose();
            }).bounds(x, y, 72, 20).build());
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
