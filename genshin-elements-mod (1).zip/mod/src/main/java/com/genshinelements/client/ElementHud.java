package com.genshinelements.client;

import com.genshinelements.element.Element;
import com.genshinelements.network.ClientState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Indicador do elemento selecionado, à direita da hotbar, com barra do ataque carregado. */
public final class ElementHud {
    private ElementHud() {}

    public static void render(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        Element[] all = Element.values();
        Element el = all[Math.floorMod(ClientState.element, all.length)];
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int x = sw / 2 + 91 + 30;
        int y = sh - 22;
        int rgb = 0xFF000000 | el.color;

        g.fill(x - 1, y - 1, x + 21, y + 21, rgb);          // moldura
        g.fill(x, y, x + 20, y + 20, 0xFF161616);           // fundo
        g.fill(x + 4, y + 4, x + 16, y + 16, rgb);          // "gema" do elemento
        g.text(mc.font, el.displayName, x - 2, y - 10, rgb, true);

        int held = ClientState.chargeTicks;
        if (held > 0) {                                      // barra de carga (cheia = pronto para soltar)
            int w = Math.min(20, held);
            g.fill(x, y + 22, x + 20, y + 25, 0xFF000000);
            g.fill(x, y + 22, x + w, y + 25, held >= 20 ? 0xFFFFFFFF : rgb);
        }
    }
}
