package com.genshinelements.command;

import com.genshinelements.element.Element;
import com.genshinelements.element.ElementManager;
import com.genshinelements.element.LunarManager;
import com.genshinelements.element.StellarManager;
import com.genshinelements.item.ModItems;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.Arrays;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/** /ge element <nome> | next | prev | skill | chargestart | chargerelease | artefatos | status  (o cliente usa nas teclas). */
public final class ModCommands {
    private ModCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("ge")
                .then(Commands.literal("element")
                        .then(Commands.argument("nome", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(
                                        Arrays.stream(Element.values()).map(e -> e.id), b))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    Element e = Element.byId(StringArgumentType.getString(ctx, "nome"));
                                    if (e == null) {
                                        p.sendSystemMessage(Component.literal("Elemento inválido.")
                                                .withStyle(ChatFormatting.RED));
                                        return 0;
                                    }
                                    ElementManager.select(p, e);
                                    return 1;
                                })))
                .then(Commands.literal("next").executes(ctx -> {
                    ElementManager.cycle(ctx.getSource().getPlayerOrException(), 1);
                    return 1;
                }))
                .then(Commands.literal("prev").executes(ctx -> {
                    ElementManager.cycle(ctx.getSource().getPlayerOrException(), -1);
                    return 1;
                }))
                .then(Commands.literal("skill").executes(ctx -> {
                    ElementManager.castSkill(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("chargestart").executes(ctx -> {
                    ElementManager.chargeStart(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("chargerelease").executes(ctx -> {
                    ElementManager.chargeRelease(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("artefatos").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    p.getInventory().add(new ItemStack(ModItems.STAR_AXIS.get()));
                    p.getInventory().add(new ItemStack(ModItems.FROZEN_MOON_SONG.get()));
                    return 1;
                }))
                .then(Commands.literal("status").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    int lv = LunarManager.moonsign(p);
                    String sign = lv == 0 ? "inativo" : lv == 1 ? "Brilho Nascente" : "Brilho Ascendente";
                    String stellar = StellarManager.enabled(p) ? "ativas" : "inativas";
                    p.sendSystemMessage(Component.literal("Elemento: ")
                            .append(ElementManager.selected(p.getUUID()).coloredName())
                            .append(Component.literal("  |  Signo Lunar: " + sign + "  |  Estelares: " + stellar)));
                    return 1;
                })));
    }
}
