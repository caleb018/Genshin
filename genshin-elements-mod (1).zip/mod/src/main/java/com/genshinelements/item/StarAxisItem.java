package com.genshinelements.item;

import com.genshinelements.element.LunarManager;
import com.genshinelements.element.StellarManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class StarAxisItem extends Item {
    public StarAxisItem(Properties properties) {
        super(properties);
    }

    /** Clique direito mostra o Signo Lunar atual e se as reações Estelares estão ativas. */
    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (player instanceof ServerPlayer sp) {
            int lv = LunarManager.moonsign(sp);
            String moon = switch (lv) {
                case 0 -> "inativo";
                case 1 -> "Brilho Nascente";
                default -> "Brilho Ascendente";
            };
            String stellar = StellarManager.enabled(sp) ? "ativas" : "inativas";
            sp.sendSystemMessage(Component.literal("Signo Lunar: " + moon + "  |  Reações Estelares: " + stellar)
                    .withStyle(lv >= 2 ? ChatFormatting.GOLD : ChatFormatting.AQUA), true);
        }
        return InteractionResult.SUCCESS;
    }
}
