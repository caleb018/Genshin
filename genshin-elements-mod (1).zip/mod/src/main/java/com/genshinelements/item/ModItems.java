package com.genshinelements.item;

import com.genshinelements.GenshinElementsMod;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(GenshinElementsMod.MODID);

    /** Artefato 1: Eixo Estelar (slot Curios "star_axis"). Habilita as reações Estelares. */
    public static final DeferredItem<Item> STAR_AXIS = ITEMS.registerItem("star_axis",
            StarAxisItem::new, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

    /** Artefato 2: Canção da Lua Gelada (slot Curios "moon_song"). */
    public static final DeferredItem<Item> FROZEN_MOON_SONG = ITEMS.registerItem("frozen_moon_song",
            Item::new, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

    /** Item que só existe para carregar o modelo da torreta Moondrift. */
    public static final DeferredItem<Item> MOONDRIFT = ITEMS.registerSimpleItem("moondrift");
}
