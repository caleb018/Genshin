package com.genshinelements;

import com.genshinelements.command.ModCommands;
import com.genshinelements.element.ElementManager;
import com.genshinelements.element.LunarManager;
import com.genshinelements.item.ModItems;
import com.genshinelements.network.ClientState;
import com.genshinelements.network.ElementSyncPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

@Mod(GenshinElementsMod.MODID)
public class GenshinElementsMod {
    public static final String MODID = "genshinelements";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MODID, path);
    }

    public GenshinElementsMod(IEventBus modBus) {
        ModItems.ITEMS.register(modBus);
        modBus.addListener(this::registerPayloads);
        modBus.addListener(this::buildTabs);

        NeoForge.EVENT_BUS.addListener(this::registerCommands);
        NeoForge.EVENT_BUS.addListener((ServerTickEvent.Post e) -> ElementManager.tick(e.getServer()));
        NeoForge.EVENT_BUS.addListener((ServerStartedEvent e) -> LunarManager.cleanupOrphans(e.getServer()));
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedInEvent e) -> {
            if (e.getEntity() instanceof ServerPlayer sp) ElementManager.load(sp);
        });
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent e) ->
                ElementManager.forget(e.getEntity().getUUID()));
        NeoForge.EVENT_BUS.addListener(this::onDamage);
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(ElementSyncPayload.TYPE, ElementSyncPayload.CODEC,
                (payload, ctx) -> ClientState.element = payload.element());
    }

    private void buildTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.STAR_AXIS.get());
            event.accept(ModItems.FROZEN_MOON_SONG.get());
        }
    }

    private void registerCommands(RegisterCommandsEvent event) {
        ModCommands.register(event.getDispatcher());
    }

    /** Todo golpe do jogador (corpo a corpo ou projétil) aplica o elemento selecionado. */
    private void onDamage(LivingDamageEvent.Post event) {
        if (ElementManager.inReaction()) return;
        float taken = event.getNewDamage();
        if (taken <= 0f) return;
        var entity = event.getEntity();
        var source = event.getSource();
        if (!(source.getEntity() instanceof ServerPlayer player) || entity == player) return;
        Entity direct = source.getDirectEntity();
        if (direct != player && !(direct instanceof Projectile)) return;
        ElementManager.onPlayerHit(entity, player, taken);
    }
}
