package com.genshinelements.element;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.phys.Vec3;

/**
 * Marca elemental flutuando na mão principal do jogador, uma por elemento/arconte:
 * <ul>
 *   <li>PYRO    - chamas de cabelo da Mavuika (cinco línguas de fogo ondulantes + anel solar de Natlan)</li>
 *   <li>HYDRO   - gota de Focalors com órbitas e pérolas de água</li>
 *   <li>ELECTRO - olho violeta da Raiden Shogun (pisca, íris, pupila em fenda e faíscas)</li>
 *   <li>CRYO    - floco de gelo de seis braços da Tsaritsa, com pontas de coroa</li>
 *   <li>ANEMO   - ciclone de dois braços de Barbatos com penas orbitando</li>
 *   <li>GEO     - selo hexagonal de Morax com losango geo e cristais orbitando</li>
 *   <li>DENDRO  - interface do Terminal Akasha (anéis, hexágono, circuitos e folha)</li>
 * </ul>
 * Tudo é feito com partículas enviadas pelo servidor, então todos os jogadores próximos enxergam.
 * Segurar o ataque carregado faz o símbolo crescer, girar mais e brilhar quando está pronto.
 */
public final class HandEffects {
    private HandEffects() {}

    /** A cada quantos ticks o símbolo é redesenhado (partículas de poeira duram ~5-25 ticks). */
    private static final int PERIOD = 3;

    /** Posição da mão em relação ao olho: à frente, ao lado e para baixo (ajuste aqui se ficar fora do lugar). */
    private static final double HAND_FWD = 0.72;
    private static final double HAND_SIDE = 0.44;
    private static final double HAND_DOWN = 0.30;
    /** O símbolo flutua um pouco acima da mão. */
    private static final double HOVER = 0.16;

    public static void tick(MinecraftServer server, long now) {
        if (now % PERIOD != 0) return;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isSpectator() || !p.isAlive()) continue;
            if (!(p.level() instanceof ServerLevel sl)) continue;

            Element el = ElementManager.selected(p.getUUID());
            int held = ElementManager.chargeHeld(p.getUUID());
            double charge = Math.min(1.0, held / 20.0);

            Vec3 f = p.getLookAngle().normalize();
            Vec3 right = new Vec3(-f.z, 0, f.x);
            if (right.lengthSqr() < 1.0E-4) right = new Vec3(1, 0, 0); // olhando reto para cima/baixo
            right = right.normalize();
            Vec3 up = right.cross(f).normalize();
            double side = p.getMainArm() == HumanoidArm.RIGHT ? 1.0 : -1.0;

            Vec3 center = p.getEyePosition()
                    .add(f.scale(HAND_FWD))
                    .add(right.scale(HAND_SIDE * side))
                    .add(up.scale(-HAND_DOWN + HOVER));

            double breathe = 1.0 + 0.05 * Math.sin(now * 0.2);
            Frame g = new Frame(sl, center, right, up, (1.0 + 0.45 * charge) * breathe);

            switch (el) {
                case PYRO -> pyro(g, now);
                case HYDRO -> hydro(g, now);
                case ELECTRO -> electro(g, now);
                case CRYO -> cryo(g, now);
                case ANEMO -> anemo(g, now);
                case GEO -> geo(g, now);
                case DENDRO -> dendro(g, now);
            }

            if (charge > 0) {
                // anel de energia que se fecha enquanto carrega; faíscas quando está pronto
                g.ring(0, 0, 0.32, 10, now * 0.35, new DustParticleOptions(el.color, 0.8f));
                if (held >= 20) {
                    g.spark(ParticleTypes.END_ROD, g.rnd(0.3), g.rnd(0.3), 0.01);
                    g.spark(ParticleTypes.END_ROD, g.rnd(0.3), g.rnd(0.3), 0.01);
                }
            }
        }
    }

    // ------------------------------------------------------------------ PYRO (Mavuika)

    private static void pyro(Frame g, long now) {
        double t = now * 0.15;
        ParticleOptions core = grad(0xFFF4B0, 0xFFB22E, 0.65f);   // base quase branca/amarela
        ParticleOptions mid = grad(0xFF9A1F, 0xF03C0C, 0.65f);    // laranja -> vermelho
        ParticleOptions edge = grad(0xFF4A12, 0x8A0A00, 0.55f);   // pontas em brasa

        // anel solar de Natlan sob as chamas
        g.ring(0, -0.02, 0.15, 8, t * 0.6, grad(0xFFC93A, 0xFF5A14, 0.6f));

        // cinco línguas de fogo como as mechas flamejantes do cabelo: a central é a mais alta, as pontas se curvam
        for (int i = 0; i < 5; i++) {
            double lean = (i - 2);
            double base = lean * 0.07;
            double len = (i == 2 ? 0.36 : (i % 2 == 0 ? 0.27 : 0.21)) * (1 + 0.12 * Math.sin(t * 2 + i * 1.7));
            int n = 4;
            for (int j = 1; j <= n; j++) {
                double s = j / (double) n;
                double sway = Math.sin(t * 1.6 + i * 1.3 + s * 2.4) * 0.045 * s;
                double curl = lean * 0.035 * s * s;
                double a = base + sway + curl;
                double b = 0.02 + s * len;
                g.put(a, b, s < 0.4 ? core : (s < 0.8 ? mid : edge));
            }
            if ((now / PERIOD + i) % 3 == 0) {
                g.spark(ParticleTypes.SMALL_FLAME, base + lean * 0.035, 0.02 + len, 0.01);
            }
        }
        if (now % 6 == 0) g.spark(ParticleTypes.FLAME, g.rnd(0.12), 0.1, 0.015);
    }

    // ------------------------------------------------------------------ HYDRO (Focalors)

    private static void hydro(Frame g, long now) {
        double t = now * 0.08;
        ParticleOptions drop = grad(0x9BE4FF, 0x2E6BFF, 0.7f);
        ParticleOptions orbit = grad(0x6FD3FF, 0x2F7BFF, 0.55f);
        ParticleOptions pearl = new DustParticleOptions(0xE6F9FF, 0.9f);

        // gota central (ponta para cima)
        double a = 0.13;
        for (int i = 0; i < 14; i++) {
            double th = i * 2 * Math.PI / 14;
            g.put(a * Math.sin(th) * Math.sin(th / 2), -a * Math.cos(th) * 0.95, drop);
        }
        g.put(-0.03, -0.04, new DustParticleOptions(0xFFFFFF, 0.5f)); // brilho dentro da gota
        g.put(-0.04, -0.01, new DustParticleOptions(0xFFFFFF, 0.4f));

        // duas órbitas inclinadas se cruzando
        for (int k = 0; k < 2; k++) {
            double phi = t * (k == 0 ? 1 : -1) + k * Math.PI / 2;
            double cp = Math.cos(phi), sp = Math.sin(phi);
            for (int i = 0; i < 10; i++) {
                double th = i * 2 * Math.PI / 10;
                double x = 0.25 * Math.cos(th), y = 0.25 * 0.38 * Math.sin(th);
                g.put(x * cp - y * sp, x * sp + y * cp, orbit);
            }
        }
        // três pérolas orbitando a gota
        for (int k = 0; k < 3; k++) {
            double th = t * 2.2 + k * 2 * Math.PI / 3;
            g.put(0.25 * Math.cos(th), 0.25 * Math.sin(th) * 0.9, pearl);
        }
        if (now % 6 == 0) g.spark(ParticleTypes.FALLING_WATER, g.rnd(0.1), -0.18, 0.0);
        if (now % 9 == 0) g.spark(ParticleTypes.SPLASH, g.rnd(0.15), -0.15, 0.02);
    }

    // ------------------------------------------------------------------ ELECTRO (Raiden Shogun)

    private static void electro(Frame g, long now) {
        double w = 0.22;
        // pisca a cada 3,5 s
        long ph = now % 70;
        double open = ph < 6 ? 0.15 + 0.85 * Math.abs(ph - 3) / 3.0 : 1.0;
        double h = 0.10 * open;

        ParticleOptions lid = grad(0xD9A0FF, 0x9B3CFF, 0.65f);
        ParticleOptions lash = new DustParticleOptions(0xB86CFF, 0.55f);
        ParticleOptions iris = grad(0xF0CCFF, 0xB050FF, 0.65f);
        ParticleOptions pupil = new DustParticleOptions(0x6A12D8, 0.55f);

        // pálpebras (amêndoa)
        for (int i = 0; i <= 8; i++) {
            double x = -w + 2 * w * i / 8.0;
            double c = 1 - (x / w) * (x / w);
            g.put(x, h * c, lid);
            if (i > 0 && i < 8) g.put(x, -h * 0.8 * c, lid);
        }
        // cílios nos dois cantos
        g.put(-w - 0.04, 0.03, lash);
        g.put(-w - 0.08, 0.06, lash);
        g.put(w + 0.04, 0.03, lash);
        g.put(w + 0.08, 0.06, lash);

        if (open > 0.5) {
            // íris + pupila em losango/fenda + brilho
            g.ring(0, 0, 0.068, 8, now * 0.1, iris);
            g.put(0, 0.04, pupil);
            g.put(0, 0.0, pupil);
            g.put(0, -0.04, pupil);
            g.put(0.025, 0.035, new DustParticleOptions(0xFFFFFF, 0.45f));
        }
        // raios ao redor do olho
        g.spark(ParticleTypes.ELECTRIC_SPARK, g.rnd(w + 0.05), g.rnd(0.16), 0.02);
        if (now % 6 == 0) g.spark(ParticleTypes.ELECTRIC_SPARK, g.rnd(w), g.rnd(0.2), 0.04);
    }

    // ------------------------------------------------------------------ CRYO (Tsaritsa)

    private static void cryo(Frame g, long now) {
        double t = now * 0.025;
        ParticleOptions arm = grad(0xFFFFFF, 0x6FD6FF, 0.6f);
        ParticleOptions barb = new DustParticleOptions(0x9FE8FF, 0.5f);
        ParticleOptions crown = new DustParticleOptions(0xFFFFFF, 0.8f);

        for (int k = 0; k < 6; k++) {
            double ang = t + k * Math.PI / 3;
            double dx = Math.cos(ang), dy = Math.sin(ang);
            g.put(dx * 0.08, dy * 0.08, arm);
            g.put(dx * 0.16, dy * 0.16, arm);
            g.put(dx * 0.26, dy * 0.26, crown);      // ponta em cristal, como a coroa da Tsaritsa
            // farpas a 60 graus em cada lado, na metade do braço
            for (int s = -1; s <= 1; s += 2) {
                double ba = ang + s * Math.PI / 3;
                g.put(dx * 0.17 + Math.cos(ba) * 0.055, dy * 0.17 + Math.sin(ba) * 0.055, barb);
            }
        }
        g.put(0, 0, new DustParticleOptions(0xFFFFFF, 0.9f));
        if (now % 6 == 0) g.spark(ParticleTypes.SNOWFLAKE, g.rnd(0.25), g.rnd(0.25), 0.01);
    }

    // ------------------------------------------------------------------ ANEMO (Barbatos)

    private static void anemo(Frame g, long now) {
        double t = now * 0.12;
        ParticleOptions swirl = grad(0xD8FFF4, 0x2FD6A8, 0.6f);
        ParticleOptions blade = new DustParticleOptions(0x5CE6C0, 0.55f);
        ParticleOptions feather = new DustParticleOptions(0xF2FFFB, 0.6f);

        // ciclone de dois braços
        for (int arm = 0; arm < 2; arm++) {
            for (int i = 0; i < 7; i++) {
                double r = 0.04 + i * 0.032;
                double th = arm * Math.PI + r * 16 + t * 2.5;
                g.put(Math.cos(th) * r, Math.sin(th) * r, swirl);
            }
        }
        // três lâminas de vento curvas em anel externo
        for (int k = 0; k < 3; k++) {
            for (int i = 0; i < 4; i++) {
                double th = -t + k * 2 * Math.PI / 3 + i * 0.16;
                g.put(Math.cos(th) * 0.27, Math.sin(th) * 0.27, blade);
            }
        }
        // duas penas orbitando
        for (int k = 0; k < 2; k++) {
            double th = -t * 1.3 + k * Math.PI;
            double bx = Math.cos(th) * 0.2, by = Math.sin(th) * 0.2;
            double tx = -Math.sin(th), ty = Math.cos(th);
            g.put(bx, by, feather);
            g.put(bx + tx * 0.04 + Math.cos(th) * 0.015, by + ty * 0.04 + Math.sin(th) * 0.015, feather);
            g.put(bx + tx * 0.075 + Math.cos(th) * 0.035, by + ty * 0.075 + Math.sin(th) * 0.035, feather);
        }
        if (now % 6 == 0) g.spark(ParticleTypes.CLOUD, g.rnd(0.2), g.rnd(0.2), 0.02);
    }

    // ------------------------------------------------------------------ GEO (Morax)

    private static void geo(Frame g, long now) {
        double t = now * 0.05;
        ParticleOptions gold = new DustParticleOptions(0xF0C040, 0.65f);
        ParticleOptions glow = grad(0xFFF0A0, 0xE0901E, 0.6f);
        ParticleOptions shard = new DustParticleOptions(0xC27A18, 0.85f);

        // selo hexagonal (3 pontos por lado)
        double R = 0.23;
        for (int i = 0; i < 6; i++) {
            double a1 = Math.PI / 6 + i * Math.PI / 3, a2 = a1 + Math.PI / 3;
            double x1 = Math.cos(a1) * R, y1 = Math.sin(a1) * R, x2 = Math.cos(a2) * R, y2 = Math.sin(a2) * R;
            for (int j = 0; j < 3; j++) {
                double s = j / 3.0;
                g.put(x1 + (x2 - x1) * s, y1 + (y2 - y1) * s, gold);
            }
        }
        // losango geo no centro
        double hw = 0.09, hh = 0.15;
        double[][] v = {{0, hh}, {hw, 0}, {0, -hh}, {-hw, 0}};
        for (int i = 0; i < 4; i++) {
            double[] a = v[i], b = v[(i + 1) % 4];
            for (int j = 0; j < 3; j++) {
                double s = j / 3.0;
                g.put(a[0] + (b[0] - a[0]) * s, a[1] + (b[1] - a[1]) * s, glow);
            }
        }
        g.put(0, 0, new DustParticleOptions(0xFFF6C0, 0.9f));
        // três cristais orbitando devagar
        for (int k = 0; k < 3; k++) {
            double th = t + k * 2 * Math.PI / 3;
            g.put(Math.cos(th) * 0.3, Math.sin(th) * 0.3, shard);
        }
        if (now % 9 == 0) g.spark(ParticleTypes.CRIT, g.rnd(0.2), g.rnd(0.2), 0.02);
    }

    // ------------------------------------------------------------------ DENDRO (Terminal Akasha)

    private static void dendro(Frame g, long now) {
        double t = now * 0.04;
        ParticleOptions ringC = new DustParticleOptions(0x8BD43B, 0.6f);
        ParticleOptions hexC = grad(0xD6FF7A, 0x6FE35A, 0.55f);
        ParticleOptions trace = new DustParticleOptions(0x3DE0A0, 0.5f);
        ParticleOptions node = new DustParticleOptions(0xEFFFB8, 0.8f);
        ParticleOptions leaf = grad(0xC4FF55, 0x4DBB2A, 0.6f);

        // anel externo com 4 aberturas (gira)
        for (int i = 0; i < 16; i++) {
            if (i % 4 == 3) continue;
            double th = t + i * 2 * Math.PI / 16;
            g.put(Math.cos(th) * 0.25, Math.sin(th) * 0.25, ringC);
        }
        // hexágono interno girando ao contrário (vértices + pontos médios)
        double R = 0.15;
        for (int i = 0; i < 6; i++) {
            double a1 = -t * 1.5 + i * Math.PI / 3, a2 = a1 + Math.PI / 3;
            double x1 = Math.cos(a1) * R, y1 = Math.sin(a1) * R, x2 = Math.cos(a2) * R, y2 = Math.sin(a2) * R;
            g.put(x1, y1, hexC);
            g.put((x1 + x2) / 2, (y1 + y2) / 2, hexC);
        }
        // três trilhas de circuito do hexágono até o anel, cada uma terminando num nó de dados
        for (int k = 0; k < 3; k++) {
            double a = -t * 1.5 + k * 2 * Math.PI / 3;
            double c = Math.cos(a), s = Math.sin(a);
            g.put(c * 0.19, s * 0.19, trace);
            g.put(c * 0.225, s * 0.225, trace);
            g.put(c * 0.265, s * 0.265, node);
        }
        // folha (vesica) com nervura no centro do terminal
        double[] ys = {-1, -0.5, 0, 0.5, 1};
        for (double y : ys) {
            double wv = 0.035 * (1 - y * y);
            g.put(wv, y * 0.085, leaf);
            if (wv > 0) g.put(-wv, y * 0.085, leaf);
        }
        if (now % 6 == 0) g.spark(ParticleTypes.HAPPY_VILLAGER, g.rnd(0.22), g.rnd(0.22), 0.0);
    }

    // ------------------------------------------------------------------ utilidades

    private static ParticleOptions grad(int from, int to, float scale) {
        return new DustColorTransitionOptions(from, to, scale);
    }

    /** Plano do símbolo: centro + eixos (direita, cima) da câmera do jogador, para que ele veja o desenho de frente. */
    private record Frame(ServerLevel sl, Vec3 c, Vec3 r, Vec3 u, double k) {
        Vec3 at(double a, double b) {
            return c.add(r.scale(a * k)).add(u.scale(b * k));
        }

        void put(double a, double b, ParticleOptions o) {
            Vec3 p = at(a, b);
            sl.sendParticles(o, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }

        void spark(ParticleOptions o, double a, double b, double speed) {
            Vec3 p = at(a, b);
            sl.sendParticles(o, p.x, p.y, p.z, 1, 0.01, 0.01, 0.01, speed);
        }

        void ring(double cx, double cy, double rad, int n, double rot, ParticleOptions o) {
            for (int i = 0; i < n; i++) {
                double th = rot + i * 2 * Math.PI / n;
                put(cx + Math.cos(th) * rad, cy + Math.sin(th) * rad, o);
            }
        }

        double rnd(double range) {
            return (sl.getRandom().nextDouble() * 2 - 1) * range;
        }
    }
}
