package com.genshinelements.element;

import com.genshinelements.item.ModItems;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import top.theillusivec4.curios.api.CuriosApi;

/**
 * Único ponto de contato com o Curios: lê os artefatos equipados nos slots Curios.
 * Resultado em cache por 10 ticks (as reações consultam isso várias vezes por golpe).
 */
public final class MoonGear {
    private MoonGear() {}

    private static final Map<UUID, long[]> CACHE = new HashMap<>(); // {tick, moonsign, stellar}

    private static boolean has(ServerPlayer p, Item item) {
        return CuriosApi.getCuriosInventory(p).map(inv -> inv.isEquipped(item)).orElse(false);
    }

    private static long[] get(ServerPlayer p) {
        long now = ElementManager.now();
        long[] c = CACHE.get(p.getUUID());
        if (c != null && now - c[0] < 10) return c;
        boolean axis = has(p, ModItems.STAR_AXIS.get());
        boolean song = has(p, ModItems.FROZEN_MOON_SONG.get());
        c = new long[] {now, (axis ? 1 : 0) + (song ? 1 : 0), axis ? 1 : 0};
        CACHE.put(p.getUUID(), c);
        return c;
    }

    /** 0 = inativo, 1 = Brilho Nascente (um artefato), 2 = Brilho Ascendente (os dois). */
    public static int moonsign(ServerPlayer p) {
        return p == null ? 0 : (int) get(p)[1];
    }

    /** Reações Estelares exigem o Eixo Estelar equipado. */
    public static boolean stellar(ServerPlayer p) {
        return p != null && get(p)[2] == 1;
    }

    public static void forget(UUID id) {
        CACHE.remove(id);
    }
}
