package com.genshinelements.element;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import com.genshinelements.network.ElementSyncPayload;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.network.PacketDistributor;
import net.minecraft.world.phys.Vec3;

/**
 * Núcleo do sistema elemental: auras (gauge em "unidades"), decaimento, ICD,
 * reações amplificadoras / transformativas e a habilidade elemental do jogador.
 * Tudo roda no servidor e fica em memória (não persiste entre reinícios).
 */
public final class ElementManager {
    private ElementManager() {}

    private static final int N = Element.values().length;
    private static final int PYRO = Element.PYRO.ordinal();
    private static final int HYDRO = Element.HYDRO.ordinal();
    private static final int ELECTRO = Element.ELECTRO.ordinal();
    private static final int CRYO = Element.CRYO.ordinal();
    private static final int DENDRO = Element.DENDRO.ordinal();

    private static final Map<UUID, State> STATES = new HashMap<>();
    private static final Map<UUID, Element> SELECTED = new HashMap<>();
    private static final Map<UUID, Long> SKILL_CD = new HashMap<>();
    private static int depth = 0;       // >0 enquanto causamos dano de reação (evita loop)
    private static int swirlDepth = 0;  // limita cadeia de Difusão
    private static long now = 0;
    private static boolean charged = false; // true durante um ataque carregado
    private static final Map<UUID, Long> CHARGE_START = new HashMap<>();
    private static final Map<UUID, Long> CHARGE_CD = new HashMap<>();
    private static final String TAG = "ge_el_"; // tag do jogador: persiste o elemento escolhido

    static final class State {
        final LivingEntity entity;
        final double[] gauge = new double[N];
        final double[] init = new double[N];
        double quicken, quickenInit;
        int frozen, superTicks, ecCd, burnCd;
        long touched;
        UUID owner;
        final int[] icdHits = new int[N];
        final long[] icdLast = new long[N];

        State(LivingEntity e) {
            entity = e;
            Arrays.fill(icdLast, -100000L);
        }
    }

    // ------------------------------------------------------------------ seleção

    public static Element selected(UUID id) { return SELECTED.getOrDefault(id, Element.PYRO); }

    public static void select(ServerPlayer p, Element e) {
        SELECTED.put(p.getUUID(), e);
        for (String t : new ArrayList<>(p.entityTags())) {
            if (t.startsWith(TAG)) p.removeTag(t);
        }
        p.addTag(TAG + e.id); // tags do jogador são salvas com o personagem
        p.sendSystemMessage(Component.literal("Elemento: ").append(e.coloredName()), true);
        sync(p);
    }

    /** Ao entrar no mundo: recupera o elemento salvo e manda ao cliente. */
    public static void load(ServerPlayer p) {
        for (String t : p.entityTags()) {
            if (t.startsWith(TAG)) {
                Element e = Element.byId(t.substring(TAG.length()));
                if (e != null) SELECTED.put(p.getUUID(), e);
            }
        }
        sync(p);
    }

    public static void sync(ServerPlayer p) {
        PacketDistributor.sendToPlayer(p, new ElementSyncPayload(selected(p.getUUID()).ordinal()));
    }

    /** Aplica impulso horizontal equivalente ao antigo knockback(strength, x, z). */
    public static void knockback(LivingEntity entity, double strength, double x, double z) {
        Vec3 direction = new Vec3(x, 0.0, z);
        if (direction.lengthSqr() < 1.0E-8) return;
        entity.addDeltaMovement(direction.normalize().scale(strength));
    }

    public static long now() { return now; }

    public static void setCharged(boolean b) { charged = b; }

    // ---- ataque carregado (segurar 1 s e soltar)

    public static void chargeStart(ServerPlayer p) {
        CHARGE_START.put(p.getUUID(), now);
    }

    /** Ticks que o jogador está segurando o ataque carregado (0 se não está carregando). */
    public static int chargeHeld(UUID id) {
        Long st = CHARGE_START.get(id);
        return st == null ? 0 : (int) (now - st);
    }

    public static void chargeRelease(ServerPlayer p) {
        Long st = CHARGE_START.remove(p.getUUID());
        if (st == null || now - st < 20) return;
        if (now < CHARGE_CD.getOrDefault(p.getUUID(), 0L)) return;
        CHARGE_CD.put(p.getUUID(), now + 30);
        ChargedAttacks.fire(p);
    }

    public static void cycle(ServerPlayer p, int dir) {
        Element cur = selected(p.getUUID());
        select(p, dir >= 0 ? cur.next() : cur.prev());
    }

    public static void forget(UUID id) {
        SELECTED.remove(id);
        SKILL_CD.remove(id);
        CHARGE_START.remove(id);
        CHARGE_CD.remove(id);
        MoonGear.forget(id);
        LunarManager.forget(id);
        StellarManager.forget(id);
    }

    public static boolean inReaction() { return depth > 0; }

    // ------------------------------------------------------------------ eventos

    /** Chamado após cada golpe (corpo a corpo ou projétil) do jogador. */
    public static void onPlayerHit(LivingEntity target, ServerPlayer sp, float dmg) {
        Element el = selected(sp.getUUID());
        State s = STATES.computeIfAbsent(target.getUUID(), k -> new State(target));
        s.touched = now;
        s.owner = sp.getUUID();

        // Estilhaçar: golpe pesado (>= 6) ou Geo em inimigo congelado
        if (s.frozen > 0 && (dmg >= 6f || el == Element.GEO)) {
            s.frozen = 0;
            target.removeEffect(MobEffects.SLOWNESS);
            if (target.level() instanceof ServerLevel sl) {
                hurt(target, sp, 5f, false);
                fx(sl, center(target), ParticleTypes.SNOWFLAKE, 20, 0.4);
                sound(sl, center(target), SoundEvents.GLASS_BREAK);
            }
            msg(sp, "Estilhaçar", ChatFormatting.AQUA);
        }
        // Superconduzir: -40% de resistência física
        if (s.superTicks > 0) hurt(target, sp, dmg * 0.4f, false);

        // ICD: aplica no 1º golpe e depois a cada 3 golpes ou 2,5 s
        int i = el.ordinal();
        s.icdHits[i]++;
        if (now - s.icdLast[i] >= 50 || s.icdHits[i] >= 3) {
            s.icdHits[i] = 0;
            s.icdLast[i] = now;
            applyElement(target, el, 1.0, sp, dmg);
        }
        if (StellarManager.enabled(sp)) StellarManager.onPlayerHit(sp, target, el, dmg, now);
    }

    /** Remove resistência física (-40% via dano extra nos golpes) por {@code ticks}. */
    public static void shred(LivingEntity e, ServerPlayer owner, int ticks) {
        State s = STATES.computeIfAbsent(e.getUUID(), k -> new State(e));
        s.touched = now;
        if (owner != null) s.owner = owner.getUUID();
        s.superTicks = Math.max(s.superTicks, ticks);
    }

    public static void tick(MinecraftServer server) {
        now++;
        LunarManager.tick(server);
        Totems.tick(server);
        HandEffects.tick(server, now);
        if (!CHARGE_START.isEmpty()) {
            for (Map.Entry<UUID, Long> en : CHARGE_START.entrySet()) {
                ServerPlayer cp = server.getPlayerList().getPlayer(en.getKey());
                if (cp == null || !(cp.level() instanceof ServerLevel csl)) continue;
                long held = now - en.getValue();
                if (held % 4 == 0) {
                    Vec3 hp = cp.position().add(0, 1.0, 0);
                    csl.sendParticles(dust(selected(en.getKey()), 0.7f), hp.x, hp.y, hp.z, 3, 0.5, 0.6, 0.5, 0);
                }
                if (held == 20) sound(csl, cp.position(), SoundEvents.AMETHYST_BLOCK_CHIME);
            }
        }

        Iterator<State> it = STATES.values().iterator();
        while (it.hasNext()) {
            State s = it.next();
            LivingEntity e = s.entity;
            if (e.isRemoved() || !e.isAlive() || !(e.level() instanceof ServerLevel sl)) {
                it.remove();
                continue;
            }
            boolean any = false;
            for (int i = 0; i < N; i++) {
                if (s.gauge[i] > 0) {
                    any = true;
                    s.gauge[i] = Math.max(0, s.gauge[i] - 1.0 / ((2.5 * s.init[i] + 7.0) * 20.0));
                }
            }
            if (s.quicken > 0) {
                any = true;
                s.quicken = Math.max(0, s.quicken - 1.0 / ((2.5 * Math.max(1, s.quickenInit) + 7.0) * 20.0));
            }
            ServerPlayer owner = s.owner == null ? null : server.getPlayerList().getPlayer(s.owner);
            Vec3 c = center(e);

            if (s.frozen > 0) {
                any = true;
                s.frozen--;
                if (s.frozen % 10 == 0) {
                    e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 15, 6, false, false));
                    sl.sendParticles(ParticleTypes.SNOWFLAKE, c.x, c.y, c.z, 3, 0.3, 0.4, 0.3, 0.01);
                }
            }
            if (s.superTicks > 0) { any = true; s.superTicks--; }

            // Eletrocarregado: Hydro + Electro coexistindo causam dano em cadeia a cada 1 s
            if (s.gauge[HYDRO] > 0 && s.gauge[ELECTRO] > 0) {
                if (--s.ecCd <= 0) {
                    s.ecCd = 20;
                    hurt(e, owner, 2f, false);
                    sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 8, 0.4, 0.5, 0.4, 0.2);
                    for (LivingEntity n : near(sl, c, 3.0, owner)) {
                        if (n == e) continue;
                        State ns = STATES.get(n.getUUID());
                        if (ns != null && ns.gauge[HYDRO] > 0) hurt(n, owner, 1.5f, false);
                    }
                    s.gauge[HYDRO] = Math.max(0, s.gauge[HYDRO] - 0.4);
                    s.gauge[ELECTRO] = Math.max(0, s.gauge[ELECTRO] - 0.4);
                }
            } else {
                s.ecCd = 0;
            }

            // Queimar: Pyro + Dendro coexistindo queimam o alvo até o Dendro acabar
            if (s.gauge[PYRO] > 0 && s.gauge[DENDRO] > 0) {
                if (--s.burnCd <= 0) {
                    s.burnCd = 10;
                    hurt(e, owner, 1f, false);
                    e.setRemainingFireTicks(40);
                    s.gauge[DENDRO] = Math.max(0, s.gauge[DENDRO] - 0.15);
                    s.gauge[PYRO] = Math.max(s.gauge[PYRO], 0.4);
                    s.init[PYRO] = Math.max(s.init[PYRO], 1.0);
                }
            } else {
                s.burnCd = 0;
            }

            // partículas da aura
            if (now % 10 == 0) {
                for (Element el : Element.values()) {
                    if (el.hasAura() && s.gauge[el.ordinal()] > 0) {
                        sl.sendParticles(dust(el, 0.8f), c.x, c.y, c.z, 2, 0.3, 0.4, 0.3, 0);
                    }
                }
                if (s.quicken > 0) sl.sendParticles(dust(0x58E08A, 0.8f), c.x, c.y, c.z, 2, 0.3, 0.4, 0.3, 0);
            }

            if (!any && now - s.touched > 200) it.remove();
        }
    }

    // ------------------------------------------------------------------ aplicação

    /** Aplica {@code units} de {@code el} (1U, 2U, 4U...) e resolve as reações. */
    public static void applyElement(LivingEntity target, Element el, double units, ServerPlayer owner, float hit) {
        if (!(target.level() instanceof ServerLevel sl)) return;
        State s = STATES.computeIfAbsent(target.getUUID(), k -> new State(target));
        s.touched = now;
        if (owner != null) s.owner = owner.getUUID();
        Vec3 pos = center(target);
        boolean lunar = owner != null && LunarManager.moonsign(owner) >= 1;

        double rest = switch (el) {
            case PYRO -> pyro(sl, s, target, owner, pos, units, hit);
            case HYDRO -> hydro(sl, s, target, owner, pos, units, lunar);
            case ELECTRO -> electro(sl, s, target, owner, pos, units, hit, lunar);
            case CRYO -> cryo(sl, s, target, owner, pos, units, hit);
            case DENDRO -> dendro(sl, s, target, owner, pos, units, hit, lunar);
            case ANEMO -> anemo(sl, s, target, owner, pos, units);
            case GEO -> geo(sl, s, target, owner, pos, units, lunar);
        };
        if (rest > 0) setAura(s, el, rest);
        fx(sl, pos, dust(el, 1.0f), 6, 0.3);
    }

    private static void setAura(State s, Element el, double units) {
        if (!el.hasAura()) return;
        int i = el.ordinal();
        if (s.gauge[i] < units) {
            s.gauge[i] = units;
            s.init[i] = units;
        }
    }

    /** Consome {@code aura} com o coeficiente da reação; devolve as unidades do gatilho que sobraram. */
    private static double use(State s, int aura, double trig, double coef) {
        double consumed = Math.min(s.gauge[aura], trig * coef);
        s.gauge[aura] -= consumed;
        if (s.gauge[aura] <= 0.0001) s.gauge[aura] = 0;
        if (s.gauge[aura] > 0) return 0;
        return Math.max(0, trig - consumed / coef);
    }

    // ---- PYRO
    private static double pyro(ServerLevel sl, State s, LivingEntity t, ServerPlayer o, Vec3 pos, double u, float hit) {
        LunarManager.detonateCores(sl, pos, 4.0, Element.PYRO, o); // Florescência
        if (s.gauge[HYDRO] > 0) {                                  // Vaporizar (x1,5)
            double r = use(s, HYDRO, u, 2.0);
            amplify(t, o, hit, 1.5f);
            fx(sl, pos, ParticleTypes.CLOUD, 12, 0.4);
            msg(o, "Vaporizar", ChatFormatting.GOLD);
            return r;
        }
        if (s.gauge[CRYO] > 0 || s.frozen > 0) {                   // Derreter (x2)
            double r = use(s, CRYO, u, 0.5);
            if (s.gauge[CRYO] <= 0) s.frozen = 0;
            amplify(t, o, hit, 2.0f);
            fx(sl, pos, ParticleTypes.FLAME, 12, 0.4);
            msg(o, "Derreter", ChatFormatting.GOLD);
            return r;
        }
        if (s.gauge[ELECTRO] > 0) {                                // Sobrecarga
            double r = use(s, ELECTRO, u, 1.0);
            overload(sl, pos, o);
            return r;
        }
        if (s.gauge[DENDRO] > 0 || s.quicken > 0) msg(o, "Queimar", ChatFormatting.RED);
        return u;
    }

    // ---- HYDRO
    private static double hydro(ServerLevel sl, State s, LivingEntity t, ServerPlayer o, Vec3 pos, double u, boolean lunar) {
        if (s.gauge[PYRO] > 0) {                                   // Vaporizar reverso (x2) - amplifica o próximo golpe
            double r = use(s, PYRO, u, 0.5);
            fx(sl, pos, ParticleTypes.CLOUD, 12, 0.4);
            msg(o, "Vaporizar", ChatFormatting.GOLD);
            return r;
        }
        if (s.gauge[CRYO] > 0) return freeze(sl, s, t, o, pos, u, CRYO);
        if (s.gauge[ELECTRO] > 0) {
            if (lunar) {                                           // Lunar-Carregado
                double r = use(s, ELECTRO, u, 1.0);
                LunarManager.spawnThundercloud(sl, t, o);
                return r;
            }
            msg(o, "Eletrocarregado", ChatFormatting.LIGHT_PURPLE); // coexistem -> tick causa o dano
            return u;
        }
        if (s.gauge[DENDRO] > 0) {                                 // Florescer / Lunar-Florescer
            double r = use(s, DENDRO, u, 2.0);
            bloom(sl, t, o, pos, lunar);
            return r;
        }
        return u;
    }

    // ---- ELECTRO
    private static double electro(ServerLevel sl, State s, LivingEntity t, ServerPlayer o, Vec3 pos, double u, float hit, boolean lunar) {
        LunarManager.detonateCores(sl, pos, 4.0, Element.ELECTRO, o); // Hiperflorescer
        if (s.gauge[PYRO] > 0) {
            double r = use(s, PYRO, u, 1.0);
            overload(sl, pos, o);
            return r;
        }
        if (s.gauge[HYDRO] > 0) {
            if (lunar) {                                           // Lunar-Carregado
                double r = use(s, HYDRO, u, 1.0);
                LunarManager.spawnThundercloud(sl, t, o);
                return r;
            }
            msg(o, "Eletrocarregado", ChatFormatting.LIGHT_PURPLE);
            return u;
        }
        if (s.gauge[CRYO] > 0) {
            double r = use(s, CRYO, u, 1.0);
            superconduct(sl, s, pos, o);
            return r;
        }
        if (s.quicken > 0) {                                       // Agravar (+dano plano)
            double take = Math.min(s.quicken, u);
            s.quicken -= take;
            hurt(t, o, 3f, false);
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, 12, 0.3, 0.4, 0.3, 0.3);
            msg(o, "Agravar", ChatFormatting.LIGHT_PURPLE);
            return u - take;
        }
        if (s.gauge[DENDRO] > 0) {                                 // Acelerar
            double m = Math.min(u, s.gauge[DENDRO]);
            s.gauge[DENDRO] -= m;
            s.quicken = Math.max(s.quicken, m);
            s.quickenInit = s.quicken;
            msg(o, "Acelerar", ChatFormatting.GREEN);
            return u - m;
        }
        return u;
    }

    // ---- CRYO
    private static double cryo(ServerLevel sl, State s, LivingEntity t, ServerPlayer o, Vec3 pos, double u, float hit) {
        if (s.gauge[PYRO] > 0) {                                   // Derreter reverso (x1,5)
            double r = use(s, PYRO, u, 2.0);
            amplify(t, o, hit, 1.5f);
            fx(sl, pos, ParticleTypes.SNOWFLAKE, 12, 0.4);
            msg(o, "Derreter", ChatFormatting.GOLD);
            return r;
        }
        if (s.gauge[HYDRO] > 0) return freeze(sl, s, t, o, pos, u, HYDRO);
        if (s.gauge[ELECTRO] > 0) {
            double r = use(s, ELECTRO, u, 1.0);
            superconduct(sl, s, pos, o);
            return r;
        }
        return u; // Cryo + Dendro coexistem
    }

    // ---- DENDRO
    private static double dendro(ServerLevel sl, State s, LivingEntity t, ServerPlayer o, Vec3 pos, double u, float hit, boolean lunar) {
        if (s.gauge[HYDRO] > 0) {                                  // Florescer / Lunar-Florescer
            double r = use(s, HYDRO, u, 0.5);
            bloom(sl, t, o, pos, lunar);
            return r;
        }
        if (s.gauge[PYRO] > 0) {                                   // Queimar
            msg(o, "Queimar", ChatFormatting.RED);
            return u;
        }
        if (s.gauge[ELECTRO] > 0) {                                // Acelerar
            double m = Math.min(u, s.gauge[ELECTRO]);
            s.gauge[ELECTRO] -= m;
            s.quicken = Math.max(s.quicken, m);
            s.quickenInit = s.quicken;
            msg(o, "Acelerar", ChatFormatting.GREEN);
            return u - m;
        }
        if (s.quicken > 0) {                                       // Propagar (+dano plano)
            s.quicken = Math.max(0, s.quicken - u);
            hurt(t, o, 3f, false);
            fx(sl, pos, ParticleTypes.HAPPY_VILLAGER, 10, 0.4);
            msg(o, "Propagar", ChatFormatting.GREEN);
        }
        return u;
    }

    // ---- ANEMO
    private static double anemo(ServerLevel sl, State s, LivingEntity t, ServerPlayer o, Vec3 pos, double u) {
        int best = -1;
        for (int i : new int[] {PYRO, HYDRO, ELECTRO, CRYO}) {
            if (s.gauge[i] > 0 && (best < 0 || s.gauge[i] > s.gauge[best])) best = i;
        }
        fx(sl, pos, ParticleTypes.CLOUD, 10, 0.4);
        if (best < 0) return 0;
        Element el = Element.values()[best];
        use(s, best, u, 0.5);                                      // Difusão
        if (best == CRYO && StellarManager.enabled(o)) {           // Redemoinho Estelar substitui Difusão de Cryo
            StellarManager.swirl(sl, t, o, pos);
            return 0;
        }
        hurt(t, o, 3f, false);
        msg(o, "Difusão (" + el.displayName + ")", el.format);
        if (swirlDepth < 1) {
            swirlDepth++;
            try {
                for (LivingEntity n : near(sl, pos, 4.0, o)) {
                    if (n == t) continue;
                    applyElement(n, el, 0.5, o, 0f);
                }
            } finally {
                swirlDepth--;
            }
        }
        return 0;
    }

    // ---- GEO
    private static double geo(ServerLevel sl, State s, LivingEntity t, ServerPlayer o, Vec3 pos, double u, boolean lunar) {
        if (lunar && s.gauge[HYDRO] > 0) {                         // Lunar-Cristalizar
            use(s, HYDRO, u, 0.5);
            LunarManager.lunarCrystallize(sl, t, o);
            return 0;
        }
        int best = -1;
        for (int i : new int[] {PYRO, HYDRO, ELECTRO, CRYO}) {
            if (s.gauge[i] > 0 && (best < 0 || s.gauge[i] > s.gauge[best])) best = i;
        }
        if (best < 0) return 0;
        Element el = Element.values()[best];
        use(s, best, u, 0.5);                                      // Cristalizar
        if (o != null) {
            for (Player p : sl.players()) {
                if (p.distanceToSqr(pos.x, pos.y, pos.z) <= 36) {
                    p.setAbsorptionAmount(Math.min(p.getAbsorptionAmount() + 4f, 12f));
                }
            }
        }
        sl.sendParticles(dust(el, 1.4f), pos.x, pos.y, pos.z, 14, 0.4, 0.4, 0.4, 0.02);
        sound(sl, pos, SoundEvents.AMETHYST_BLOCK_CHIME);
        msg(o, "Cristalizar (" + el.displayName + ")", el.format);
        return 0;
    }

    // ------------------------------------------------------------------ reações

    private static double freeze(ServerLevel sl, State s, LivingEntity t, ServerPlayer o, Vec3 pos, double u, int other) {
        double m = Math.min(u, s.gauge[other]);
        double r = use(s, other, u, 1.0);
        double seconds = Math.max(1.0, 2.0 * Math.sqrt(5.0 * m + 4.0) - 4.0);
        s.frozen += (int) (seconds * 20) + 20;
        t.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, s.frozen, 6, false, false));
        fx(sl, pos, ParticleTypes.SNOWFLAKE, 20, 0.4);
        msg(o, "Congelar", ChatFormatting.AQUA);
        return r;
    }

    private static void overload(ServerLevel sl, Vec3 pos, ServerPlayer o) {
        for (LivingEntity n : near(sl, pos, 2.5, o)) {
            hurt(n, o, 5f, false);
            Vec3 d = n.position().subtract(pos);
            knockback(n, 0.8, -d.x, -d.z);
        }
        fx(sl, pos, ParticleTypes.EXPLOSION, 1, 0);
        fx(sl, pos, ParticleTypes.FLAME, 16, 0.5);
        sound(sl, pos, SoundEvents.FIREWORK_ROCKET_BLAST);
        msg(o, "Sobrecarga", ChatFormatting.RED);
    }

    private static void superconduct(ServerLevel sl, State s, Vec3 pos, ServerPlayer o) {
        if (StellarManager.enabled(o)) {            // Condução Estelar substitui Superconduzir
            StellarManager.conduct(sl, pos, o);
            return;
        }
        s.superTicks = 240; // 12 s de -40% de resistência física
        for (LivingEntity n : near(sl, pos, 2.5, o)) hurt(n, o, 3f, false);
        fx(sl, pos, ParticleTypes.SNOWFLAKE, 18, 0.5);
        fx(sl, pos, ParticleTypes.ELECTRIC_SPARK, 12, 0.5);
        msg(o, "Superconduzir", ChatFormatting.AQUA);
    }

    private static void bloom(ServerLevel sl, LivingEntity t, ServerPlayer o, Vec3 pos, boolean lunar) {
        LunarManager.spawnCore(sl, pos, o);                         // Núcleo de Dendro comum (também no Lunar-Florescer)
        if (lunar) {
            LunarManager.lunarBloomDew(sl, o);                      // Orvalho para a equipe
            if (charged) LunarManager.lunarBloomBurst(t, o);        // dano direto só em ataques específicos (carregados)
            msg(o, "Lunar-Florescer", ChatFormatting.YELLOW);
        } else {
            msg(o, "Florescer", ChatFormatting.GREEN);
        }
    }

    private static void amplify(LivingEntity t, ServerPlayer o, float hit, float mult) {
        if (hit > 0) hurt(t, o, hit * (mult - 1f), false);
    }

    // ------------------------------------------------------------------ habilidade

    /** Habilidade elemental: raio de até 24 blocos que aplica 2U do elemento selecionado. */
    public static void castSkill(ServerPlayer p) {
        if (!(p.level() instanceof ServerLevel sl)) return;
        long cd = SKILL_CD.getOrDefault(p.getUUID(), 0L);
        if (now < cd) {
            p.sendSystemMessage(Component.literal("Habilidade em recarga: " + ((cd - now + 19) / 20) + "s")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        Element el = selected(p.getUUID());
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity hit = null;
        Vec3 end = eye;
        for (double d = 1.0; d <= 24.0 && hit == null; d += 0.5) {
            Vec3 pt = eye.add(look.scale(d));
            BlockPos bp = BlockPos.containing(pt);
            if (!sl.getBlockState(bp).getCollisionShape(sl, bp).isEmpty()) break;
            end = pt;
            sl.sendParticles(dust(el, 0.8f), pt.x, pt.y - 0.2, pt.z, 1, 0, 0, 0, 0);
            AABB box = new AABB(pt.x - 0.5, pt.y - 0.5, pt.z - 0.5, pt.x + 0.5, pt.y + 0.5, pt.z + 0.5);
            List<LivingEntity> l = sl.getEntitiesOfClass(LivingEntity.class, box,
                    e -> e.isAlive() && e != p && !(e instanceof ArmorStand));
            if (!l.isEmpty()) hit = l.get(0);
        }
        SKILL_CD.put(p.getUUID(), now + 100);
        sound(sl, p.position(), SoundEvents.AMETHYST_BLOCK_CHIME);
        if (hit != null) {
            float dmg = 4f;
            hurt(hit, p, dmg, false);
            applyElement(hit, el, 2.0, p, dmg);
        } else {
            sl.sendParticles(dust(el, 1.2f), end.x, end.y, end.z, 6, 0.2, 0.2, 0.2, 0);
        }
    }

    // ------------------------------------------------------------------ utilidades (usadas também pelo LunarManager)

    public static Vec3 center(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.5, 0);
    }

    public static List<LivingEntity> near(ServerLevel sl, Vec3 c, double r, ServerPlayer owner) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        return new ArrayList<>(sl.getEntitiesOfClass(LivingEntity.class, box,
                e -> e.isAlive() && e != owner && !(e instanceof Player) && !(e instanceof ArmorStand)));
    }

    /** Dano elemental. Reações Lunares podem dar CRIT e ganham bônus no Brilho Ascendente. */
    public static void hurt(LivingEntity target, ServerPlayer owner, float amount, boolean lunar) {
        if (!(target.level() instanceof ServerLevel sl) || amount <= 0 || !target.isAlive()) return;
        float amt = amount;
        if (lunar && owner != null) {
            if (LunarManager.moonsign(owner) >= 2) amt *= 1.5f;
            if (sl.getRandom().nextFloat() < 0.25f) {
                amt *= 1.6f;
                Vec3 c = center(target);
                sl.sendParticles(ParticleTypes.CRIT, c.x, c.y + 0.4, c.z, 10, 0.3, 0.3, 0.3, 0.2);
            }
        }
        int oldInv = target.getInvulnerableTime();
        depth++;
        try {
            target.setInvulnerableTime(0);
            DamageSource src = owner != null
                    ? sl.damageSources().indirectMagic(owner, owner)
                    : sl.damageSources().magic();
            target.hurtServer(sl, src, amt);
        } finally {
            depth--;
            target.setInvulnerableTime(oldInv);
        }
    }

    /** Dano de reação Estelar: pode dar CRIT, sem os bônus de Signo Lunar. */
    public static void hurtStellar(LivingEntity target, ServerPlayer owner, float amount) {
        if (!(target.level() instanceof ServerLevel sl) || amount <= 0 || !target.isAlive()) return;
        float amt = amount;
        if (sl.getRandom().nextFloat() < 0.25f) {
            amt *= 1.6f;
            Vec3 c = center(target);
            sl.sendParticles(ParticleTypes.CRIT, c.x, c.y + 0.4, c.z, 10, 0.3, 0.3, 0.3, 0.2);
        }
        hurt(target, owner, amt, false);
    }

    public record Aim(Vec3 point, LivingEntity entity) {}

    /** Mira do jogador: primeiro inimigo ou bloco no caminho (até {@code range} blocos). */
    public static Aim aim(ServerPlayer p, double range) {
        ServerLevel sl = (ServerLevel) p.level();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye;
        for (double d = 1.0; d <= range; d += 0.5) {
            Vec3 pt = eye.add(look.scale(d));
            BlockPos bp = BlockPos.containing(pt);
            if (!sl.getBlockState(bp).getCollisionShape(sl, bp).isEmpty()) break;
            end = pt;
            AABB box = new AABB(pt.x - 0.5, pt.y - 0.5, pt.z - 0.5, pt.x + 0.5, pt.y + 0.5, pt.z + 0.5);
            List<LivingEntity> l = sl.getEntitiesOfClass(LivingEntity.class, box,
                    e -> e.isAlive() && e != p && !(e instanceof ArmorStand));
            if (!l.isEmpty()) return new Aim(center(l.get(0)), l.get(0));
        }
        return new Aim(end, null);
    }

    public static ParticleOptions dust(Element el, float scale) { return new DustParticleOptions(el.color, scale); }

    public static ParticleOptions dust(int rgb, float scale) { return new DustParticleOptions(rgb, scale); }

    public static void fx(ServerLevel sl, Vec3 p, ParticleOptions type, int count, double spread) {
        sl.sendParticles(type, p.x, p.y, p.z, count, spread, spread, spread, 0.02);
    }

    public static void sound(ServerLevel sl, Vec3 p, SoundEvent ev) {
        sl.playSound(null, p.x, p.y, p.z, ev, SoundSource.PLAYERS, 0.7f, 1.1f);
    }

    public static void msg(ServerPlayer p, String text, ChatFormatting color) {
        if (p != null) p.sendSystemMessage(Component.literal(text).withStyle(color), true);
    }

    /** Linha de partículas entre dois pontos. */
    public static void beam(ServerLevel sl, Vec3 a, Vec3 b, ParticleOptions type) {
        Vec3 d = b.subtract(a);
        int steps = Math.max(2, (int) (d.length() * 3));
        for (int i = 0; i <= steps; i++) {
            Vec3 p = a.add(d.scale(i / (double) steps));
            sl.sendParticles(type, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
    }
}
