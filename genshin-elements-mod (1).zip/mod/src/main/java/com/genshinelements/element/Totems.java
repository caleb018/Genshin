package com.genshinelements.element;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/**
 * Registro central de totens (Moondrifts, Campo da Estrela Polar, Vórtice Estelar...).
 * Regra de otimização: no máximo {@link #MAX_TOTEMS} totens simultâneos numa área de 18x18 chunks
 * (±{@link #TOTEM_HALF_RANGE} blocos em X e Z, mesma dimensão). Ao estourar, o mais antigo é removido.
 * Núcleos de Dendro NÃO contam aqui (têm limite próprio em {@link LunarManager}).
 */
public final class Totems {
    private Totems() {}

    public static final int MAX_TOTEMS = 3;
    public static final double TOTEM_HALF_RANGE = 9 * 16; // 18x18 chunks = 288x288 blocos

    public abstract static class Totem {
        public final ServerLevel level;
        public final Vec3 pos;
        public final UUID owner;
        public final int life;
        public int age;
        long seq;

        protected Totem(ServerLevel level, Vec3 pos, UUID owner, int life) {
            this.level = level;
            this.pos = pos;
            this.owner = owner;
            this.life = life;
        }

        /** Chamado 1x por tick enquanto o totem existe. */
        public abstract void tick(MinecraftServer server);

        /** Limpeza/efeito final (expiração ou remoção por limite). */
        public abstract void onRemove();
    }

    private static final List<Totem> ALL = new ArrayList<>();
    private static long counter = 0;

    public static List<Totem> all() {
        return ALL;
    }

    private static boolean near(Totem a, Totem b) {
        return a.level == b.level
                && Math.abs(a.pos.x - b.pos.x) <= TOTEM_HALF_RANGE
                && Math.abs(a.pos.z - b.pos.z) <= TOTEM_HALF_RANGE;
    }

    public static void add(Totem t) {
        t.seq = counter++;
        while (true) {
            int n = 0;
            Totem oldest = null;
            for (Totem o : ALL) {
                if (!near(o, t)) continue;
                n++;
                if (oldest == null || o.seq < oldest.seq) oldest = o;
            }
            if (n < MAX_TOTEMS || oldest == null) break;
            remove(oldest);
        }
        ALL.add(t);
    }

    public static void remove(Totem t) {
        if (ALL.remove(t)) t.onRemove();
    }

    public static void tick(MinecraftServer server) {
        if (ALL.isEmpty()) return;
        for (Totem t : new ArrayList<>(ALL)) {
            if (!ALL.contains(t)) continue; // removido durante este tick
            t.age++;
            if (t.age >= t.life) {
                remove(t);
                continue;
            }
            t.tick(server);
        }
    }
}
