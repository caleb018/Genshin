package com.genshinelements.element;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Reações Estelares (Glimmer), habilitadas pelo Eixo Estelar equipado no slot Curios:
 *  - Condução Estelar (Cryo + Electro, no lugar de Superconduzir): cria o Campo da Estrela Polar
 *    (-40% resistência física dos inimigos, bônus Cryo/Electro, aplicações registradas por 4 s
 *    viram dano direto de Condução Estelar). Só um campo por jogador.
 *  - Redemoinho Estelar (Anemo + Cryo, no lugar do Redemoinho de Cryo): acerto Anemo + Vórtice Estelar
 *    que sobe de nível a cada novo Redemoinho e explode em área com dano Cryo.
 * Campo e Vórtice são totens (limite global em {@link Totems}).
 */
public final class StellarManager {
    private StellarManager() {}

    private static final int FIELD_LIFE = 240;   // 12 s
    private static final double FIELD_RADIUS = 5.0;
    private static final int VORTEX_LIFE = 60;   // 3 s
    private static final int VORTEX_MAX_LEVEL = 3;
    private static final Map<UUID, Long> SWIRL_WINDOW = new HashMap<>(); // dano direto por 8 s

    public static boolean enabled(ServerPlayer p) {
        return MoonGear.stellar(p);
    }

    // ------------------------------------------------------------------ Campo da Estrela Polar

    static final class Field extends Totems.Totem {
        int stored;
        long windowStart = -1000;

        Field(ServerLevel level, Vec3 pos, UUID owner) {
            super(level, pos, owner, FIELD_LIFE);
        }

        boolean contains(Vec3 p) {
            double dx = p.x - pos.x, dz = p.z - pos.z;
            return dx * dx + dz * dz <= FIELD_RADIUS * FIELD_RADIUS && Math.abs(p.y - pos.y) <= 4.0;
        }

        @Override
        public void tick(MinecraftServer server) {
            if (age % 5 == 0) {
                for (int i = 0; i < 8; i++) {
                    double a = (Math.PI * 2 / 8) * i + age * 0.05;
                    level.sendParticles(ElementManager.dust(0x9FE8FF, 1.0f),
                            pos.x + Math.cos(a) * FIELD_RADIUS, pos.y + 0.1, pos.z + Math.sin(a) * FIELD_RADIUS,
                            1, 0, 0, 0, 0);
                }
                level.sendParticles(ParticleTypes.END_ROD, pos.x, pos.y + 1.6, pos.z, 1, 0.1, 0.3, 0.1, 0.01);
            }
            if (age % 10 == 0) {
                ServerPlayer owner = server.getPlayerList().getPlayer(this.owner);
                for (LivingEntity n : ElementManager.near(level, pos, FIELD_RADIUS, owner)) {
                    if (contains(n.position())) ElementManager.shred(n, owner, 30); // -40% res. física
                }
            }
        }

        @Override
        public void onRemove() {
            ElementManager.fx(level, pos.add(0, 0.5, 0), ParticleTypes.END_ROD, 12, 0.6);
        }
    }

    public static void conduct(ServerLevel sl, Vec3 pos, ServerPlayer owner) {
        UUID oid = owner == null ? new UUID(0, 0) : owner.getUUID();
        for (Totems.Totem t : new java.util.ArrayList<>(Totems.all())) {
            if (t instanceof Field && t.owner.equals(oid)) Totems.remove(t); // só um campo por jogador
        }
        Totems.add(new Field(sl, pos, oid));
        ElementManager.sound(sl, pos, SoundEvents.AMETHYST_BLOCK_RESONATE);
        ElementManager.msg(owner, "Condução Estelar", ChatFormatting.AQUA);
    }

    private static Field fieldOf(ServerPlayer p) {
        for (Totems.Totem t : Totems.all()) {
            if (t instanceof Field f && f.owner.equals(p.getUUID()) && f.level == p.level() && f.contains(p.position())) {
                return f;
            }
        }
        return null;
    }

    /** Chamado após cada golpe do jogador (já com o Eixo Estelar equipado). */
    public static void onPlayerHit(ServerPlayer sp, LivingEntity target, Element el, float dmg, long now) {
        if (el == Element.CRYO || el == Element.ELECTRO) {
            Field f = fieldOf(sp);
            if (f != null) {
                if (now - f.windowStart > 80) { // janela de 4 s de aplicações registradas
                    f.windowStart = now;
                    f.stored = 0;
                }
                f.stored = Math.min(6, f.stored + 1);
                ElementManager.hurt(target, sp, dmg * 0.2f, false);                    // bônus Cryo/Electro
                ElementManager.hurtStellar(target, sp, 1.5f + 0.5f * f.stored);         // dano direto de Condução
            }
        }
        Long w = SWIRL_WINDOW.get(sp.getUUID());
        if (w != null) {
            if (now > w) SWIRL_WINDOW.remove(sp.getUUID());
            else if (el == Element.ANEMO || el == Element.CRYO) ElementManager.hurtStellar(target, sp, 1.5f);
        }
    }

    // ------------------------------------------------------------------ Vórtice Estelar

    static final class Vortex extends Totems.Totem {
        int lvl = 1;

        Vortex(ServerLevel level, Vec3 pos, UUID owner) {
            super(level, pos, owner, VORTEX_LIFE);
        }

        @Override
        public void tick(MinecraftServer server) {
            if (age % 4 == 0) {
                ServerPlayer owner = server.getPlayerList().getPlayer(this.owner);
                level.sendParticles(ElementManager.dust(0x9FE8FF, 1.1f), pos.x, pos.y + 0.8, pos.z, 4, 0.5, 0.6, 0.5, 0);
                level.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y + 1.0, pos.z, 2, 0.3, 0.5, 0.3, 0.02);
                for (LivingEntity n : ElementManager.near(level, pos, 4.0, owner)) {
                    Vec3 d = n.position().subtract(pos);
                    ElementManager.knockback(n, 0.15 + 0.05 * lvl, d.x, d.z); // puxa para o centro
                }
            }
        }

        @Override
        public void onRemove() {
            ServerPlayer owner = level.getServer().getPlayerList().getPlayer(this.owner);
            double r = 3.0 + 0.5 * lvl;
            for (LivingEntity n : ElementManager.near(level, pos, r, owner)) {
                ElementManager.hurtStellar(n, owner, 4f + 3f * lvl);
            }
            ElementManager.fx(level, pos.add(0, 0.8, 0), ParticleTypes.SNOWFLAKE, 24 + 8 * lvl, r * 0.5);
            ElementManager.fx(level, pos.add(0, 0.8, 0), ParticleTypes.CLOUD, 10, 0.5);
            ElementManager.sound(level, pos, SoundEvents.GLASS_BREAK);
        }
    }

    public static void swirl(ServerLevel sl, LivingEntity target, ServerPlayer owner, Vec3 pos) {
        ElementManager.hurt(target, owner, 3f, false); // acerto Anemo do Redemoinho
        UUID oid = owner == null ? new UUID(0, 0) : owner.getUUID();
        Vortex found = null;
        for (Totems.Totem t : Totems.all()) {
            if (t instanceof Vortex v && v.owner.equals(oid) && v.level == sl
                    && v.pos.distanceToSqr(pos) <= 16.0) {
                found = v;
                break;
            }
        }
        if (found == null) {
            Totems.add(new Vortex(sl, target.position(), oid));
        } else {
            found.lvl = Math.min(VORTEX_MAX_LEVEL, found.lvl + 1);
            if (found.lvl >= VORTEX_MAX_LEVEL) found.age = Math.max(found.age, found.life - 10); // explode logo
        }
        if (owner != null) SWIRL_WINDOW.put(oid, ElementManager.now() + 160); // 8 s de dano direto
        ElementManager.msg(owner, "Redemoinho Estelar", ChatFormatting.AQUA);
    }

    public static void forget(UUID id) {
        SWIRL_WINDOW.remove(id);
    }
}
