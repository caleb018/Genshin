package com.genshinelements.element;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.Vec3;

/**
 * Reações Lunares (Nod-Krai). Signo Lunar vem dos artefatos nos slots Curios (ver {@link MoonGear}):
 * um artefato = Brilho Nascente (reações lunares ativas); os dois = Brilho Ascendente (+50% dano lunar, nuvem mais rápida).
 *
 *  - Lunar-Carregado: nuvem de trovão sobre o alvo.
 *  - Lunar-Florescer: Núcleo de Dendro comum + Orvalho; dano direto só vindo de ataques carregados.
 *  - Lunar-Cristalizar: 3 Moondrifts (totens); a cada 3 reações, Harmonia Moondrift (projéteis teleguiados).
 * Núcleos de Dendro: no máximo {@link #CORE_MAX} num raio de 7x7 chunks (não contam como totens).
 */
public final class LunarManager {
    private LunarManager() {}

    private static final class Cloud {
        UUID target, owner; ServerLevel level; int left, interval, age;
    }

    private static final class Core {
        ServerLevel level; Vec3 pos; UUID owner; int age; long seq;
    }

    private static final class Bolt {
        ServerLevel level; Vec3 pos; UUID target, owner; int age;
    }

    /** Torreta Moondrift (item_display + totem). Fica parada até a Harmonia, como no jogo. */
    private static final class Drift extends Totems.Totem {
        final String tag;

        Drift(ServerLevel level, Vec3 pos, UUID owner, String tag) {
            super(level, pos, owner, DRIFT_LIFE);
            this.tag = tag;
        }

        @Override
        public void tick(MinecraftServer server) {
            if (age % 10 == 0) {
                Vec3 top = pos.add(0, 1.4, 0);
                level.sendParticles(ElementManager.dust(0xFFE9A8, 0.9f), top.x, top.y, top.z, 2, 0.2, 0.2, 0.2, 0);
            }
        }

        @Override
        public void onRemove() {
            run(level, pos, "kill @e[type=minecraft:item_display,tag=" + tag + "]");
            ElementManager.fx(level, pos.add(0, 0.8, 0), ParticleTypes.END_ROD, 14, 0.4);
        }
    }

    private static final List<Cloud> CLOUDS = new ArrayList<>();
    private static final List<Core> CORES = new ArrayList<>();
    private static final List<Bolt> BOLTS = new ArrayList<>();
    private static final Map<UUID, Integer> HARMONY = new HashMap<>();
    private static final Map<UUID, int[]> DEW = new HashMap<>(); // {quantidade, tick de início}
    private static long tickNo = 0;
    private static long driftCounter = 0;
    private static long coreCounter = 0;

    private static final int DRIFT_LIFE = 300;   // 15 s
    private static final int CLOUD_LIFE = 240;   // 12 s
    private static final int CORE_LIFE = 120;    // 6 s (igual ao jogo)
    public static final int CORE_MAX = 6;
    public static final double CORE_HALF_RANGE = 3.5 * 16; // 7x7 chunks = 112x112 blocos

    // ------------------------------------------------------------------ Signo Lunar

    public static int moonsign(ServerPlayer p) {
        return MoonGear.moonsign(p);
    }

    // ------------------------------------------------------------------ Lunar-Carregado

    public static void spawnThundercloud(ServerLevel sl, LivingEntity target, ServerPlayer owner) {
        int interval = owner != null && moonsign(owner) >= 2 ? 30 : 40;
        for (Cloud c : CLOUDS) {
            if (c.target.equals(target.getUUID())) {
                c.left = CLOUD_LIFE;
                c.interval = interval;
                if (owner != null) c.owner = owner.getUUID();
                ElementManager.msg(owner, "Lunar-Carregado", ChatFormatting.LIGHT_PURPLE);
                return;
            }
        }
        Cloud c = new Cloud();
        c.target = target.getUUID();
        c.owner = owner == null ? null : owner.getUUID();
        c.level = sl;
        c.left = CLOUD_LIFE;
        c.interval = interval;
        CLOUDS.add(c);
        ElementManager.msg(owner, "Lunar-Carregado", ChatFormatting.LIGHT_PURPLE);
    }

    // ------------------------------------------------------------------ Núcleos de Dendro

    /** Cria um Núcleo de Dendro comum. Acima do limite (6 em 7x7 chunks) o mais antigo detona na hora. */
    public static void spawnCore(ServerLevel sl, Vec3 pos, ServerPlayer owner) {
        int n = 0;
        Core oldest = null;
        for (Core c : CORES) {
            if (c.level != sl || Math.abs(c.pos.x - pos.x) > CORE_HALF_RANGE || Math.abs(c.pos.z - pos.z) > CORE_HALF_RANGE) continue;
            n++;
            if (oldest == null || c.seq < oldest.seq) oldest = c;
        }
        if (n >= CORE_MAX && oldest != null) {
            CORES.remove(oldest);
            explodeCore(oldest, sl.getServer());
        }
        Core c = new Core();
        c.level = sl;
        c.pos = pos;
        c.owner = owner == null ? null : owner.getUUID();
        c.seq = coreCounter++;
        CORES.add(c);
    }

    private static void explodeCore(Core k, MinecraftServer server) {
        ServerPlayer owner = k.owner == null ? null : server.getPlayerList().getPlayer(k.owner);
        for (LivingEntity n : ElementManager.near(k.level, k.pos, 2.5, owner)) ElementManager.hurt(n, owner, 4f, false);
        ElementManager.fx(k.level, k.pos, ParticleTypes.HAPPY_VILLAGER, 16, 0.6);
    }

    /** Orvalho de Moonridge (Lunar-Florescer concede Orvalho à equipe): cura, até 3 a cada 18 s. */
    public static void lunarBloomDew(ServerLevel sl, ServerPlayer owner) {
        if (owner == null) return;
        int[] d = DEW.computeIfAbsent(owner.getUUID(), k -> new int[] {0, 0});
        if (tickNo - d[1] > 360) { d[0] = 0; d[1] = (int) tickNo; }
        if (d[0] < 3) {
            d[0]++;
            owner.heal(2f);
            Vec3 p = owner.position().add(0, 1.0, 0);
            sl.sendParticles(ElementManager.dust(0x9FE8FF, 1.2f), p.x, p.y, p.z, 8, 0.3, 0.5, 0.3, 0);
        }
    }

    /** Dano direto de Lunar-Florescer: só ataques específicos (aqui, os ataques carregados) o causam. */
    public static void lunarBloomBurst(LivingEntity target, ServerPlayer owner) {
        ElementManager.hurt(target, owner, 4f, true);
    }

    /** Cores perto de {@code pos} reagem: Electro = Hiperflorescer, Pyro = Florescência. Retorna quantos foram consumidos. */
    public static int detonateCores(ServerLevel sl, Vec3 pos, double r, Element el, ServerPlayer owner) {
        int count = 0;
        Iterator<Core> it = CORES.iterator();
        while (it.hasNext()) {
            Core c = it.next();
            if (c.level != sl || c.pos.distanceToSqr(pos) > r * r) continue;
            it.remove();
            count++;
            if (el == Element.ELECTRO) {
                LivingEntity best = nearestEnemy(sl, c.pos, 10.0, owner);
                ElementManager.fx(sl, c.pos, ParticleTypes.ELECTRIC_SPARK, 10, 0.2);
                if (best != null) {
                    ElementManager.beam(sl, c.pos, ElementManager.center(best), ParticleTypes.ELECTRIC_SPARK);
                    ElementManager.hurt(best, owner, 6f, false);
                }
                ElementManager.msg(owner, "Hiperflorescer", ChatFormatting.LIGHT_PURPLE);
            } else if (el == Element.PYRO) {
                for (LivingEntity n : ElementManager.near(sl, c.pos, 3.0, owner)) ElementManager.hurt(n, owner, 6f, false);
                ElementManager.fx(sl, c.pos, ParticleTypes.EXPLOSION, 1, 0);
                ElementManager.fx(sl, c.pos, ParticleTypes.FLAME, 16, 0.6);
                ElementManager.sound(sl, c.pos, SoundEvents.FIREWORK_ROCKET_BLAST);
                ElementManager.msg(owner, "Florescência", ChatFormatting.RED);
            }
        }
        return count;
    }

    // ------------------------------------------------------------------ Lunar-Cristalizar (Moondrifts)

    /** Cada reação mantém 3 Moondrifts do jogador; a cada 3 reações eles disparam a Harmonia no alvo. */
    public static void lunarCrystallize(ServerLevel sl, LivingEntity target, ServerPlayer owner) {
        UUID oid = owner == null ? new UUID(0, 0) : owner.getUUID();
        int mine = 0;
        for (Totems.Totem t : Totems.all()) {
            if (t instanceof Drift d && d.owner.equals(oid) && d.level == sl) {
                d.age = 0; // renova a duração
                mine++;
            }
        }
        Vec3 feet = target.position();
        for (int i = mine; i < 3; i++) {
            double a = i * (Math.PI * 2 / 3) + sl.getRandom().nextDouble();
            spawnDrift(sl, feet.add(Math.cos(a) * 2.2, 0, Math.sin(a) * 2.2), oid);
        }
        ElementManager.msg(owner, "Lunar-Cristalizar", ChatFormatting.GOLD);

        int n = HARMONY.merge(oid, 1, Integer::sum);
        if (n >= 3) {
            HARMONY.put(oid, 0);
            moondriftHarmony(sl, oid, owner, target);
        }
    }

    private static void spawnDrift(ServerLevel sl, Vec3 pos, UUID owner) {
        String tag = "ge_md_" + (driftCounter++);
        Totems.add(new Drift(sl, pos, owner, tag));
        String cmd = String.format(Locale.ROOT,
                "summon minecraft:item_display %.3f %.3f %.3f {Tags:[\"ge_moondrift\",\"%s\"],"
                        + "item:{id:\"genshinelements:moondrift\",count:1},item_display:\"none\","
                        + "brightness:{sky:15,block:15},"
                        + "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                        + "translation:[0f,0.72f,0f],scale:[1.2f,1.2f,1.2f]}}",
                pos.x, pos.y, pos.z, tag);
        run(sl, pos, cmd);
        ElementManager.fx(sl, pos.add(0, 0.8, 0), ParticleTypes.END_ROD, 12, 0.3);
        ElementManager.sound(sl, pos, SoundEvents.AMETHYST_BLOCK_CHIME);
    }

    private static void run(ServerLevel sl, Vec3 pos, String command) {
        MinecraftServer server = sl.getServer();
        CommandSourceStack src = server.createCommandSourceStack()
                .withLevel(sl).withPosition(pos).withSuppressedOutput();
        server.getCommands().performPrefixedCommand(src, command);
    }

    /** Harmonia Moondrift: cada Moondrift dispara um projétil teleguiado no alvo (dano Lunar-Cristalizar, Geo). */
    private static void moondriftHarmony(ServerLevel sl, UUID oid, ServerPlayer owner, LivingEntity target) {
        for (Totems.Totem t : Totems.all()) {
            if (!(t instanceof Drift d) || !d.owner.equals(oid) || d.level != sl) continue;
            Bolt b = new Bolt();
            b.level = sl;
            b.pos = d.pos.add(0, 1.4, 0);
            b.target = target.getUUID();
            b.owner = oid;
            BOLTS.add(b);
        }
        ElementManager.sound(sl, target.position(), SoundEvents.AMETHYST_BLOCK_CHIME);
        ElementManager.msg(owner, "Harmonia Moondrift!", ChatFormatting.GOLD);
    }

    private static LivingEntity nearestEnemy(ServerLevel sl, Vec3 from, double r, ServerPlayer owner) {
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity e : ElementManager.near(sl, from, r, owner)) {
            if (!(e instanceof Enemy)) continue;
            double d = e.position().distanceToSqr(from);
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    // ------------------------------------------------------------------ tick

    public static void tick(MinecraftServer server) {
        tickNo++;

        // Nuvem de trovão (Lunar-Carregado)
        Iterator<Cloud> ci = CLOUDS.iterator();
        while (ci.hasNext()) {
            Cloud c = ci.next();
            LivingEntity t = c.level.getEntity(c.target) instanceof LivingEntity le ? le : null;
            if (t == null || !t.isAlive() || --c.left <= 0) { ci.remove(); continue; }
            c.age++;
            ServerPlayer owner = c.owner == null ? null : server.getPlayerList().getPlayer(c.owner);
            Vec3 cp = t.position().add(0, t.getBbHeight() + 1.3, 0);
            if (c.age % 4 == 0) {
                c.level.sendParticles(ParticleTypes.CLOUD, cp.x, cp.y, cp.z, 4, 0.4, 0.1, 0.4, 0.0);
                c.level.sendParticles(ElementManager.dust(0x6A4BD6, 1.3f), cp.x, cp.y, cp.z, 3, 0.4, 0.1, 0.4, 0.0);
            }
            if (c.age % c.interval == 0) {
                int shots = c.level.getRandom().nextInt(3) == 0 ? 2 : 1; // 1/3 de chance de instância extra
                for (int i = 0; i < shots; i++) {
                    ElementManager.beam(c.level, cp, ElementManager.center(t), ParticleTypes.ELECTRIC_SPARK);
                    ElementManager.hurt(t, owner, 5f, true);
                }
                ElementManager.sound(c.level, cp, SoundEvents.LIGHTNING_BOLT_IMPACT);
            }
        }

        // Núcleos de Dendro
        Iterator<Core> ki = CORES.iterator();
        while (ki.hasNext()) {
            Core k = ki.next();
            k.age++;
            if (k.age % 4 == 0) {
                k.level.sendParticles(ParticleTypes.HAPPY_VILLAGER, k.pos.x, k.pos.y, k.pos.z, 2, 0.15, 0.15, 0.15, 0);
                k.level.sendParticles(ElementManager.dust(Element.DENDRO, 1.0f), k.pos.x, k.pos.y, k.pos.z, 2, 0.1, 0.1, 0.1, 0);
            }
            if (k.age >= CORE_LIFE) {
                ki.remove();
                explodeCore(k, server);
            }
        }

        // Projéteis da Harmonia Moondrift (teleguiados)
        Iterator<Bolt> bi = BOLTS.iterator();
        while (bi.hasNext()) {
            Bolt b = bi.next();
            ServerPlayer owner = server.getPlayerList().getPlayer(b.owner);
            LivingEntity t = b.level.getEntity(b.target) instanceof LivingEntity le && le.isAlive() ? le : null;
            if (t == null) t = nearestEnemy(b.level, b.pos, 16.0, owner);
            if (t == null) { bi.remove(); continue; }
            b.target = t.getUUID();
            Vec3 to = ElementManager.center(t).subtract(b.pos);
            double dist = to.length();
            if (dist < 1.0 || ++b.age > 60) {
                ElementManager.hurt(t, owner, 6f, true);
                ElementManager.fx(b.level, ElementManager.center(t), ParticleTypes.END_ROD, 14, 0.5);
                ElementManager.fx(b.level, ElementManager.center(t), ParticleTypes.CRIT, 8, 0.4);
                bi.remove();
                continue;
            }
            Vec3 next = b.pos.add(to.scale(Math.min(1.2, dist) / dist));
            ElementManager.beam(b.level, b.pos, next, ElementManager.dust(Element.GEO, 1.0f));
            b.pos = next;
        }
    }

    /** Remove torretas órfãs (displays que sobraram de um desligamento forçado). */
    public static void cleanupOrphans(MinecraftServer server) {
        for (ServerLevel sl : server.getAllLevels()) {
            run(sl, Vec3.ZERO, "kill @e[type=minecraft:item_display,tag=ge_moondrift]");
        }
    }

    public static void forget(UUID id) {
        HARMONY.remove(id);
        DEW.remove(id);
    }
}
