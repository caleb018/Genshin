package com.genshinelements.element;

import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

public enum Element {
    PYRO("pyro", "Pyro", 0xFF6A2A, ChatFormatting.RED),
    HYDRO("hydro", "Hydro", 0x3FA9FF, ChatFormatting.BLUE),
    ELECTRO("electro", "Electro", 0xB86CFF, ChatFormatting.LIGHT_PURPLE),
    CRYO("cryo", "Cryo", 0x9FE8FF, ChatFormatting.AQUA),
    ANEMO("anemo", "Anemo", 0x5CE6C0, ChatFormatting.GREEN),
    GEO("geo", "Geo", 0xF0C040, ChatFormatting.GOLD),
    DENDRO("dendro", "Dendro", 0x8BD43B, ChatFormatting.DARK_GREEN);

    public final String id;
    public final String displayName;
    public final int color;
    public final ChatFormatting format;

    Element(String id, String displayName, int color, ChatFormatting format) {
        this.id = id;
        this.displayName = displayName;
        this.color = color;
        this.format = format;
    }

    public MutableComponent coloredName() {
        return Component.literal(displayName).withStyle(format);
    }

    public Element next() { return values()[(ordinal() + 1) % values().length]; }

    public Element prev() { return values()[(ordinal() + values().length - 1) % values().length]; }

    /** Elementos que formam aura no inimigo (Anemo e Geo não ficam grudados). */
    public boolean hasAura() { return this != ANEMO && this != GEO; }

    public static Element byId(String s) {
        String k = s.toLowerCase(Locale.ROOT);
        for (Element e : values()) if (e.id.equals(k)) return e;
        return null;
    }
}
