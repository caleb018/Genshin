package com.genshinelements.element;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Ataque carregado de cada elemento (segure a tecla por 1 s e solte). Cada um aplica 1U do próprio elemento.
 * Durante o disparo vale "carregado": é o que libera o dano direto de Lunar-Florescer.
 */
public final class ChargedAttacks {
    private ChargedAttacks() {}

    public static void fire(ServerPlayer p) {
        if (!(p.level() instanceof ServerLevel sl)) return;
        Element el = ElementManager.selected(p.getUUID());
        ElementManager.Aim aim = ElementManager.aim(p, 20.0);
        Vec3 from = p.getEyePosition().add(0, -0.25, 0);
        Vec3 to = aim.point();
        ElementManager.beam(sl, from, to, ElementManager.dust(el, 1.2f));
        ElementManager.sound(sl, p.position(), SoundEvents.AMETHYST_BLOCK_RESONATE);

        ElementManager.setCharged(true);
        try {
            switch (el) {
                case PYRO -> {      // bola de fogo: explosão em área
                    burst(sl, p, el, to, 2.5, 6f, 1.0);
                    ElementManager.fx(sl, to, ParticleTypes.FLAME, 20, 0.6);
                    ElementManager.fx(sl, to, ParticleTypes.EXPLOSION, 1, 0);
                }
                case HYDRO -> {     // projétil d'água: respingo em área
                    burst(sl, p, el, to, 2.5, 5f, 1.0);
                    ElementManager.fx(sl, to, ParticleTypes.SPLASH, 24, 0.6);
                }
                case ELECTRO -> {   // raio encadeado: alvo + até 2 vizinhos
                    LivingEntity first = aim.entity() != null ? aim.entity() : nearestTo(sl, p, to, 3.0);
                    if (first == null) {
                        ElementManager.fx(sl, to, ParticleTypes.ELECTRIC_SPARK, 12, 0.4);
                        break;
                    }
                    strike(sl, p, el, first, 5f, 1.0);
                    List<LivingEntity> chain = new ArrayList<>(ElementManager.near(sl, ElementManager.center(first), 5.0, p));
                    chain.remove(first);
                    chain.sort(Comparator.comparingDouble(e -> e.distanceToSqr(first)));
                    for (int i = 0; i < Math.min(2, chain.size()); i++) {
                        ElementManager.beam(sl, ElementManager.center(first), ElementManager.center(chain.get(i)), ParticleTypes.ELECTRIC_SPARK);
                        strike(sl, p, el, chain.get(i), 3f, 0.5);
                    }
                }
                case CRYO -> {      // lança de gelo: atravessa todos na linha
                    Vec3 mid = from.add(to).scale(0.5);
                    double half = from.distanceTo(to) / 2 + 1;
                    for (LivingEntity n : ElementManager.near(sl, mid, half, p)) {
                        if (distToSegment(ElementManager.center(n), from, to) <= 1.0) strike(sl, p, el, n, 5f, 1.0);
                    }
                    ElementManager.fx(sl, to, ParticleTypes.SNOWFLAKE, 16, 0.5);
                }
                case ANEMO -> {     // rajada: puxa os inimigos para o centro
                    burst(sl, p, el, to, 3.5, 3f, 1.0);
                    for (LivingEntity n : ElementManager.near(sl, to, 3.5, p)) {
                        Vec3 d = n.position().subtract(to);
                        n.knockback(0.6, d.x, d.z);
                    }
                    ElementManager.fx(sl, to, ParticleTypes.CLOUD, 18, 0.8);
                }
                case GEO -> {       // espinho de cristal
                    burst(sl, p, el, to, 2.5, 7f, 1.0);
                    ElementManager.fx(sl, to, ElementManager.dust(el, 1.6f), 20, 0.6);
                    ElementManager.sound(sl, to, SoundEvents.AMETHYST_BLOCK_BREAK);
                }
                case DENDRO -> {    // semente: explosão de folhas
                    burst(sl, p, el, to, 2.5, 4f, 1.0);
                    ElementManager.fx(sl, to, ParticleTypes.HAPPY_VILLAGER, 18, 0.6);
                }
            }
        } finally {
            ElementManager.setCharged(false);
        }
    }

    private static void strike(ServerLevel sl, ServerPlayer p, Element el, LivingEntity n, float dmg, double units) {
        ElementManager.hurt(n, p, dmg, false);
        ElementManager.applyElement(n, el, units, p, dmg);
    }

    private static void burst(ServerLevel sl, ServerPlayer p, Element el, Vec3 c, double r, float dmg, double units) {
        for (LivingEntity n : ElementManager.near(sl, c, r, p)) strike(sl, p, el, n, dmg, units);
    }

    private static LivingEntity nearestTo(ServerLevel sl, ServerPlayer p, Vec3 c, double r) {
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity n : ElementManager.near(sl, c, r, p)) {
            double d = n.position().distanceToSqr(c);
            if (d < bd) { bd = d; best = n; }
        }
        return best;
    }

    private static double distToSegment(Vec3 pt, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        double t = len2 == 0 ? 0 : Math.max(0, Math.min(1, pt.subtract(a).dot(ab) / len2));
        return pt.distanceTo(a.add(ab.scale(t)));
    }
}
