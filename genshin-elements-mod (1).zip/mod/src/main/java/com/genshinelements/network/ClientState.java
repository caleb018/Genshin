package com.genshinelements.network;

/** Estado só do cliente (sem imports de classes client-only, seguro de carregar no servidor). */
public final class ClientState {
    private ClientState() {}

    /** Ordinal do elemento selecionado (sincronizado pelo servidor). */
    public static volatile int element = 0;
    /** Ticks que a tecla de ataque carregado está segurada. */
    public static volatile int chargeTicks = 0;
}
