package com.genshinelements.network;

import com.genshinelements.GenshinElementsMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Servidor -> cliente: elemento atualmente selecionado (para o indicador na tela). */
public record ElementSyncPayload(int element) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ElementSyncPayload> TYPE =
            new CustomPacketPayload.Type<>(GenshinElementsMod.id("element_sync"));

    public static final StreamCodec<ByteBuf, ElementSyncPayload> CODEC =
            ByteBufCodecs.VAR_INT.map(ElementSyncPayload::new, ElementSyncPayload::element);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
