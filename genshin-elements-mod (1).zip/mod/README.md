# Genshin Elements (NeoForge 26.3 + Curios)

Sistema elemental de Genshin Impact para Minecraft: 7 elementos, reações, Reações **Lunares** e **Estelares**,
ataques carregados, Eixo Estelar e Canção da Lua Gelada (slots Curios) e torretas Moondrift.

> **Este código não foi compilado** (não havia Gradle/JDK 25 nem acesso à rede onde foi escrito).
> Leia "Se não compilar" no fim.

## Como compilar
1. JDK 25 instalado.
2. Abra a pasta no IntelliJ **ou** rode uma vez `gradle wrapper --gradle-version 9.3.1` e depois `./gradlew build`.
3. `./gradlew runClient` para testar. O .jar sai em `build/libs/`.

Versões (gradle.properties): ModDevGradle 2.0.148, NeoForge 26.3.0.37-beta, Curios 17.0.0-beta.3+26.3
(repositório `https://maven.theillusivec4.top/`). **Curios é dependência obrigatória** do mod.

## Controles (Opções > Controles > Genshin Elements)
- R: roda de elementos · V / B: próximo / anterior · G: habilidade elemental (2U, recarga 5 s)
- **Botão direito do mouse (segurar 1 s e soltar, com a mão principal vazia): ataque carregado do elemento selecionado** (recarga 1,5 s). Pode ser remapeado nos Controles; `REQUIRE_EMPTY_HAND` em `GenshinElementsClient` libera para qualquer item.
- Golpes corpo a corpo e flechas aplicam 1U do elemento (ICD: 1º golpe, depois a cada 3 golpes ou 2,5 s)
- Indicador do elemento à direita da hotbar (com barra de carga). O elemento escolhido é salvo no personagem.

## Marca elemental na mão (`HandEffects.java`)
Um símbolo animado flutua sobre a mão principal conforme o elemento (visível para todos):
- **Pyro**: chamas de cabelo da Mavuika + anel solar de Natlan · **Hydro**: gota de Focalors, órbitas e pérolas
- **Electro**: olho violeta da Raiden Shogun (pisca, íris, pupila, faíscas) · **Cryo**: floco de seis braços com pontas de coroa da Tsaritsa
- **Anemo**: ciclone de Barbatos com penas · **Geo**: selo hexagonal de Morax com losango e cristais · **Dendro**: interface do Terminal Akasha
- Ao segurar o ataque carregado o símbolo cresce e ganha um anel; fica faiscando quando está pronto para soltar.
- Posição/tamanho: constantes `HAND_FWD`, `HAND_SIDE`, `HAND_DOWN`, `HOVER`, `PERIOD` no topo do arquivo.

## Artefatos (slots Curios: "Eixo Estelar" e "Canção da Lua Gelada")
- Um artefato = Brilho Nascente (reações lunares ativas). Os dois = Brilho Ascendente (+50% dano lunar, nuvem mais rápida).
- **Eixo Estelar equipado = reações Estelares ativas.**
- Sem os artefatos, valem só as reações normais.

## Reações Lunares (Geo/Electro/Dendro + Hydro)
- **Lunar-Carregado**: nuvem de trovão no alvo.
- **Lunar-Florescer**: cria um Núcleo de Dendro **comum** + Orvalho (cura). O dano direto só sai de **ataques carregados**
  (como no jogo, onde só ataques específicos causam dano de Lunar-Florescer).
- **Lunar-Cristalizar**: 3 Moondrifts (15 s). Eles ficam parados; a cada 3 reações disparam a **Harmonia Moondrift**
  (projétil teleguiado de cada torreta, dano Geo). Só Lunar-Cristalizar gera Moondrift.

## Reações Estelares (precisam do Eixo Estelar)
- **Condução Estelar** (Cryo + Electro, substitui Superconduzir): **Campo da Estrela Polar** (12 s, raio 5): inimigos dentro
  perdem 40% de resistência física; você ganha +20% de dano Cryo/Electro e dano direto de Condução Estelar que cresce com as
  aplicações feitas nos últimos 4 s. Um campo por jogador.
- **Redemoinho Estelar** (Anemo + Cryo, substitui Difusão de Cryo): acerto Anemo + **Vórtice Estelar** (3 s) que puxa inimigos,
  sobe de nível a cada novo Redemoinho (até 3) e explode em área com dano Cryo. Dano direto por 8 s após a reação.

## Limites de otimização
- **Totens** (Moondrifts, Campo da Estrela Polar, Vórtice Estelar): no máximo **3** simultâneos numa área de **18x18 chunks**
  (mesma dimensão). Ao passar disso, o mais antigo some. Constantes em `Totems.java`.
- **Núcleos de Dendro** (não são totens): no máximo **6** numa área de **7x7 chunks**. Ao passar disso, o mais antigo detona na hora.
  Constantes em `LunarManager.java`.

## Comandos
`/ge element <nome>`, `/ge next`, `/ge prev`, `/ge skill`, `/ge chargestart`, `/ge chargerelease`, `/ge status`, `/ge artefatos`

## Se não compilar (pontos mais prováveis, 26.3 mudou muita coisa)
- `GenshinElementsClient`: `mc.gui.setScreenAndShow(...)` / `mc.gui.screen()` (abrir a roda) e `new KeyMapping.Category(...)`.
- `MoonGear`: `inv.isEquipped(item)` da API do Curios (único arquivo que toca o Curios).
- `ElementHud`: `GuiGraphicsExtractor.fill/text` e `registerAboveAll` do `RegisterGuiLayersEvent`.
- `ModItems`: assinatura de `registerItem`/`registerSimpleItem`. `neo_version` em `gradle.properties` (pegue a mais nova se faltar).
- Slots Curios: `data/genshinelements/curios/slots|entities` e tags `data/curios/tags/item/` (formato do Curios 17).
